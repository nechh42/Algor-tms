export interface PredictionResult {
  probability: number;
  direction: 'up' | 'down';
  confidence: number;
  symbol: string;
  predictedPrice: number;
  timeframe: string;
}

// Calculate standard deviation helper function
const calculateStandardDeviation = (values: number[]): number => {
  const n = values.length;
  if (n === 0) return 0;
  
  const mean = values.reduce((sum, val) => sum + val, 0) / n;
  const squareDiffs = values.map(value => {
    const diff = value - mean;
    return diff * diff;
  });
  
  const avgSquareDiff = squareDiffs.reduce((sum, val) => sum + val, 0) / n;
  return Math.sqrt(avgSquareDiff);
};

// Basit bir lineer regresyon modeli
class LinearRegression {
  private weights: number[] = [];
  private bias: number = 0;

  train(features: number[][], labels: number[], learningRate: number = 0.01, epochs: number = 100) {
    const numFeatures = features[0].length;
    this.weights = Array(numFeatures).fill(0);
    
    for (let epoch = 0; epoch < epochs; epoch++) {
      for (let i = 0; i < features.length; i++) {
        const prediction = this.predict(features[i]);
        const error = prediction - labels[i];
        
        // Ağırlıkları güncelle
        for (let j = 0; j < numFeatures; j++) {
          this.weights[j] -= learningRate * error * features[i][j];
        }
        this.bias -= learningRate * error;
      }
    }
  }

  predict(features: number[]): number {
    return features.reduce((sum, feature, i) => sum + feature * this.weights[i], 0) + this.bias;
  }
}

export const predictPrice = (prices: number[], volumes: number[]): PredictionResult => {
  try {
    // Son 20 günlük veriyi kullan
    const windowSize = 20;
    const features: number[][] = [];
    const labels: number[] = [];

    // Özellik mühendisliği
    for (let i = windowSize; i < prices.length; i++) {
      const priceWindow = prices.slice(i - windowSize, i);
      const volumeWindow = volumes.slice(i - windowSize, i);
      
      // Teknik göstergeler hesapla
      const priceChange = (priceWindow[windowSize-1] - priceWindow[0]) / priceWindow[0];
      const volumeChange = (volumeWindow[windowSize-1] - volumeWindow[0]) / volumeWindow[0];
      const priceVolatility = calculateStandardDeviation(priceWindow.map((p, idx) => 
        idx > 0 ? (p - priceWindow[idx-1]) / priceWindow[idx-1] : 0
      ));
      
      features.push([priceChange, volumeChange, priceVolatility]);
      labels.push(prices[i]);
    }

    // Model eğitimi
    const model = new LinearRegression();
    model.train(features, labels);

    // Son verilerle tahmin yap
    const lastFeatures = [
      (prices[prices.length-1] - prices[prices.length-21]) / prices[prices.length-21],
      (volumes[volumes.length-1] - volumes[volumes.length-21]) / volumes[volumes.length-21],
      calculateStandardDeviation(prices.slice(-20).map((p, i, arr) => 
        i > 0 ? (p - arr[i-1]) / arr[i-1] : 0
      ))
    ];

    const predictedPrice = model.predict(lastFeatures);
    const currentPrice = prices[prices.length - 1];
    const direction = predictedPrice > currentPrice ? 'up' : 'down';
    
    // Güven skorunu hesapla
    const recentAccuracy = Math.min(
      100,
      100 - Math.abs((predictedPrice - currentPrice) / currentPrice) * 100
    );

    return {
      probability: Math.abs((predictedPrice - currentPrice) / currentPrice) * 100,
      direction,
      confidence: recentAccuracy,
      symbol: 'THYAO', // Örnek sembol
      predictedPrice: parseFloat(predictedPrice.toFixed(2)),
      timeframe: '4h'
    };
  } catch (error) {
    console.error('Tahmin hatası:', error);
    return {
      probability: 50,
      direction: 'up',
      confidence: 0,
      symbol: 'THYAO',
      predictedPrice: prices[prices.length - 1],
      timeframe: '4h'
    };
  }
};