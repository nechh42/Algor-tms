import { toast } from "@/hooks/use-toast";

export interface RiskParameters {
  maxPositionSize: number;
  stopLossPercentage: number;
  takeProfitPercentage: number;
  maxDrawdown: number;
  riskPerTrade: number;
  maxOpenPositions: number;
  maxLeverage: number;        // Yeni eklenen
  marginRequirement: number;   // Yeni eklenen
}

export class RiskManagementService {
  private static riskParameters: RiskParameters = {
    maxPositionSize: 10000,
    stopLossPercentage: 2,
    takeProfitPercentage: 4,
    maxDrawdown: 10,
    riskPerTrade: 1,
    maxOpenPositions: 5,
    maxLeverage: 10,          // Maksimum kaldıraç
    marginRequirement: 20     // Teminat gereksinimi %
  };

  static calculatePositionSize(price: number, accountBalance: number): number {
    const maxRiskAmount = accountBalance * (this.riskParameters.riskPerTrade / 100);
    const positionSize = Math.min(
      maxRiskAmount / (this.riskParameters.stopLossPercentage / 100),
      this.riskParameters.maxPositionSize
    );
    return Math.floor(positionSize);
  }

  static calculateStopLoss(entryPrice: number, type: 'AL' | 'SAT'): number {
    const stopLossAmount = entryPrice * (this.riskParameters.stopLossPercentage / 100);
    return type === 'AL' ? 
      entryPrice - stopLossAmount : 
      entryPrice + stopLossAmount;
  }

  static calculateTakeProfit(entryPrice: number, type: 'AL' | 'SAT'): number {
    const takeProfitAmount = entryPrice * (this.riskParameters.takeProfitPercentage / 100);
    return type === 'AL' ? 
      entryPrice + takeProfitAmount : 
      entryPrice - takeProfitAmount;
  }

  static validatePosition(price: number, size: number, accountBalance: number): boolean {
    const positionValue = price * size;
    const maxAllowedValue = accountBalance * (this.riskParameters.maxPositionSize / 100);
    
    if (positionValue > maxAllowedValue) {
      toast({
        title: "Risk Uyarısı",
        description: "Pozisyon büyüklüğü maksimum izin verilen değeri aşıyor.",
        variant: "destructive",
      });
      return false;
    }
    return true;
  }

  static checkDrawdown(currentBalance: number, initialBalance: number): boolean {
    const drawdown = ((initialBalance - currentBalance) / initialBalance) * 100;
    if (drawdown > this.riskParameters.maxDrawdown) {
      toast({
        title: "Drawdown Uyarısı",
        description: `Maksimum drawdown limiti aşıldı: ${drawdown.toFixed(2)}%`,
        variant: "destructive",
      });
      return false;
    }
    return true;
  }

  static updateRiskParameters(newParams: Partial<RiskParameters>) {
    this.riskParameters = { ...this.riskParameters, ...newParams };
    toast({
      title: "Risk Parametreleri Güncellendi",
      description: "Yeni risk parametreleri başarıyla kaydedildi.",
    });
  }

  static getRiskParameters(): RiskParameters {
    return { ...this.riskParameters };
  }

  static calculateMarginRequired(price: number, size: number, leverage: number): number {
    const positionValue = price * size;
    return positionValue / leverage;
  }

  static validateVIOPPosition(price: number, size: number, leverage: number, accountBalance: number): boolean {
    const marginRequired = this.calculateMarginRequired(price, size, leverage);
    
    if (leverage > this.riskParameters.maxLeverage) {
      toast({
        title: "Risk Uyarısı",
        description: "Kaldıraç oranı maksimum limiti aşıyor.",
        variant: "destructive",
      });
      return false;
    }

    if (marginRequired > accountBalance * (this.riskParameters.marginRequirement / 100)) {
      toast({
        title: "Teminat Uyarısı",
        description: "Gerekli teminat miktarı hesap bakiyesinin izin verilen oranını aşıyor.",
        variant: "destructive",
      });
      return false;
    }

    return true;
  }
}
