import { toast } from "@/hooks/use-toast";

export interface SentimentData {
  score: number;
  volume: number;
  trend: 'bullish' | 'bearish' | 'neutral';
  confidence: number;
}

export class MarketSentimentService {
  private static readonly SENTIMENT_THRESHOLD = 0.6;

  static analyzeSentiment(
    price: number,
    volume: number,
    volatility: number
  ): SentimentData {
    // Basit bir duygu analizi simülasyonu
    const randomFactor = Math.random();
    const trendFactor = Math.sin(Date.now() / 10000); // Zaman bazlı dalgalanma
    
    const sentimentScore = (randomFactor + trendFactor) / 2;
    const confidence = 0.5 + (Math.random() * 0.5); // 0.5 ile 1 arası

    const trend: SentimentData['trend'] = 
      sentimentScore > this.SENTIMENT_THRESHOLD ? 'bullish' :
      sentimentScore < -this.SENTIMENT_THRESHOLD ? 'bearish' : 
      'neutral';

    if (confidence > 0.8) {
      toast({
        title: "Piyasa Duyarlılığı",
        description: `Yüksek güvenilirlikle ${
          trend === 'bullish' ? 'yükseliş' : 
          trend === 'bearish' ? 'düşüş' : 
          'nötr'
        } trendi tespit edildi`,
        variant: trend === 'bullish' ? "default" : "destructive"
      });
    }

    return {
      score: sentimentScore,
      volume,
      trend,
      confidence
    };
  }

  static async fetchNewsData(): Promise<void> {
    // Simüle edilmiş haber analizi
    const newsImpact = Math.random() - 0.5;
    
    if (Math.abs(newsImpact) > 0.3) {
      toast({
        title: "Haber Analizi",
        description: `Önemli haber etkisi: ${
          newsImpact > 0 ? 'Pozitif' : 'Negatif'
        }`,
        variant: newsImpact > 0 ? "default" : "destructive"
      });
    }
  }
}