export class VWAPService {
  static calculateVWAP(prices: number[], volumes: number[]): number {
    if (prices.length !== volumes.length || prices.length === 0) {
      return 0;
    }

    let cumulativeTPV = 0; // Total Price * Volume
    let cumulativeVolume = 0;

    for (let i = 0; i < prices.length; i++) {
      cumulativeTPV += prices[i] * volumes[i];
      cumulativeVolume += volumes[i];
    }

    return cumulativeVolume === 0 ? 0 : cumulativeTPV / cumulativeVolume;
  }

  static isVWAPSignal(currentPrice: number, vwap: number): 'AL' | 'SAT' | null {
    const threshold = 0.02; // %2 fark
    
    if (currentPrice > vwap * (1 + threshold)) {
      return 'AL'; // Fiyat VWAP'ın üzerinde
    } else if (currentPrice < vwap * (1 - threshold)) {
      return 'SAT'; // Fiyat VWAP'ın altında
    }
    
    return null;
  }
}