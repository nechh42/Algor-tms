export class MomentumService {
  // Rate of Change (ROC) - Momentum göstergesi
  static calculateROC(prices: number[], period: number = 14): number {
    if (prices.length < period) return 0;
    
    const currentPrice = prices[prices.length - 1];
    const oldPrice = prices[prices.length - 1 - period];
    
    return ((currentPrice - oldPrice) / oldPrice) * 100;
  }

  // Stochastic Oscillator
  static calculateStochastic(prices: number[], period: number = 14): {
    k: number; // %K değeri
    d: number; // %D değeri
  } {
    if (prices.length < period) return { k: 50, d: 50 };

    const recentPrices = prices.slice(-period);
    const currentPrice = recentPrices[recentPrices.length - 1];
    const lowest = Math.min(...recentPrices);
    const highest = Math.max(...recentPrices);

    const k = ((currentPrice - lowest) / (highest - lowest)) * 100;
    
    // %D is 3-period simple moving average of %K
    const d = k; // Basitleştirilmiş versiyon

    return { k, d };
  }

  static getMomentumSignal(roc: number, stoch: { k: number; d: number }): 'AL' | 'SAT' | null {
    // ROC sinyali
    const rocSignal = roc > 2 ? 'AL' : roc < -2 ? 'SAT' : null;
    
    // Stochastic sinyali
    const stochSignal = 
      (stoch.k > 80 && stoch.d > 80) ? 'SAT' :
      (stoch.k < 20 && stoch.d < 20) ? 'AL' : null;
    
    // Her iki indikatör de aynı sinyali veriyorsa
    if (rocSignal && rocSignal === stochSignal) {
      return rocSignal;
    }
    
    return null;
  }
}