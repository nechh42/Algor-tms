import { TechnicalAnalysisService } from './TechnicalAnalysisService';

export class DynamicLevelsService {
  static calculateDynamicLevels(
    price: number,
    volatility: number,
    trend: 'AL' | 'SAT'
  ): {
    stopLoss: number;
    takeProfit: number;
  } {
    // Volatilite bazlı dinamik çarpanlar
    const stopMultiplier = Math.max(0.5, Math.min(2, volatility));
    const profitMultiplier = Math.max(1, Math.min(3, volatility * 1.5));

    // Trend yönüne göre seviyeleri hesapla
    if (trend === 'AL') {
      return {
        stopLoss: price * (1 - stopMultiplier / 100),
        takeProfit: price * (1 + profitMultiplier / 100)
      };
    } else {
      return {
        stopLoss: price * (1 + stopMultiplier / 100),
        takeProfit: price * (1 - profitMultiplier / 100)
      };
    }
  }

  static adjustLevelsForVolume(
    levels: { stopLoss: number; takeProfit: number },
    volume: number,
    averageVolume: number
  ): { stopLoss: number; takeProfit: number } {
    // Hacim bazlı ayarlama faktörü
    const volumeFactor = volume / averageVolume;
    const adjustmentFactor = Math.max(0.8, Math.min(1.2, volumeFactor));

    return {
      stopLoss: levels.stopLoss * adjustmentFactor,
      takeProfit: levels.takeProfit * adjustmentFactor
    };
  }
}