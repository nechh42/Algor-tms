import { toast } from "@/hooks/use-toast";

export interface TechnicalIndicators {
  rsi: number;
  macd: {
    value: number;
    signal: number;
    histogram: number;
  };
  bollinger: {
    upper: number;
    middle: number;
    lower: number;
  };
  volume: number;
}

export class TechnicalAnalysisService {
  static calculateRSI(prices: number[], period: number = 14): number {
    if (prices.length < period) return 50;

    let gains = 0;
    let losses = 0;

    for (let i = 1; i < period; i++) {
      const difference = prices[i] - prices[i - 1];
      if (difference >= 0) {
        gains += difference;
      } else {
        losses -= difference;
      }
    }

    const avgGain = gains / period;
    const avgLoss = losses / period;
    const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;

    return 100 - (100 / (1 + rs));
  }

  static calculateMACD(prices: number[]): { value: number; signal: number; histogram: number } {
    const ema12 = this.calculateEMA(prices, 12);
    const ema26 = this.calculateEMA(prices, 26);
    const macdLine = ema12 - ema26;
    const signalLine = this.calculateEMA([macdLine], 9);

    return {
      value: macdLine,
      signal: signalLine,
      histogram: macdLine - signalLine
    };
  }

  static calculateBollinger(prices: number[], period: number = 20): { upper: number; middle: number; lower: number } {
    const sma = prices.slice(-period).reduce((a, b) => a + b) / period;
    const stdDev = Math.sqrt(
      prices.slice(-period).map(p => Math.pow(p - sma, 2)).reduce((a, b) => a + b) / period
    );

    return {
      upper: sma + (2 * stdDev),
      middle: sma,
      lower: sma - (2 * stdDev)
    };
  }

  static calculateVolatility(prices: number[], period: number = 20): number {
    if (prices.length < period) return 0;

    const returns = prices.slice(-period).map((price, i, arr) => 
      i > 0 ? (price - arr[i-1]) / arr[i-1] : 0
    );

    const avgReturn = returns.reduce((a, b) => a + b) / returns.length;
    const variance = returns.map(r => Math.pow(r - avgReturn, 2))
      .reduce((a, b) => a + b) / returns.length;

    return Math.sqrt(variance) * 100; // Convert to percentage
  }

  private static calculateEMA(prices: number[], period: number): number {
    const multiplier = 2 / (period + 1);
    let ema = prices[0];

    for (let i = 1; i < prices.length; i++) {
      ema = (prices[i] - ema) * multiplier + ema;
    }

    return ema;
  }
}
