export class BacktestService {
  static async getRecentTrades(market: 'SPOT' | 'VIOP'): Promise<any[]> {
    // Bu fonksiyon normalde backtest verilerini getirecek
    // Şimdilik mock veri dönüyoruz
    return [
      {
        symbol: market === 'SPOT' ? 'THYAO' : 'F_XU0300424',
        type: 'AL',
        entry: 85.40,
        exit: 87.20,
        pnl: 2.1,
        timestamp: new Date(),
        market: market
      },
      {
        symbol: market === 'SPOT' ? 'GARAN' : 'F_THYAO0424',
        type: 'SAT',
        entry: 44.80,
        exit: 43.90,
        pnl: 2.0,
        timestamp: new Date(),
        market: market
      }
    ];
  }
}