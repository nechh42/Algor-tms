export const calculateRSI = (prices: number[]): number => {
  if (prices.length < 14) return 50;
  
  let gains = 0;
  let losses = 0;
  
  for (let i = 1; i < 14; i++) {
    const difference = prices[i] - prices[i-1];
    if (difference >= 0) {
      gains += difference;
    } else {
      losses += Math.abs(difference);
    }
  }
  
  const avgGain = gains / 14;
  const avgLoss = losses / 14;
  
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
};

export const calculateVolatility = (prices: number[]): number => {
  if (prices.length < 20) return 0;
  
  const returns = prices.slice(-20).map((p, i, arr) => 
    i > 0 ? (p - arr[i-1]) / arr[i-1] : 0
  );
  
  const avgReturn = returns.reduce((a, b) => a + b) / returns.length;
  const variance = returns.map(r => Math.pow(r - avgReturn, 2))
    .reduce((a, b) => a + b) / returns.length;
  
  return Math.sqrt(variance);
};