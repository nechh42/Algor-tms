import { TradeSignal, Position, TradingStrategy } from './types/trading';
import { TradeValidator } from './trading/TradeValidator';
import { PositionManager } from './trading/PositionManager';
import { SignalAnalyzer } from './trading/SignalAnalyzer';
import { BacktestService } from './analysis/BacktestService';
import { toast } from '@/hooks/use-toast';
import { MockTradingDataService } from './trading/MockTradingDataService';

export class TradingService {
  static async analyzeSpotSymbols() {
    return SignalAnalyzer.analyzeSymbolsByMarket('SPOT');
  }

  static async analyzeVIOPSymbols() {
    return SignalAnalyzer.analyzeSymbolsByMarket('VIOP');
  }

  static validateTrade(signal: TradeSignal, currentPositions: Position[]): boolean {
    return TradeValidator.validateTrade(signal, currentPositions);
  }

  static async executeSignal(signal: TradeSignal) {
    return PositionManager.executeSignal(signal);
  }

  static closeAllPositions() {
    return PositionManager.closeAllPositions();
  }

  static getPositions() {
    return PositionManager.getPositions();
  }

  static async confirmTrend(symbol: string) {
    try {
      const recentPrices = await SignalAnalyzer.getRecentPrices(symbol);
      const ma20 = this.calculateMA(recentPrices, 20);
      const ma50 = this.calculateMA(recentPrices, 50);
      
      const currentPrice = recentPrices[recentPrices.length - 1];
      const trendStrength = (currentPrice - ma20) / ma20;
      
      return {
        isValid: trendStrength > 0.01,
        reason: trendStrength > 0.01 ? 'Trend güçlü' : 'Zayıf trend'
      };
    } catch (error) {
      console.error('Trend doğrulama hatası:', error);
      return { isValid: false, reason: 'Trend analizi başarısız' };
    }
  }

  static async analyzeVolume(symbol: string) {
    try {
      const recentVolumes = await SignalAnalyzer.getRecentVolumes(symbol);
      const avgVolume = this.calculateAverage(recentVolumes);
      const currentVolume = recentVolumes[recentVolumes.length - 1];
      
      return {
        isValid: currentVolume > avgVolume * 1.2,
        reason: currentVolume > avgVolume * 1.2 ? 'Yüksek hacim' : 'Yetersiz hacim'
      };
    } catch (error) {
      console.error('Hacim analizi hatası:', error);
      return { isValid: false, reason: 'Hacim analizi başarısız' };
    }
  }

  private static calculateMA(prices: number[], period: number): number {
    if (prices.length < period) return 0;
    const sum = prices.slice(-period).reduce((a, b) => a + b, 0);
    return sum / period;
  }

  private static calculateAverage(numbers: number[]): number {
    return numbers.reduce((a, b) => a + b, 0) / numbers.length;
  }

  static async calculateSuccessRate(market: 'SPOT' | 'VIOP'): Promise<number> {
    try {
      const trades = await BacktestService.getRecentTrades(market);
      if (!trades.length) return 0;

      const successfulTrades = trades.filter(trade => trade.pnl > 0);
      return (successfulTrades.length / trades.length) * 100;
    } catch (error) {
      console.error(`${market} başarı oranı hesaplanırken hata:`, error);
      return 0;
    }
  }

  static async optimizeParameters(): Promise<{
    success: boolean;
    optimizedParams: Record<string, any>;
  }> {
    try {
      const spotPerformance = await this.calculateSuccessRate('SPOT');
      const viopPerformance = await this.calculateSuccessRate('VIOP');
      
      const optimizedParams = {
        stopLossPercent: spotPerformance > 70 ? 2 : 3,
        takeProfitPercent: spotPerformance > 70 ? 4 : 3,
        gridLevels: viopPerformance > 70 ? 5 : 3,
        timeframe: spotPerformance > 80 ? '15m' : '1h',
        leverageLimit: viopPerformance > 75 ? 5 : 3
      };

      return {
        success: true,
        optimizedParams
      };
    } catch (error) {
      console.error('Bot parametre optimizasyonu hatası:', error);
      return {
        success: false,
        optimizedParams: {}
      };
    }
  }
}
