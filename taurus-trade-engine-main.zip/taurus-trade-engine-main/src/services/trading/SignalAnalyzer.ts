import { TradeSignal, MarketData } from '../types/trading';
import { TechnicalAnalysisStrategy } from './strategies/TechnicalAnalysisStrategy';
import { VolumeStrategy } from './strategies/VolumeStrategy';
import { MomentumStrategy } from './strategies/MomentumStrategy';
import { GridTradingService } from './GridTradingService';
import { DynamicLevelsService } from '../analysis/DynamicLevelsService';
import { toast } from '@/hooks/use-toast';
import { MockTradingDataService } from './MockTradingDataService';

export class SignalAnalyzer {
  private static readonly spotSymbols = [
    'AKBNK', 'GARAN', 'ISCTR', 'YKBNK', 'HALKB',
    'KCHOL', 'SAHOL', 'SISE', 'TAVHL', 'TKFEN',
    'THYAO', 'ASELS', 'TUPRS', 'EREGL', 'BIMAS'
  ];

  private static readonly viopSymbols = [
    'F_XU0300424', 'F_THYAO0424', 'F_GARAN0424',
    'F_AKBNK0424', 'F_KCHOL0424', 'F_EREGL0424'
  ];

  static async analyzeSymbolsByMarket(market: 'SPOT' | 'VIOP'): Promise<TradeSignal[]> {
    const symbols = market === 'SPOT' ? this.spotSymbols : this.viopSymbols;
    const signals: TradeSignal[] = [];
    
    for (const symbol of symbols) {
      try {
        const marketData = await MockTradingDataService.fetchStockData(symbol);
        
        if (marketData && marketData.length > 0) {
          const signal = await this.analyzeSingleSymbol(symbol, marketData, market);
          
          // Güven skorunu 0.60'a düşürdük
          if (signal && signal.confidence >= 0.60) {
            signals.push(signal);
            
            // Yüksek güvenli sinyal eşiğini de 0.75'e düşürdük
            if (signal.confidence > 0.75) {
              console.log(`Yüksek güvenli sinyal: ${symbol}, Güven: ${signal.confidence}`);
              toast({
                title: `Yüksek Güvenli ${market} Sinyali`,
                description: `${symbol} için ${signal.type} sinyali - Güven: %${(signal.confidence * 100).toFixed(1)}`,
              });
            }
          }
        }
      } catch (error) {
        console.error(`${symbol} analiz hatası:`, error);
      }
    }

    return signals;
  }

  private static async analyzeSingleSymbol(
    symbol: string,
    marketData: any[],
    market: 'SPOT' | 'VIOP'
  ): Promise<TradeSignal | null> {
    if (marketData.length < 2) return null;

    const prices = marketData.map(d => d.price);
    const lastPrice = prices[prices.length - 1];

    // Tüm stratejilerden sinyal al
    const signals = [
      TechnicalAnalysisStrategy.analyze(symbol, prices),
      VolumeStrategy.analyze(symbol, prices, marketData.map(d => d.volume || 0)),
      MomentumStrategy.analyze(symbol, prices)
    ].filter(signal => signal !== null) as Partial<TradeSignal>[];

    if (signals.length === 0) return null;

    // En yüksek güvenli sinyali seç
    const bestSignal = signals.reduce((prev, current) => 
      (current.confidence || 0) > (prev.confidence || 0) ? current : prev
    );

    // Dinamik seviyeleri daha esnek hesapla
    const volatility = Math.abs((lastPrice - prices[prices.length - 2]) / prices[prices.length - 2]);
    const dynamicLevels = DynamicLevelsService.calculateDynamicLevels(
      lastPrice,
      volatility * 1.5, // %50 daha esnek
      bestSignal.type as 'AL' | 'SAT'
    );

    return {
      ...bestSignal,
      stopLoss: dynamicLevels.stopLoss,
      takeProfit: dynamicLevels.takeProfit,
      timestamp: new Date(),
      market: market,
      leverage: market === 'VIOP' ? 10 : undefined,
      contractSize: market === 'VIOP' ? 1000 : undefined
    } as TradeSignal;
  }

  static async getRecentPrices(symbol: string): Promise<number[]> {
    try {
      const data = await MockTradingDataService.fetchStockData(symbol);
      return data.map(d => d.price);
    } catch (error) {
      console.error(`${symbol} fiyat verisi alınamadı:`, error);
      return [];
    }
  }

  static async getRecentVolumes(symbol: string): Promise<number[]> {
    try {
      const data = await MockTradingDataService.fetchStockData(symbol);
      return data.map(d => d.volume || 0);
    } catch (error) {
      console.error(`${symbol} hacim verisi alınamadı:`, error);
      return [];
    }
  }
}