import { Position, TradeSignal } from '../types/trading';
import { toast } from '@/hooks/use-toast';
import { RiskManagementService } from '../RiskManagementService';

export class PositionManager {
  private static positions: Position[] = [];
  private static accountBalance = 100000;

  static getPositions(): Position[] {
    return this.positions;
  }

  static async executeSignal(signal: TradeSignal): Promise<boolean> {
    console.log('Sinyal uygulanıyor:', signal);

    const positionSize = RiskManagementService.calculatePositionSize(
      signal.price,
      this.accountBalance
    );

    if (!RiskManagementService.validatePosition(signal.price, positionSize, this.accountBalance)) {
      return false;
    }

    const stopLossPrice = RiskManagementService.calculateStopLoss(signal.price, signal.type);
    const takeProfitPrice = RiskManagementService.calculateTakeProfit(signal.price, signal.type);

    const position: Position = {
      symbol: signal.symbol,
      type: signal.type,
      entry: signal.price,
      size: positionSize,
      stopLoss: stopLossPrice,
      takeProfit: takeProfitPrice,
      timestamp: new Date(),
      pnl: 0,
      market: signal.market || 'SPOT',
      leverage: signal.leverage,
      contractSize: signal.contractSize,
      status: 'OPEN'
    };

    this.positions.push(position);

    toast({
      title: "Yeni İşlem",
      description: `${signal.symbol} ${signal.type} pozisyonu açıldı. Fiyat: ${signal.price}`,
    });

    console.log('Pozisyon açıldı:', position);
    return true;
  }

  static closeAllPositions(): Position[] {
    const closedPositions = [...this.positions];
    this.positions = [];
    
    toast({
      title: "Pozisyonlar Kapatıldı",
      description: `${closedPositions.length} adet pozisyon kapatıldı.`,
    });
    
    return closedPositions;
  }

  static updatePositionPnL(symbol: string, currentPrice: number) {
    const position = this.positions.find(p => p.symbol === symbol);
    if (position) {
      const pnlPercentage = position.type === 'AL' ?
        ((currentPrice - position.entry) / position.entry) * 100 :
        ((position.entry - currentPrice) / position.entry) * 100;
      
      position.pnl = parseFloat(pnlPercentage.toFixed(2));

      // Stop loss ve take profit kontrolü
      if ((position.type === 'AL' && currentPrice <= position.stopLoss) ||
          (position.type === 'SAT' && currentPrice >= position.stopLoss)) {
        this.closePosition(symbol, 'Stop Loss');
      } else if ((position.type === 'AL' && currentPrice >= position.takeProfit) ||
                 (position.type === 'SAT' && currentPrice <= position.takeProfit)) {
        this.closePosition(symbol, 'Take Profit');
      }
    }
  }

  private static closePosition(symbol: string, reason: string) {
    const positionIndex = this.positions.findIndex(p => p.symbol === symbol);
    if (positionIndex !== -1) {
      const position = this.positions[positionIndex];
      this.positions.splice(positionIndex, 1);
      
      toast({
        title: `Pozisyon Kapatıldı - ${reason}`,
        description: `${symbol} pozisyonu ${reason} nedeniyle kapatıldı. PnL: ${position.pnl}%`,
      });
    }
  }
}