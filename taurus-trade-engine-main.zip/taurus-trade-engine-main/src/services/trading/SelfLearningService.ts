import { TradeSignal, Position } from '../types/trading';
import { toast } from '@/hooks/use-toast';

interface StrategyPerformance {
  strategyId: string;
  winRate: number;
  profitFactor: number;
  averageProfit: number;
  tradesCount: number;
}

export class SelfLearningService {
  private static strategyPerformance: Map<string, StrategyPerformance> = new Map();
  private static learningRate = 0.01;
  private static minConfidenceThreshold = 0.65;

  static updateStrategyPerformance(position: Position) {
    const strategyId = position.strategyId || 'default';
    const currentPerf = this.strategyPerformance.get(strategyId) || {
      strategyId,
      winRate: 0,
      profitFactor: 1,
      averageProfit: 0,
      tradesCount: 0
    };

    const isWin = position.pnl > 0;
    const newTradesCount = currentPerf.tradesCount + 1;
    
    // Performans metriklerini güncelle
    const newPerf = {
      ...currentPerf,
      tradesCount: newTradesCount,
      winRate: ((currentPerf.winRate * currentPerf.tradesCount) + (isWin ? 100 : 0)) / newTradesCount,
      averageProfit: ((currentPerf.averageProfit * currentPerf.tradesCount) + position.pnl) / newTradesCount,
      profitFactor: isWin ? currentPerf.profitFactor * (1 + this.learningRate) : 
                           currentPerf.profitFactor * (1 - this.learningRate)
    };

    this.strategyPerformance.set(strategyId, newPerf);
    this.adjustStrategyParameters(strategyId, newPerf);
  }

  private static adjustStrategyParameters(strategyId: string, performance: StrategyPerformance) {
    if (performance.tradesCount < 10) return; // Minimum veri gereksinimi

    if (performance.winRate < 50) {
      this.minConfidenceThreshold += this.learningRate;
      toast({
        title: "Bot Öğrenimi",
        description: "Düşük başarı oranı nedeniyle güven eşiği yükseltildi.",
      });
    } else if (performance.winRate > 70) {
      this.minConfidenceThreshold = Math.max(0.6, this.minConfidenceThreshold - this.learningRate);
      toast({
        title: "Bot Öğrenimi",
        description: "Yüksek başarı oranı nedeniyle güven eşiği optimize edildi.",
      });
    }

    // Öğrenme oranını dinamik olarak ayarla
    this.learningRate = Math.max(0.001, Math.min(0.05, 1 / performance.tradesCount));
  }

  static validateSignal(signal: TradeSignal): boolean {
    const strategyPerf = this.strategyPerformance.get(signal.strategyId || 'default');
    
    if (strategyPerf && strategyPerf.tradesCount > 10) {
      // Strateji performansına göre sinyal filtreleme
      if (strategyPerf.winRate < 45 || strategyPerf.profitFactor < 1) {
        return false;
      }
      
      // Düşük performanslı stratejiler için daha yüksek güven skoru gerekir
      if (strategyPerf.winRate < 55 && signal.confidence < this.minConfidenceThreshold + 0.1) {
        return false;
      }
    }

    return signal.confidence >= this.minConfidenceThreshold;
  }

  static getStrategyInsights(): StrategyPerformance[] {
    return Array.from(this.strategyPerformance.values());
  }
}