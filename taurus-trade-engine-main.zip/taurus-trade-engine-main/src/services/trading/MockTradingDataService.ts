import { MarketData } from '../types/trading';

export class MockTradingDataService {
  private static readonly spotSymbols = [
    // BIST 100
    'ACSEL', 'ADEL', 'AEFES', 'AFYON', 'AGESA', 'AKBNK', 'AKCNS', 'AKFGY', 'AKGRT', 'AKSA',
    'AKSEN', 'ALARK', 'ALBRK', 'ALGYO', 'ALKIM', 'ANACM', 'ARASE', 'ARCLK', 'ARDYZ', 'ASELS',
    'ASUZU', 'AYDEM', 'BAGFS', 'BAKAB', 'BALAT', 'BANVT', 'BERA', 'BIMAS', 'BIOEN', 'BIZIM',
    'BRISA', 'BRSAN', 'BRYAT', 'BUCIM', 'CCOLA', 'CEMTS', 'CIMSA', 'CLEBI', 'CRDFA', 'DEVA',
    'DOAS', 'DOHOL', 'ECILC', 'EGEEN', 'EKGYO', 'ENJSA', 'ENKAI', 'ERBOS', 'EREGL', 'EUREN',
    'FROTO', 'GARAN', 'GENIL', 'GESAN', 'GLYHO', 'GOZDE', 'GSDHO', 'GUBRF', 'GWIND', 'HALKB',
    'HEKTS', 'INDES', 'IPEKE', 'ISCTR', 'ISDMR', 'ISFIN', 'ISGYO', 'ISMEN', 'IZMDC', 'KARSN',
    'KARTN', 'KCHOL', 'KERVT', 'KLNMA', 'KMPUR', 'KONTR', 'KONYA', 'KORDS', 'KOZAA', 'KOZAL',
    'KRDMD', 'KZBGY', 'LOGO', 'MAVI', 'MGROS', 'NETAS', 'NTHOL', 'ODAS', 'OTKAR', 'OYAKC',
    'PENTA', 'PETKM', 'PGSUS', 'PNLSN', 'POLHO', 'PRKAB', 'PRKME', 'QUAGR', 'SAHOL', 'SASA',

    // BIST Tüm
    'ACSEL', 'ADEL', 'ADESE', 'AEFES', 'AFYON', 'AGESA', 'AGHOL', 'AGYO', 'AHGAZ', 'AKBNK', 
    'AKCNS', 'AKFGY', 'AKFYE', 'AKGRT', 'AKMGY', 'AKSA', 'AKSEN', 'AKSGY', 'AKSUE', 'AKYHO', 
    'ALARK', 'ALBRK', 'ALCAR', 'ALCTL', 'ALFAS', 'ALGYO', 'ALKA', 'ALKIM', 'ALMAD', 'ANELE', 
    'ANGEN', 'ANHYT', 'ANSGR', 'ARASE', 'ARCLK', 'ARDYZ', 'ARENA', 'ARMDA', 'ARSAN', 'ARZUM', 
    'ASELS', 'ASTOR', 'ASUZU', 'ATAGY', 'ATAKS', 'ATSYH', 'AVGYO', 'AVHOL', 'AVTUR', 'AYCES',
    'AYDEM', 'AYEN', 'AYES', 'AYGAZ', 'BAGFS', 'BAKAB', 'BALAT', 'BANVT', 'BASCM', 'BASGZ',
    'BAYRK', 'BERA', 'BEYAZ', 'BFREN', 'BIENY', 'BIGCH', 'BIMAS', 'BIOEN', 'BIZIM', 'BJKAS',
    'BLCYT', 'BMSCH', 'BNTAS', 'BOBET', 'BOSSA', 'BRISA', 'BRKO', 'BRMEN', 'BRSAN', 'BRYAT',
    'BSOKE', 'BTCIM', 'BUCIM', 'BURCE', 'BURVA', 'CASA', 'CCOLA', 'CELHA', 'CEMAS', 'CEMTS',
    'CEOEM', 'CIMSA', 'CLEBI', 'CMBTN', 'CMENT', 'COSMO', 'CRDFA', 'CRFSA', 'CUSAN', 'DAGHL',
    'DAGI', 'DARDL', 'DENGE', 'DERHL', 'DERIM', 'DESA', 'DESPC', 'DEVA', 'DGATE', 'DGNMO',
    'DIRIT', 'DITAS', 'DMSAS', 'DNISI', 'DOAS', 'DOBUR', 'DOCO', 'DOGUB', 'DOHOL', 'DOKTA',
    'DURDO', 'DYOBY', 'DZGYO', 'ECILC', 'ECZYT', 'EDATA', 'EDIP', 'EGEEN', 'EGEPO', 'EGPRO',
    'EGSER', 'EKGYO', 'EKIZ', 'EMKEL', 'ENJSA', 'ENKAI', 'EPLAS', 'ERBOS', 'EREGL', 'ERSU',
    'ESCAR', 'ESCOM', 'ESEN', 'ETILR', 'ETYAT', 'EUHOL', 'EUREN', 'FADE', 'FENER', 'FLAP',
    'FMIZP', 'FONET', 'FORMT', 'FRIGO', 'FROTO', 'GARAN', 'GARFA', 'GEDIK', 'GEDZA', 'GENIL',
    'GENTS', 'GEREL', 'GESAN', 'GLBMD', 'GLRYH', 'GLYHO', 'GMTAS', 'GOODY', 'GOZDE', 'GRNYO',
    'GRSEL', 'GSDDE', 'GSDHO', 'GSRAY', 'GUBRF', 'GWIND', 'HALKB', 'HATEK', 'HDFGS', 'HEKTS',
    'HKTM', 'HLGYO', 'HTTBT', 'HUBVC', 'HUNER', 'HUZFA', 'ICBCT', 'IDEAS', 'IDGYO', 'IEYHO',
    'IHLGM', 'IHLOS', 'IHYAY', 'IMASM', 'INDES', 'INFO', 'INGRM', 'INTEM', 'INVEO', 'IPEKE',
    'ISCTR', 'ISDMR', 'ISFIN', 'ISGYO', 'ISKPL', 'ISMEN', 'ISYAT', 'ITTFH', 'IZFAS', 'IZMDC',
    'JANTS', 'KAPLM', 'KAREL', 'KARSN', 'KARTN', 'KARYE', 'KATMR', 'KCHOL', 'KENT', 'KERVN',
    'KERVT', 'KFEIN', 'KGYO', 'KLGYO', 'KLKIM', 'KLMSN', 'KLNMA', 'KLRHO', 'KLSYN', 'KMPUR',
    'KNFRT', 'KONTR', 'KONYA', 'KOPOL', 'KORDS', 'KOZAA', 'KOZAL', 'KRDMA', 'KRDMB', 'KRDMD',
    'KRGYO', 'KRONT', 'KRPLS', 'KRSTL', 'KRTEK', 'KRVGD', 'KSTUR', 'KTLEV', 'KTSKR', 'KUTPO',
    'KUVVA', 'KUYAS', 'KZBGY', 'LIDER', 'LINK', 'LOGO', 'LUKSK', 'MAALT', 'MACKO', 'MAGEN',
    'MAKIM', 'MAKTK', 'MANAS', 'MARKA', 'MARTI', 'MAVI', 'MEDTR', 'MEGAP', 'MEGAP', 'MEPET',
    'MERIT', 'MERKO', 'METRO', 'METUR', 'MGROS', 'MIATK', 'MIPAZ', 'MMCAS', 'MNDRS', 'MPARK',
    'MRGYO', 'MRSHL', 'MSGYO', 'MTRKS', 'MTRYO', 'MZHLD', 'NATEN', 'NETAS', 'NIBAS', 'NTGAZ',
    'NTHOL', 'NUGYO', 'NUHCM', 'OBASE', 'ODAS', 'ONCSM', 'ORCAY', 'ORGE', 'ORMA', 'OSMEN',
    'OSTIM', 'OTKAR', 'OTTO', 'OYAKC', 'OYAYO', 'OYLUM', 'OYYAT', 'OZGYO', 'OZKGY', 'OZRDN',
    'OZSUB', 'PAGYO', 'PAMEL', 'PAPIL', 'PARSN', 'PASEU', 'PCILT', 'PEGYO', 'PEKGY', 'PENTA',
    'PETKM', 'PETUN', 'PGSUS', 'PINSU', 'PKART', 'PKENT', 'PNSUT', 'POLHO', 'POLTK', 'PRDGS',
    'PRKAB', 'PRKME', 'PRZMA', 'PSDTC', 'PSGYO', 'QNBFB', 'QUAGR', 'RALYH', 'RAYSG', 'RNPOL',
    'RODRG', 'ROYAL', 'RTALB', 'RUBNS', 'RYGYO', 'RYSAS', 'SAFKR', 'SAHOL', 'SAMAT', 'SANEL',
    'SANFM', 'SANKO', 'SARKY', 'SASA', 'SAYAS', 'SDTTR', 'SEGYO', 'SEKFK', 'SEKUR', 'SELEC',
    'SELGD', 'SELVA', 'SEYKM', 'SILVR', 'SISE', 'SKBNK', 'SKTAS', 'SMART', 'SMRTG', 'SNGYO',
    'SNKRN', 'SNPAM', 'SODSN', 'SOKM', 'SONME', 'SRVGY', 'SUMAS', 'SUNTK', 'SUWEN', 'TATEN',
    'TAVHL', 'TCELL', 'TDGYO', 'TEKTU', 'TETMT', 'TEZOL', 'TGSAS', 'THYAO', 'TKFEN', 'TKNSA',
    'TLMAN', 'TMPOL', 'TMSN', 'TNZTP', 'TOASO', 'TRCAS', 'TRGYO', 'TRILC', 'TSGYO', 'TSKB',
    'TSPOR', 'TTKOM', 'TTRAK', 'TUCLK', 'TUKAS', 'TUPRS', 'TUREX', 'TURGG', 'TURSG', 'UFUK',
    'ULAS', 'ULKER', 'ULUFA', 'ULUSE', 'ULUUN', 'UMPAS', 'UNLU', 'USAK', 'UTPYA', 'UZERB',
    'VAKBN', 'VAKFN', 'VAKKO', 'VANGD', 'VERTU', 'VERUS', 'VESBE', 'VESTL', 'VKFYO', 'VKGYO',
    'VKING', 'YAPRK', 'YATAS', 'YAYLA', 'YBTAS', 'YESIL', 'YGGYO', 'YGYO', 'YKBNK', 'YKSLN',
    'YONGA', 'YUNSA', 'YYAPI', 'YYLGD', 'ZEDUR', 'ZOREN', 'ZORLF'
  ];

  private static readonly viopContracts = [
    // Index Futures
    'F_XU0300424', 'F_XU0300624', 'F_XU0300824', 'F_XU0301024',
    'F_XU0301224', 'F_XU0300225', 'F_XU0300425', 'F_XU0300625',
    
    // Stock Futures
    'F_AKBNK0424', 'F_ARCLK0424', 'F_ASELS0424', 'F_BIMAS0424',
    'F_EKGYO0424', 'F_EREGL0424', 'F_FROTO0424', 'F_GARAN0424',
    'F_GUBRF0424', 'F_HEKTS0424', 'F_ISCTR0424', 'F_KCHOL0424',
    'F_KOZAA0424', 'F_KOZAL0424', 'F_KRDMD0424', 'F_PETKM0424',
    'F_PGSUS0424', 'F_SAHOL0424', 'F_SASA0424', 'F_SISE0424',
    'F_TAVHL0424', 'F_TCELL0424', 'F_THYAO0424', 'F_TOASO0424',
    'F_TSKB0424', 'F_TUPRS0424', 'F_VAKBN0424', 'F_VESTL0424',
    'F_YKBNK0424', 'F_YYLGD0424',
    
    // Currency Futures
    'F_TRYUSD0424', 'F_TRYEUR0424', 'F_USDTRY0424', 'F_EURTRY0424',
    'F_XAUUSD0424', 'F_XAGUSD0424', 'F_USDTRY0624', 'F_EURTRY0624',
    
    // Commodity Futures
    'F_WHEAT0424', 'F_COTTON0424', 'F_COFFEE0424', 'F_STEEL0424',
    'F_GOLD0424', 'F_SILVER0424', 'F_COPPER0424', 'F_PLATIN0424',
    'F_CRUDE0424', 'F_BRENT0424', 'F_NATGAS0424'
  ];

  static async fetchStockData(symbol: string): Promise<Array<{
    date: string;
    price: number;
    volume?: number;
    high?: number;
    low?: number;
    open?: number;
  }>> {
    console.log(`${symbol} için veri üretiliyor...`);
    
    const data = Array.from({ length: 90 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      
      const basePrice = 100 + Math.random() * 900;
      const volatility = 0.02;
      
      const high = basePrice * (1 + Math.random() * volatility);
      const low = basePrice * (1 - Math.random() * volatility);
      const open = low + Math.random() * (high - low);
      const close = low + Math.random() * (high - low);
      
      return {
        date: date.toISOString().split('T')[0],
        price: close,
        volume: Math.floor(Math.random() * 10000000) + 1000000,
        high,
        low,
        open
      };
    });

    console.log(`${symbol} için ${data.length} veri noktası üretildi`);
    return data;
  }

  static getAvailableSymbols(market: 'SPOT' | 'VIOP'): string[] {
    return market === 'SPOT' ? this.spotSymbols : this.viopContracts;
  }

  static async fetchMarketData(symbol: string): Promise<MarketData> {
    const data = await this.fetchStockData(symbol);
    const lastPrice = data[0].price;
    
    return {
      price: lastPrice,
      rsi: Math.random() * 100,
      volatility: Math.random() * 5 + 1,
      volume: Math.floor(Math.random() * 10000000) + 1000000,
      market: symbol.startsWith('F_') ? 'VIOP' : 'SPOT',
      contractSize: symbol.startsWith('F_') ? 1000 : undefined,
      openInterest: symbol.startsWith('F_') ? Math.floor(Math.random() * 50000) + 10000 : undefined
    };
  }
}
