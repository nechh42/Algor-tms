import { TradeSignal } from '../../types/trading';
import { TechnicalAnalysisService } from '../../analysis/TechnicalAnalysisService';

export class TechnicalAnalysisStrategy {
  static analyze(symbol: string, prices: number[]): Partial<TradeSignal> | null {
    if (prices.length < 14) return null;

    const rsi = TechnicalAnalysisService.calculateRSI(prices);
    const macd = TechnicalAnalysisService.calculateMACD(prices);
    const bollinger = TechnicalAnalysisService.calculateBollinger(prices);
    const lastPrice = prices[prices.length - 1];

    let signal: 'AL' | 'SAT' | null = null;
    let confidence = 0;

    // RSI Analizi
    if (rsi < 30) {
      signal = 'AL';
      confidence += 0.2;
    } else if (rsi > 70) {
      signal = 'SAT';
      confidence += 0.2;
    }

    // MACD Analizi
    if (macd.histogram > 0 && macd.histogram > macd.signal) {
      if (signal === 'AL') confidence += 0.2;
      else if (!signal) {
        signal = 'AL';
        confidence += 0.15;
      }
    } else if (macd.histogram < 0 && macd.histogram < macd.signal) {
      if (signal === 'SAT') confidence += 0.2;
      else if (!signal) {
        signal = 'SAT';
        confidence += 0.15;
      }
    }

    // Bollinger Analizi
    if (lastPrice < bollinger.lower) {
      if (signal === 'AL') confidence += 0.2;
      else if (!signal) {
        signal = 'AL';
        confidence += 0.15;
      }
    } else if (lastPrice > bollinger.upper) {
      if (signal === 'SAT') confidence += 0.2;
      else if (!signal) {
        signal = 'SAT';
        confidence += 0.15;
      }
    }

    if (!signal || confidence < 0.6) return null;

    return {
      symbol,
      type: signal,
      price: lastPrice,
      confidence,
      opportunity: confidence > 0.8 ? 'HIGH' : confidence > 0.7 ? 'MEDIUM' : 'LOW'
    };
  }
}