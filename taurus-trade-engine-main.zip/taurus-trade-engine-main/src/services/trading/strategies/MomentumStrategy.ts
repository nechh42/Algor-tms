import { TradeSignal } from '../../types/trading';
import { MomentumService } from '../../analysis/MomentumService';

export class MomentumStrategy {
  static analyze(symbol: string, prices: number[]): Partial<TradeSignal> | null {
    if (prices.length < 14) return null;

    const roc = MomentumService.calculateROC(prices);
    const stoch = MomentumService.calculateStochastic(prices);
    const signal = MomentumService.getMomentumSignal(roc, stoch);

    if (!signal) return null;

    // Momentum gücüne göre güven skoru hesaplama
    const confidence = Math.min(0.9, 0.6 + Math.abs(roc) * 0.02);

    return {
      symbol,
      type: signal,
      price: prices[prices.length - 1],
      confidence,
      opportunity: confidence > 0.8 ? 'HIGH' : confidence > 0.7 ? 'MEDIUM' : 'LOW'
    };
  }
}