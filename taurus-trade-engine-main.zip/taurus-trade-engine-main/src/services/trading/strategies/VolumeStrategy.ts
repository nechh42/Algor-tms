import { TradeSignal } from '../../types/trading';
import { VWAPService } from '../../analysis/VWAPService';

export class VolumeStrategy {
  static analyze(
    symbol: string,
    prices: number[],
    volumes: number[]
  ): Partial<TradeSignal> | null {
    if (prices.length < 20 || volumes.length < 20) return null;

    const vwap = VWAPService.calculateVWAP(prices, volumes);
    const lastPrice = prices[prices.length - 1];
    const signal = VWAPService.isVWAPSignal(lastPrice, vwap);

    if (!signal) return null;

    const avgVolume = volumes.reduce((a, b) => a + b) / volumes.length;
    const lastVolume = volumes[volumes.length - 1];
    const volumeRatio = lastVolume / avgVolume;

    // Hacim analizi bazlı güven skoru
    const confidence = Math.min(0.9, 0.6 + (volumeRatio - 1) * 0.1);

    return {
      symbol,
      type: signal,
      price: lastPrice,
      confidence,
      opportunity: confidence > 0.8 ? 'HIGH' : confidence > 0.7 ? 'MEDIUM' : 'LOW'
    };
  }
}