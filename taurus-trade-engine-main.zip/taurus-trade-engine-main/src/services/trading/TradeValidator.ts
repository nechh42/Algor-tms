import { TradeSignal, Position } from '../types/trading';
import { toast } from '@/hooks/use-toast';
import { RiskManagementService } from '../RiskManagementService';
import { TechnicalAnalysisService } from '../analysis/TechnicalAnalysisService';
import { SelfLearningService } from './SelfLearningService';

export class TradeValidator {
  private static maxDailyTrades = 15; // Artırıldı
  private static minVolume = 3000000; // Düşürüldü
  private static minVolatility = 1.2; // Düşürüldü
  private static successfulTrades: Map<string, number> = new Map();
  private static dailyTradeCount = 0;
  private static lastTradeReset = new Date().setHours(0, 0, 0, 0);
  private static minProfitRatio = 1.5; // Düşürüldü

  static validateTrade(signal: TradeSignal, currentPositions: Position[]): boolean {
    this.resetDailyTradeCountIfNeeded();

    // Mevcut pozisyon kontrolü - aynı yönde ikinci pozisyona izin ver
    const existingPosition = currentPositions.find(pos => pos.symbol === signal.symbol);
    if (existingPosition && existingPosition.type !== signal.type) {
      console.log(`${signal.symbol} için ters yönlü pozisyon mevcut`);
      return false;
    }

    // Self-learning servisinden sinyal validasyonu - daha esnek
    if (!SelfLearningService.validateSignal(signal)) {
      if (signal.confidence > 0.80) { // Yüksek güvenli sinyallere şans ver
        console.log('Yüksek güvenli sinyal - validasyon bypass ediliyor');
        return true;
      }
      console.log('Self-learning validasyonundan geçemedi');
      return false;
    }

    // Pozisyon limiti kontrolü - daha esnek
    const maxPositions = RiskManagementService.getRiskParameters().maxOpenPositions;
    if (currentPositions.length >= maxPositions + 3) { // +3 esneklik
      console.log('Maksimum pozisyon limitine ulaşıldı');
      return false;
    }

    // Risk/Ödül oranı kontrolü - daha esnek
    const riskRewardRatio = Math.abs((signal.takeProfit - signal.price) / (signal.price - signal.stopLoss));
    if (riskRewardRatio < this.minProfitRatio) {
      if (signal.confidence > 0.85) { // Yüksek güvenli sinyallere şans ver
        console.log('Düşük R/R oranı fakat yüksek güven - işlem onaylandı');
        return true;
      }
      console.log('Risk/Ödül oranı yetersiz:', riskRewardRatio);
      return false;
    }

    // Teknik gösterge kontrolü - daha esnek
    if (!this.validateTechnicalIndicators(signal)) {
      if (signal.confidence > 0.82) { // Yüksek güvenli sinyallere şans ver
        console.log('Teknik indikatörler uygun değil fakat yüksek güven - işlem onaylandı');
        return true;
      }
      console.log('Teknik indikatörler uygun değil');
      return false;
    }

    this.dailyTradeCount++;
    
    toast({
      title: "İşlem Fırsatı",
      description: `${signal.symbol} için ${signal.type} sinyali onaylandı. Güven: ${(signal.confidence * 100).toFixed(1)}%`,
    });
    
    return true;
  }

  private static validateTechnicalIndicators(signal: TradeSignal): boolean {
    // RSI kontrolü - daha esnek
    const rsi = TechnicalAnalysisService.calculateRSI([signal.price], 14);
    if ((signal.type === 'AL' && rsi > 80) || (signal.type === 'SAT' && rsi < 20)) {
      return false;
    }

    // MACD kontrolü - daha esnek
    const macd = TechnicalAnalysisService.calculateMACD([signal.price]);
    if (signal.type === 'AL' && macd.histogram < -0.15) {
      return false;
    }

    // Bollinger kontrolü - daha esnek
    const bollinger = TechnicalAnalysisService.calculateBollinger([signal.price]);
    if ((signal.type === 'AL' && signal.price > bollinger.upper * 1.03) ||
        (signal.type === 'SAT' && signal.price < bollinger.lower * 0.97)) {
      return false;
    }

    return true;
  }

  static recordTradeResult(symbol: string, successful: boolean, position: Position) {
    const currentSuccess = this.successfulTrades.get(symbol) || 0;
    this.successfulTrades.set(symbol, successful ? currentSuccess + 1 : currentSuccess - 1);
    
    // Self-learning servisini bilgilendir
    SelfLearningService.updateStrategyPerformance(position);
  }

  private static getSymbolSuccessRate(symbol: string): number {
    const successCount = this.successfulTrades.get(symbol) || 0;
    const totalTrades = Math.abs(successCount) + 1; // Add 1 to avoid division by zero
    return (successCount / totalTrades) * 100;
  }

  private static resetDailyTradeCountIfNeeded() {
    const now = new Date();
    const today = now.setHours(0, 0, 0, 0);
    
    if (today > this.lastTradeReset) {
      this.dailyTradeCount = 0;
      this.lastTradeReset = today;
    }
  }

  static updateRiskParameters(params: {
    maxDailyTrades?: number;
    minVolume?: number;
    minVolatility?: number;
  }) {
    if (params.maxDailyTrades) {
      this.maxDailyTrades = params.maxDailyTrades;
    }
    if (params.minVolume) {
      this.minVolume = params.minVolume;
    }
    if (params.minVolatility) {
      this.minVolatility = params.minVolatility;
    }
    
    toast({
      title: "Risk Parametreleri Güncellendi",
      description: "Yeni ticaret kriterleri başarıyla uygulandı.",
    });
  }
}