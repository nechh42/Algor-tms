import { toast } from '@/hooks/use-toast';
import { Position } from '../types/trading';
import { RiskManagementService } from '../RiskManagementService';

interface GridLevel {
  price: number;
  type: 'AL' | 'SAT';
  executed: boolean;
}

export class GridTradingService {
  private static gridLevels: Map<string, GridLevel[]> = new Map();
  private static gridSpacing = 0.5; // % olarak ızgara aralığı
  private static maxGrids = 10; // maksimum ızgara sayısı

  static setupGrid(symbol: string, currentPrice: number, range: number = 5) {
    const levels: GridLevel[] = [];
    const step = (currentPrice * this.gridSpacing) / 100;
    
    // Yukarı yönlü ızgaralar
    for (let i = 1; i <= this.maxGrids / 2; i++) {
      levels.push({
        price: currentPrice + (i * step),
        type: 'SAT',
        executed: false
      });
    }
    
    // Aşağı yönlü ızgaralar
    for (let i = 1; i <= this.maxGrids / 2; i++) {
      levels.push({
        price: currentPrice - (i * step),
        type: 'AL',
        executed: false
      });
    }

    // Fiyata göre sırala
    levels.sort((a, b) => b.price - a.price);
    this.gridLevels.set(symbol, levels);

    toast({
      title: "Grid Trading Kuruldu",
      description: `${symbol} için ${this.maxGrids} seviyeli ızgara oluşturuldu.`,
    });

    return levels;
  }

  static checkGridLevels(symbol: string, currentPrice: number): Position | null {
    const levels = this.gridLevels.get(symbol);
    if (!levels) return null;

    for (const level of levels) {
      if (level.executed) continue;

      if (level.type === 'AL' && currentPrice <= level.price) {
        level.executed = true;
        const size = RiskManagementService.calculatePositionSize(currentPrice, 100000);
        
        return {
          symbol,
          type: 'AL',
          entry: currentPrice,
          size,
          stopLoss: currentPrice * 0.98,
          takeProfit: currentPrice * 1.02,
          timestamp: new Date(),
          pnl: 0,
          market: 'SPOT',
          status: 'OPEN'
        };
      }

      if (level.type === 'SAT' && currentPrice >= level.price) {
        level.executed = true;
        const size = RiskManagementService.calculatePositionSize(currentPrice, 100000);
        
        return {
          symbol,
          type: 'SAT',
          entry: currentPrice,
          size,
          stopLoss: currentPrice * 1.02,
          takeProfit: currentPrice * 0.98,
          timestamp: new Date(),
          pnl: 0,
          market: 'SPOT',
          status: 'OPEN'
        };
      }
    }

    return null;
  }

  static resetGrid(symbol: string) {
    this.gridLevels.delete(symbol);
    toast({
      title: "Grid Sıfırlandı",
      description: `${symbol} için ızgara ayarları sıfırlandı.`,
    });
  }

  static updateGridSpacing(spacing: number) {
    this.gridSpacing = spacing;
    toast({
      title: "Grid Aralığı Güncellendi",
      description: `Izgara aralığı ${spacing}% olarak güncellendi.`,
    });
  }

  static getGridLevels(symbol: string): GridLevel[] {
    return this.gridLevels.get(symbol) || [];
  }
}