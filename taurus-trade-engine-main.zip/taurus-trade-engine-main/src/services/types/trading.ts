export interface TradeSignal {
  symbol: string;
  type: 'AL' | 'SAT';
  price: number;
  confidence: number;
  stopLoss: number;
  takeProfit: number;
  timestamp: Date;
  opportunity: 'HIGH' | 'MEDIUM' | 'LOW';
  market: 'SPOT' | 'VIOP';
  leverage?: number;
  contractSize?: number;
  size?: number; // Added size property
  strategyId?: string; // Added strategyId property
}

export interface Position {
  symbol: string;
  type: 'AL' | 'SAT';
  entry: number;
  size: number;
  stopLoss: number;
  takeProfit: number;
  timestamp: Date;
  pnl: number;
  market: 'SPOT' | 'VIOP';
  leverage?: number;
  marginRequired?: number;
  contractSize?: number;
  status: 'OPEN' | 'CLOSED';
  closePrice?: number;
  closeTimestamp?: Date;
  strategyId?: string; // Added strategyId property
}

export interface MarketData {
  price: number;
  rsi: number;
  volatility: number;
  volume: number;
  market: 'SPOT' | 'VIOP';
  contractSize?: number;
  openInterest?: number;  // Açık pozisyon sayısı
}

export interface TradingStrategy {
  id: string;
  name: string;
  description: string;
  analyze: (data: MarketData) => {
    signal: 'AL' | 'SAT' | null;
    confidence: number;
  };
  parameters?: Record<string, number | string | boolean>;
  supportedMarkets: ('SPOT' | 'VIOP')[];
}
