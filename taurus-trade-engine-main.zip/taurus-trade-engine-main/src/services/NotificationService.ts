import { toast } from "@/components/ui/use-toast";

export type NotificationPriority = 'low' | 'medium' | 'high';
export type NotificationType = 'price' | 'strategy' | 'risk' | 'system';

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: NotificationType;
  priority: NotificationPriority;
  timestamp: Date;
  read: boolean;
}

class NotificationService {
  private static notifications: Notification[] = [];

  static notify(
    title: string,
    message: string,
    type: NotificationType,
    priority: NotificationPriority = 'medium'
  ) {
    const notification: Notification = {
      id: Math.random().toString(36).substring(7),
      title,
      message,
      type,
      priority,
      timestamp: new Date(),
      read: false
    };

    this.notifications.push(notification);

    // Toast göster
    toast({
      title: notification.title,
      description: notification.message,
      variant: priority === 'high' ? "destructive" : "default",
    });

    // Yüksek öncelikli bildirimlerde ses çal
    if (priority === 'high') {
      const audio = new Audio('/notification.mp3');
      audio.play().catch(() => {});
    }

    return notification;
  }

  static getNotifications() {
    return this.notifications;
  }

  static markAsRead(id: string) {
    const notification = this.notifications.find(n => n.id === id);
    if (notification) {
      notification.read = true;
    }
  }

  static clearAll() {
    this.notifications = [];
  }

  // Fiyat uyarıları
  static priceAlert(symbol: string, price: number, change: number) {
    const direction = change > 0 ? 'yükseldi' : 'düştü';
    const priority: NotificationPriority = Math.abs(change) > 5 ? 'high' : 'medium';
    
    this.notify(
      `${symbol} Fiyat Uyarısı`,
      `${symbol} %${Math.abs(change).toFixed(2)} ${direction}. Güncel fiyat: ${price.toFixed(2)} ₺`,
      'price',
      priority
    );
  }

  // Strateji bildirimleri
  static strategyNotification(strategyName: string, message: string, success: boolean) {
    this.notify(
      `Strateji: ${strategyName}`,
      message,
      'strategy',
      success ? 'medium' : 'high'
    );
  }

  // Risk uyarıları
  static riskAlert(message: string, severity: NotificationPriority = 'high') {
    this.notify(
      'Risk Uyarısı',
      message,
      'risk',
      severity
    );
  }

  // Sistem bildirimleri
  static systemNotification(message: string) {
    this.notify(
      'Sistem Bildirimi',
      message,
      'system',
      'low'
    );
  }
}

export default NotificationService;