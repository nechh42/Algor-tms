import { toast } from '@/hooks/use-toast';
import NotificationService from './NotificationService';

export class AutoScheduleService {
  private static instance: AutoScheduleService;
  private timer: NodeJS.Timeout | null = null;
  private isRunning = false;

  private constructor() {}

  static getInstance(): AutoScheduleService {
    if (!AutoScheduleService.instance) {
      AutoScheduleService.instance = new AutoScheduleService();
    }
    return AutoScheduleService.instance;
  }

  private isWithinTradingHours(): boolean {
    const now = new Date();
    const day = now.getDay();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const currentTime = hours * 100 + minutes;

    // Hafta içi kontrolü (1-5 arası günler)
    if (day >= 1 && day <= 5) {
      // Saat kontrolü (09:45-18:15 arası)
      return currentTime >= 945 && currentTime <= 1815;
    }
    return false;
  }

  private checkAndNotifyStatus() {
    const isWorkingHours = this.isWithinTradingHours();
    
    if (isWorkingHours && !this.isRunning) {
      this.isRunning = true;
      NotificationService.systemNotification("Bot otomatik olarak başlatıldı (09:45-18:15 arası çalışma aktif)");
      toast({
        title: "Bot Durumu",
        description: "Otomatik çalışma başlatıldı",
      });
    } else if (!isWorkingHours && this.isRunning) {
      this.isRunning = false;
      NotificationService.systemNotification("Bot otomatik olarak durduruldu (çalışma saatleri dışında)");
      toast({
        title: "Bot Durumu",
        description: "Çalışma saatleri dışında - Bot durduruldu",
      });
    }
  }

  start() {
    if (this.timer) return;

    this.checkAndNotifyStatus();
    this.timer = setInterval(() => this.checkAndNotifyStatus(), 60000); // Her dakika kontrol et

    toast({
      title: "Otomatik Çalışma",
      description: "Bot 09:45-18:15 arası otomatik çalışacak şekilde ayarlandı",
    });
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
      this.isRunning = false;
    }

    toast({
      title: "Otomatik Çalışma",
      description: "Otomatik çalışma devre dışı bırakıldı",
    });
  }

  isActive(): boolean {
    return this.isRunning;
  }
}