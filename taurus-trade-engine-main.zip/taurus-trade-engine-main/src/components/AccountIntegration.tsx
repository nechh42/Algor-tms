import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';
import { Key, Lock, Shield } from 'lucide-react';

const AccountIntegration = () => {
  const [apiKey, setApiKey] = useState('');
  const [apiSecret, setApiSecret] = useState('');
  const [isConnected, setIsConnected] = useState(false);

  const handleConnect = () => {
    if (!apiKey || !apiSecret) {
      toast({
        title: "Hata",
        description: "Lütfen API anahtarı ve gizli anahtarı giriniz.",
        variant: "destructive",
      });
      return;
    }

    // API anahtarlarını güvenli bir şekilde localStorage'a kaydedelim
    localStorage.setItem('tradingApiKey', apiKey);
    localStorage.setItem('tradingApiSecret', apiSecret);
    
    setIsConnected(true);
    toast({
      title: "Başarılı",
      description: "Hesap bağlantısı başarıyla tamamlandı!",
    });
  };

  const handleDisconnect = () => {
    localStorage.removeItem('tradingApiKey');
    localStorage.removeItem('tradingApiSecret');
    setIsConnected(false);
    setApiKey('');
    setApiSecret('');
    
    toast({
      title: "Bilgi",
      description: "Hesap bağlantısı kesildi.",
    });
  };

  return (
    <Card className="p-6 space-y-6">
      <div className="flex items-center gap-2">
        <Key className="h-5 w-5 text-primary" />
        <h2 className="text-xl font-semibold">Hesap Entegrasyonu</h2>
      </div>

      {!isConnected ? (
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">API Anahtarı</label>
            <div className="relative">
              <Input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="API anahtarınızı giriniz"
                className="pr-10"
              />
              <Lock className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Gizli Anahtar</label>
            <div className="relative">
              <Input
                type="password"
                value={apiSecret}
                onChange={(e) => setApiSecret(e.target.value)}
                placeholder="Gizli anahtarınızı giriniz"
                className="pr-10"
              />
              <Shield className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
            </div>
          </div>

          <Button 
            onClick={handleConnect} 
            className="w-full"
          >
            Hesabı Bağla
          </Button>

          <p className="text-sm text-muted-foreground">
            API anahtarlarınızı aracı kurumunuzun web sitesinden alabilirsiniz. 
            Anahtarlarınız güvenli bir şekilde saklanacaktır.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="p-4 bg-green-50 text-green-700 rounded-lg">
            <p className="font-medium">Hesap Bağlantısı Aktif</p>
            <p className="text-sm">İşlemlerinizi güvenli bir şekilde gerçekleştirebilirsiniz.</p>
          </div>
          
          <Button 
            variant="outline" 
            onClick={handleDisconnect}
            className="w-full"
          >
            Bağlantıyı Kes
          </Button>
        </div>
      )}
    </Card>
  );
};

export default AccountIntegration;