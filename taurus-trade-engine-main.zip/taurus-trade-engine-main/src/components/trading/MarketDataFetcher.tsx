import React, { useEffect } from 'react';
import { MockTradingDataService } from '../../services/trading/MockTradingDataService';
import { toast } from '@/hooks/use-toast';

interface MarketDataFetcherProps {
  onDataUpdate: (data: Array<{
    date: string;
    price: number;
    volume?: number;
    high?: number;
    low?: number;
    open?: number;
  }>) => void;
}

const MarketDataFetcher: React.FC<MarketDataFetcherProps> = ({ onDataUpdate }) => {
  const fetchMarketData = async () => {
    try {
      const symbols = ['THYAO', 'GARAN', 'AKBNK', 'SISE', 'KCHOL', 'ASELS', 'TUPRS', 'EREGL', 'BIMAS'];
      
      console.log('Piyasa verisi alınıyor...');
      
      const allData = await Promise.all(
        symbols.map(async (symbol) => {
          const data = await MockTradingDataService.fetchStockData(symbol);
          return { symbol, data };
        })
      );

      const mostTradedStock = allData.reduce((prev, current) => {
        const prevVolume = prev.data.reduce((sum, item) => sum + (item.volume || 0), 0);
        const currentVolume = current.data.reduce((sum, item) => sum + (item.volume || 0), 0);
        return prevVolume > currentVolume ? prev : current;
      });

      console.log(`En çok işlem gören hisse: ${mostTradedStock.symbol}`);
      
      if (mostTradedStock.data.length > 0) {
        onDataUpdate(mostTradedStock.data);
        toast({
          title: "Piyasa Verisi Güncellendi",
          description: `${mostTradedStock.symbol} için ${mostTradedStock.data.length} veri noktası alındı`,
        });
      }
    } catch (error) {
      console.error('Veri alınırken hata oluştu:', error);
      toast({
        title: "Hata",
        description: "Veri alınırken bir hata oluştu.",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchMarketData();
    // Veri güncelleme süresini 15 saniyeye düşürdük
    const interval = setInterval(fetchMarketData, 15000);
    return () => clearInterval(interval);
  }, []);

  return null;
};

export default MarketDataFetcher;