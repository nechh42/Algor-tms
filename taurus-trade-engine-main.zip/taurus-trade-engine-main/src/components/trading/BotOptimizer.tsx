import React, { useEffect } from 'react';
import { TradingService } from '../../services/TradingService';
import { toast } from '@/hooks/use-toast';

interface BotOptimizerProps {
  isActive: boolean;
}

const BotOptimizer: React.FC<BotOptimizerProps> = ({ isActive }) => {
  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(async () => {
      try {
        const optimizationResult = await TradingService.optimizeParameters();
        console.log('Bot parametreleri optimize edildi:', optimizationResult);
        
        if (optimizationResult.success) {
          toast({
            title: "Bot Optimizasyonu",
            description: "Trading parametreleri güncellendi",
          });
        }
      } catch (error) {
        console.error('Bot optimizasyon hatası:', error);
      }
    }, 3600000); // Her saat başı

    return () => clearInterval(interval);
  }, [isActive]);

  return null;
};

export default BotOptimizer;