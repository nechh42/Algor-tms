import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { TrendingUp, TrendingDown, History, BarChart2, LineChart } from 'lucide-react';
import TradingChart from '../TradingChart';
import { formatCurrency, formatDate } from '@/lib/utils';

interface ViopPanelProps {
  positions: Array<any>;
  marketData: Array<any>;
}

const ViopPanel: React.FC<ViopPanelProps> = ({ positions, marketData }) => {
  const openPositions = positions.filter(p => p.status === 'OPEN');
  const closedPositions = positions.filter(p => p.status === 'CLOSED');
  
  const totalPnL = closedPositions.reduce((sum, pos) => sum + pos.pnl, 0);
  const winningTrades = closedPositions.filter(pos => pos.pnl > 0).length;
  const successRate = (winningTrades / closedPositions.length) * 100 || 0;

  return (
    <Tabs defaultValue="market" className="w-full">
      <TabsList className="grid w-full grid-cols-4">
        <TabsTrigger value="market" className="gap-2">
          <LineChart className="h-4 w-4" />
          Piyasa
        </TabsTrigger>
        <TabsTrigger value="analysis" className="gap-2">
          <BarChart2 className="h-4 w-4" />
          Analiz
        </TabsTrigger>
        <TabsTrigger value="positions" className="gap-2">
          <TrendingUp className="h-4 w-4" />
          İşlemler
        </TabsTrigger>
        <TabsTrigger value="history" className="gap-2">
          <History className="h-4 w-4" />
          Geçmiş
        </TabsTrigger>
      </TabsList>

      <TabsContent value="market">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-4">VİOP Piyasa Görünümü</h3>
          <TradingChart data={marketData} />
        </Card>
      </TabsContent>

      <TabsContent value="analysis">
        <Card className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Performans Metrikleri</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <div className="text-sm text-muted-foreground">Başarı Oranı</div>
                  <div className="text-2xl font-bold">%{successRate.toFixed(1)}</div>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="text-sm text-muted-foreground">Toplam Kar/Zarar</div>
                  <div className={`text-2xl font-bold ${totalPnL >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {totalPnL.toFixed(2)}%
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </TabsContent>

      <TabsContent value="positions">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-4">Açık Pozisyonlar</h3>
          <ScrollArea className="h-[300px]">
            {openPositions.map((position, index) => (
              <div key={index} className="mb-4 p-4 border rounded-lg">
                <div className="flex justify-between items-center">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{position.symbol}</span>
                      <Badge variant={position.type === 'AL' ? 'default' : 'destructive'}>
                        {position.type}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Giriş: {formatCurrency(position.entry)}
                    </div>
                  </div>
                  <div className={`text-lg font-semibold ${position.pnl >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {position.pnl}%
                  </div>
                </div>
              </div>
            ))}
          </ScrollArea>
        </Card>
      </TabsContent>

      <TabsContent value="history">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-4">İşlem Geçmişi</h3>
          <ScrollArea className="h-[300px]">
            {closedPositions.map((position, index) => (
              <div key={index} className="mb-4 p-4 border rounded-lg">
                <div className="flex justify-between items-center">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{position.symbol}</span>
                      <Badge variant={position.type === 'AL' ? 'default' : 'destructive'}>
                        {position.type}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {formatDate(position.closeTimestamp || position.timestamp)}
                    </div>
                  </div>
                  <div className={`text-lg font-semibold ${position.pnl >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {position.pnl}%
                  </div>
                </div>
                <div className="mt-2 text-sm text-muted-foreground">
                  <div>Giriş: {formatCurrency(position.entry)}</div>
                  <div>Çıkış: {formatCurrency(position.closePrice || 0)}</div>
                </div>
              </div>
            ))}
          </ScrollArea>
        </Card>
      </TabsContent>
    </Tabs>
  );
};

export default ViopPanel;