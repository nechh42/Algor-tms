import React from 'react';
import SpotTrader from './SpotTrader';
import ViopTrader from './ViopTrader';
import BotOptimizer from './BotOptimizer';

interface AutoTraderProps {
  isAutoTrading: boolean;
  isDemoMode: boolean;
  currentPositions: any[];
  onPositionUpdate: (positions: any[]) => void;
  autoSettings: {
    riskManagement: boolean;
    gridTrading: boolean;
    positionManagement: boolean;
  };
  selectedMarkets: string[];
}

const AutoTrader: React.FC<AutoTraderProps> = ({
  isAutoTrading,
  isDemoMode,
  currentPositions,
  onPositionUpdate,
  autoSettings,
  selectedMarkets
}) => {
  return (
    <>
      {selectedMarkets.includes('SPOT') && (
        <SpotTrader
          isActive={isAutoTrading}
          isDemoMode={isDemoMode}
          currentPositions={currentPositions}
          onPositionUpdate={onPositionUpdate}
        />
      )}
      {selectedMarkets.includes('VIOP') && (
        <ViopTrader
          isActive={isAutoTrading}
          isDemoMode={isDemoMode}
          currentPositions={currentPositions}
          onPositionUpdate={onPositionUpdate}
        />
      )}
      <BotOptimizer isActive={isAutoTrading} />
    </>
  );
};

export default AutoTrader;