import React, { useEffect } from 'react';
import { TradingService } from '../../services/TradingService';
import { toast } from '@/hooks/use-toast';

interface SpotTraderProps {
  isActive: boolean;
  isDemoMode: boolean;
  onPositionUpdate: (positions: any[]) => void;
  currentPositions: any[];
}

const SpotTrader: React.FC<SpotTraderProps> = ({
  isActive,
  isDemoMode,
  onPositionUpdate,
  currentPositions
}) => {
  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(async () => {
      try {
        const signals = await TradingService.analyzeSpotSymbols();
        const successRate = await TradingService.calculateSuccessRate('SPOT');
        console.log('SPOT Başarı Oranı:', successRate);
        
        if (signals.length > 0) {
          for (const signal of signals) {
            if (signal.confidence > 0.75) {
              console.log('SPOT sinyali bulundu:', signal);
              
              const success = isDemoMode ? true : await TradingService.executeSignal(signal);
              
              if (success) {
                const newPosition = {
                  symbol: signal.symbol,
                  type: signal.type,
                  entry: signal.price,
                  size: signal.size || Math.floor(10000 / signal.price),
                  stopLoss: signal.stopLoss,
                  takeProfit: signal.takeProfit,
                  timestamp: new Date(),
                  market: 'SPOT',
                  demo: isDemoMode
                };
                
                onPositionUpdate([...currentPositions, newPosition]);
                
                toast({
                  title: isDemoMode ? 'Demo SPOT İşlem' : 'SPOT İşlem',
                  description: `${signal.symbol} için ${signal.type} pozisyonu açıldı. Fiyat: ${signal.price}₺`,
                });
              }
            }
          }
        }
      } catch (error) {
        console.error('SPOT bot hatası:', error);
        toast({
          title: "Bot Hatası",
          description: "SPOT işlemleri sırasında bir hata oluştu.",
          variant: "destructive",
        });
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [isActive, isDemoMode, currentPositions, onPositionUpdate]);

  return null;
};

export default SpotTrader;