import React, { useEffect } from 'react';
import { TradingService } from '../../services/TradingService';
import { toast } from '@/hooks/use-toast';

interface ViopTraderProps {
  isActive: boolean;
  isDemoMode: boolean;
  onPositionUpdate: (positions: any[]) => void;
  currentPositions: any[];
}

const ViopTrader: React.FC<ViopTraderProps> = ({
  isActive,
  isDemoMode,
  onPositionUpdate,
  currentPositions
}) => {
  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(async () => {
      try {
        const signals = await TradingService.analyzeVIOPSymbols();
        const successRate = await TradingService.calculateSuccessRate('VIOP');
        console.log('VİOP Başarı Oranı:', successRate);
        
        if (signals.length > 0) {
          for (const signal of signals) {
            if (signal.confidence > 0.8) { // VİOP için daha yüksek güven skoru
              console.log('VİOP sinyali bulundu:', signal);
              
              const success = isDemoMode ? true : await TradingService.executeSignal(signal);
              
              if (success) {
                const newPosition = {
                  symbol: signal.symbol,
                  type: signal.type,
                  entry: signal.price,
                  size: signal.size || 1, // VİOP için kontrat sayısı
                  stopLoss: signal.stopLoss,
                  takeProfit: signal.takeProfit,
                  timestamp: new Date(),
                  market: 'VIOP',
                  leverage: signal.leverage || 10,
                  contractSize: signal.contractSize,
                  demo: isDemoMode
                };
                
                onPositionUpdate([...currentPositions, newPosition]);
                
                toast({
                  title: isDemoMode ? 'Demo VİOP İşlem' : 'VİOP İşlem',
                  description: `${signal.symbol} için ${signal.type} pozisyonu açıldı. Fiyat: ${signal.price}₺`,
                });
              }
            }
          }
        }
      } catch (error) {
        console.error('VİOP bot hatası:', error);
        toast({
          title: "Bot Hatası",
          description: "VİOP işlemleri sırasında bir hata oluştu.",
          variant: "destructive",
        });
      }
    }, 45000);

    return () => clearInterval(interval);
  }, [isActive, isDemoMode, currentPositions, onPositionUpdate]);

  return null;
};

export default ViopTrader;