import React from 'react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  Wallet, 
  TrendingUp, 
  TrendingDown,
  AlertTriangle,
  PieChart
} from 'lucide-react';

interface AccountStats {
  balance: number;
  equity: number;
  pnl: number;
  pnlPercentage: number;
  riskLevel: number;
}

const AccountOverview = () => {
  const accountStats: AccountStats = {
    balance: 250000,
    equity: 312500,
    pnl: 62500,
    pnlPercentage: 25,
    riskLevel: 35
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Wallet className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-semibold">Hesap Durumu</h2>
        </div>
        <Badge variant={accountStats.pnl >= 0 ? "default" : "destructive"}>
          {accountStats.pnlPercentage >= 0 ? "+" : ""}{accountStats.pnlPercentage}%
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Bakiye</span>
              <span className="font-medium">{accountStats.balance.toLocaleString()} ₺</span>
            </div>
            <Progress value={100} className="h-2" />
          </div>

          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Varlık</span>
              <span className="font-medium">{accountStats.equity.toLocaleString()} ₺</span>
            </div>
            <Progress value={(accountStats.equity / accountStats.balance) * 100} className="h-2" />
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {accountStats.pnl >= 0 ? (
                <TrendingUp className="h-4 w-4 text-green-500" />
              ) : (
                <TrendingDown className="h-4 w-4 text-red-500" />
              )}
              <span className="text-sm text-muted-foreground">Kar/Zarar</span>
            </div>
            <span className={`font-medium ${accountStats.pnl >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              {accountStats.pnl >= 0 ? '+' : ''}{accountStats.pnl.toLocaleString()} ₺
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-yellow-500" />
              <span className="text-sm text-muted-foreground">Risk Seviyesi</span>
            </div>
            <Progress value={accountStats.riskLevel} className="w-1/2 h-2" />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <PieChart className="h-4 w-4 text-blue-500" />
              <span className="text-sm text-muted-foreground">Başarı Oranı</span>
            </div>
            <span className="font-medium">65%</span>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default AccountOverview;