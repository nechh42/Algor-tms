import React, { useState, useEffect } from 'react';
import { Bell, BellRing, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import NotificationService, { Notification } from '../services/NotificationService';

const NotificationCenter = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    const updateNotifications = () => {
      const allNotifications = NotificationService.getNotifications();
      setNotifications(allNotifications);
      setUnreadCount(allNotifications.filter(n => !n.read).length);
    };

    updateNotifications();
    const interval = setInterval(updateNotifications, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleMarkAsRead = (id: string) => {
    NotificationService.markAsRead(id);
    setNotifications(NotificationService.getNotifications());
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  const handleClearAll = () => {
    NotificationService.clearAll();
    setNotifications([]);
    setUnreadCount(0);
  };

  const getNotificationColor = (type: Notification['type']) => {
    switch (type) {
      case 'price': return 'text-blue-500';
      case 'strategy': return 'text-green-500';
      case 'risk': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="icon" className="relative">
          {unreadCount > 0 ? (
            <>
              <BellRing className="h-5 w-5" />
              <Badge 
                className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0"
                variant="destructive"
              >
                {unreadCount}
              </Badge>
            </>
          ) : (
            <Bell className="h-5 w-5" />
          )}
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle className="flex justify-between items-center">
            <span>Bildirimler</span>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={handleClearAll}
              className="text-muted-foreground"
            >
              Tümünü Temizle
            </Button>
          </SheetTitle>
        </SheetHeader>
        <ScrollArea className="h-[calc(100vh-8rem)] mt-4">
          <div className="space-y-4">
            {notifications.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                Bildirim bulunmuyor
              </div>
            ) : (
              notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`
                    p-4 rounded-lg border
                    ${notification.read ? 'bg-background' : 'bg-accent'}
                  `}
                >
                  <div className="flex justify-between items-start gap-2">
                    <div>
                      <h4 className={`font-medium ${getNotificationColor(notification.type)}`}>
                        {notification.title}
                      </h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        {notification.message}
                      </p>
                      <span className="text-xs text-muted-foreground mt-2 block">
                        {new Date(notification.timestamp).toLocaleString('tr-TR')}
                      </span>
                    </div>
                    {!notification.read && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleMarkAsRead(notification.id)}
                      >
                        <Check className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
};

export default NotificationCenter;