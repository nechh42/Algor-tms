import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity,
  BarChart2,
  LineChart,
  Brain,
  AlertTriangle,
  Zap
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface IndicatorsPanelProps {
  data: Array<{ date: string; price: number }>;
}

interface Indicator {
  name: string;
  value: number;
  icon: LucideIcon;
  description: (value: number) => string;
  getVariant: (value: number) => "destructive" | "default" | "secondary";
  opportunity?: 'HIGH' | 'MEDIUM' | 'LOW';
}

const IndicatorsPanel: React.FC<IndicatorsPanelProps> = ({ data }) => {
  const calculateRSI = () => {
    if (!data || data.length < 14) return 50;
    const gains = [];
    const losses = [];
    
    for (let i = 1; i < 14; i++) {
      const difference = data[i].price - data[i-1].price;
      if (difference >= 0) {
        gains.push(difference);
        losses.push(0);
      } else {
        gains.push(0);
        losses.push(Math.abs(difference));
      }
    }
    
    const avgGain = gains.reduce((a, b) => a + b) / 14;
    const avgLoss = losses.reduce((a, b) => a + b) / 14;
    
    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  };

  const calculateBollinger = () => {
    if (!data || data.length < 20) return 50;
    const prices = data.slice(-20).map(d => d.price);
    const sma = prices.reduce((a, b) => a + b) / 20;
    const stdDev = Math.sqrt(prices.map(p => Math.pow(p - sma, 2)).reduce((a, b) => a + b) / 20);
    const currentPrice = prices[prices.length - 1];
    const upperBand = sma + (2 * stdDev);
    const lowerBand = sma - (2 * stdDev);
    return ((currentPrice - lowerBand) / (upperBand - lowerBand)) * 100;
  };

  const calculateVolatility = () => {
    if (!data || data.length < 20) return 0;
    const returns = data.slice(-20).map((d, i, arr) => 
      i > 0 ? (d.price - arr[i-1].price) / arr[i-1].price : 0
    );
    const avgReturn = returns.reduce((a, b) => a + b) / returns.length;
    const variance = returns.map(r => Math.pow(r - avgReturn, 2)).reduce((a, b) => a + b) / returns.length;
    return Math.sqrt(variance) * 100;
  };

  const indicators: Indicator[] = [
    {
      name: "RSI (14)",
      value: calculateRSI(),
      icon: Activity,
      description: value => {
        if (value < 25) return "YÜKSEK Alım Fırsatı!";
        if (value > 75) return "YÜKSEK Satış Fırsatı!";
        return "Nötr";
      },
      getVariant: value => value < 25 || value > 75 ? "default" : "secondary",
      opportunity: calculateRSI() < 25 || calculateRSI() > 75 ? 'HIGH' : 'LOW'
    },
    {
      name: "MACD",
      value: 25.5,
      icon: LineChart,
      description: value => value > 0.2 ? "Güçlü Yükseliş!" : value < -0.2 ? "Güçlü Düşüş!" : "Nötr",
      getVariant: value => Math.abs(value) > 0.2 ? "default" : "secondary",
      opportunity: Math.abs(25.5) > 0.2 ? 'MEDIUM' : 'LOW'
    },
    {
      name: "Bollinger",
      value: calculateBollinger(),
      icon: BarChart2,
      description: value => {
        if (value < 15) return "YÜKSEK Alım Fırsatı!";
        if (value > 85) return "YÜKSEK Satış Fırsatı!";
        return "Nötr Bölge";
      },
      getVariant: value => value < 15 || value > 85 ? "default" : "secondary",
      opportunity: calculateBollinger() < 15 || calculateBollinger() > 85 ? 'HIGH' : 'LOW'
    },
    {
      name: "Volatilite",
      value: calculateVolatility(),
      icon: Zap,
      description: value => {
        if (value > 2.5) return "Yüksek Fırsat Bölgesi!";
        if (value > 1.5) return "Orta Fırsat Bölgesi";
        return "Düşük Volatilite";
      },
      getVariant: value => value > 2.5 ? "default" : "secondary",
      opportunity: calculateVolatility() > 2.5 ? 'HIGH' : calculateVolatility() > 1.5 ? 'MEDIUM' : 'LOW'
    }
  ];

  return (
    <div className="grid grid-cols-1 gap-4">
      {indicators.map((indicator, index) => (
        <Card key={index} className={`p-4 space-y-3 ${
          indicator.opportunity === 'HIGH' ? 'border-green-500 shadow-lg' : ''
        }`}>
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <indicator.icon className={`h-4 w-4 ${
                indicator.opportunity === 'HIGH' ? 'text-green-500' : ''
              }`} />
              <span className="text-muted-foreground">{indicator.name}</span>
            </div>
            <Badge variant={indicator.getVariant(indicator.value)}>
              {indicator.value.toFixed(1)}
            </Badge>
          </div>
          <Progress 
            value={Math.min(Math.max(indicator.value, 0), 100)} 
            className={`h-2 ${
              indicator.opportunity === 'HIGH' ? 'bg-green-100' : ''
            }`}
          />
          <div className="flex justify-between items-center">
            <p className="text-xs text-muted-foreground">
              {indicator.description(indicator.value)}
            </p>
            {indicator.opportunity === 'HIGH' && (
              <Badge variant="default" className="bg-green-500">
                Yüksek Fırsat!
              </Badge>
            )}
          </div>
        </Card>
      ))}
    </div>
  );
};

export default IndicatorsPanel;