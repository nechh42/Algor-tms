import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

interface TradingChartProps {
  data: Array<{
    date: string;
    price: number;
    volume?: number;
  }>;
}

const TradingChart: React.FC<TradingChartProps> = ({ data }) => {
  return (
    <div className="w-full h-[400px]">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis 
            dataKey="date"
            tick={{ fontSize: 12 }}
            interval={Math.ceil(data.length / 10)}
          />
          <YAxis 
            yAxisId="price"
            orientation="left"
            domain={['auto', 'auto']}
            tick={{ fontSize: 12 }}
            tickFormatter={(value) => `₺${value.toLocaleString()}`}
            label={{ value: 'Fiyat (₺)', angle: -90, position: 'insideLeft' }}
          />
          <YAxis 
            yAxisId="volume"
            orientation="right"
            domain={['auto', 'auto']}
            tick={{ fontSize: 12 }}
            tickFormatter={(value) => `${(value/1000000).toFixed(1)}M`}
            label={{ value: 'Hacim', angle: 90, position: 'insideRight' }}
          />
          <Tooltip 
            formatter={(value: number, name: string) => {
              if (name === 'price') return [`₺${value.toLocaleString()}`, 'Fiyat'];
              if (name === 'volume') return [`${(value/1000000).toFixed(1)}M`, 'Hacim'];
              return [value, name];
            }}
            labelFormatter={(label) => `Tarih: ${label}`}
            contentStyle={{
              backgroundColor: 'rgba(255, 255, 255, 0.9)',
              border: '1px solid #ccc',
              padding: '10px',
              fontSize: '12px'
            }}
          />
          <Line
            yAxisId="price"
            type="monotone"
            dataKey="price"
            stroke="#10B981"
            strokeWidth={2}
            dot={false}
            name="price"
          />
          {data[0]?.volume && (
            <Line
              yAxisId="volume"
              type="monotone"
              dataKey="volume"
              stroke="#6366F1"
              strokeWidth={1.5}
              dot={false}
              name="volume"
            />
          )}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default TradingChart;