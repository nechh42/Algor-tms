import React, { useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Brain, TrendingUp, TrendingDown, AlertTriangle, RefreshCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PredictionResult, predictPrice } from '../utils/mlPredictions';
import { toast } from '@/hooks/use-toast';

const MLPrediction = () => {
  const [predictions, setPredictions] = useState<PredictionResult[]>([]);
  const [isTraining, setIsTraining] = useState(false);

  const trainAndPredict = async () => {
    setIsTraining(true);
    toast({
      title: "Model Eğitiliyor",
      description: "Yapay zeka modeli güncel verilerle eğitiliyor...",
    });

    try {
      // Örnek veri - gerçek uygulamada API'den gelecek
      const samplePrices = Array(150).fill(0).map((_, i) => 
        100 + Math.sin(i / 10) * 10 + Math.random() * 8 + i / 8
      );
      const sampleVolumes = Array(150).fill(0).map(() => 
        Math.random() * 1500000 + 300000
      );

      const prediction = predictPrice(samplePrices, sampleVolumes);
      prediction.symbol = 'THYAO';
      
      const prediction2 = {...prediction};
      prediction2.timeframe = '1d';
      prediction2.probability = Math.max(0, prediction.probability - 5);
      prediction2.confidence = Math.max(0, prediction.confidence - 3);
      prediction2.direction = prediction2.probability < 40 ? 'down' : 'up';

      setPredictions([prediction, prediction2]);

      if (prediction.confidence > 75) {
        toast({
          title: "Yüksek Güvenilirlikli Tahmin",
          description: `${prediction.symbol} için ${prediction.direction === 'up' ? 'yükseliş' : 'düşüş'} tahmini`,
        });
      }
    } catch (error) {
      console.error('Tahmin hatası:', error);
      toast({
        title: "Tahmin Hatası",
        description: "Model eğitimi sırasında bir hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setIsTraining(false);
    }
  };

  useEffect(() => {
    trainAndPredict();
    // Her 5 dakikada bir güncelle
    const interval = setInterval(trainAndPredict, 300000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Yapay Zeka Tahminleri</h2>
        </div>
        <Button 
          variant="outline" 
          size="sm"
          onClick={trainAndPredict}
          disabled={isTraining}
        >
          <RefreshCcw className={`h-4 w-4 mr-2 ${isTraining ? 'animate-spin' : ''}`} />
          Yeniden Eğit
        </Button>
      </div>
      
      {predictions.map((pred, index) => (
        <Card key={index} className="p-4 space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">
              {pred.timeframe} Tahmin ({pred.symbol})
            </span>
            {pred.direction === 'up' ? (
              <TrendingUp className="h-4 w-4 text-green-500" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-500" />
            )}
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Olasılık</span>
              <span>{pred.probability.toFixed(1)}%</span>
            </div>
            <Progress value={pred.probability} className="h-2" />
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Güven</span>
              <span>{pred.confidence.toFixed(1)}%</span>
            </div>
            <Progress value={pred.confidence} className="h-2" />
            {pred.confidence < 60 && (
              <div className="flex items-center gap-1 text-xs text-yellow-500">
                <AlertTriangle className="h-3 w-3" />
                <span>Düşük güven seviyesi</span>
              </div>
            )}
          </div>

          <div className="text-sm text-muted-foreground">
            Tahmin Edilen: {pred.predictedPrice.toFixed(2)} ₺
          </div>
        </Card>
      ))}
    </div>
  );
};

export default MLPrediction;