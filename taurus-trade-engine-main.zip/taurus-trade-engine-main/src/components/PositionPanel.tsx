import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from './ui/use-toast';
import { TrendingUp, TrendingDown, AlertTriangle, X } from 'lucide-react';

const PositionPanel = () => {
  const positions = [
    {
      symbol: "THYAO",
      type: "AL",
      entry: 85.40,
      current: 87.20,
      pnl: 2.1,
      size: "1000",
      risk: 65,
      target: 90.50,
      stopLoss: 83.20,
      market: "SPOT"
    },
    {
      symbol: "F_THYAO0424",
      type: "AL",
      entry: 86.20,
      current: 88.40,
      pnl: 2.5,
      size: "10",
      risk: 75,
      target: 92.00,
      stopLoss: 84.50,
      market: "VIOP",
      leverage: 10,
      contractSize: 1000
    }
  ];

  const handleClosePosition = (symbol: string) => {
    toast({
      title: "Pozisyon Kapatıldı",
      description: `${symbol} pozisyonu başarıyla kapatıldı.`,
    });
  };

  const handleModifyPosition = (symbol: string, action: string) => {
    toast({
      title: "Pozisyon Güncellendi",
      description: `${symbol} pozisyonu için ${action} işlemi gerçekleştirildi.`,
    });
  };

  return (
    <div className="space-y-4">
      {positions.map((position, index) => (
        <div key={index} className="border rounded-lg p-4 space-y-3 hover:shadow-lg transition-shadow">
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                {position.type === "AL" ? 
                  <TrendingUp className="h-4 w-4 text-green-500" /> : 
                  <TrendingDown className="h-4 w-4 text-red-500" />
                }
                <span className="font-medium">{position.symbol}</span>
                {position.market === "VIOP" && (
                  <Badge variant="secondary">VİOP</Badge>
                )}
              </div>
              <Badge variant={position.type === "AL" ? "default" : "destructive"}>
                {position.type === "AL" ? "ALIM" : "SATIM"}
              </Badge>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleClosePosition(position.symbol)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <span className="text-muted-foreground">Giriş:</span> {position.entry} ₺
            </div>
            <div>
              <span className="text-muted-foreground">Güncel:</span> {position.current} ₺
            </div>
            <div>
              <span className="text-muted-foreground">Hedef:</span> {position.target} ₺
            </div>
            <div>
              <span className="text-muted-foreground">Stop:</span> {position.stopLoss} ₺
            </div>
            <div>
              <span className="text-muted-foreground">
                {position.market === "VIOP" ? "Kontrat:" : "Lot:"}
              </span> {position.size}
            </div>
            {position.market === "VIOP" && (
              <div>
                <span className="text-muted-foreground">Kaldıraç:</span> {position.leverage}x
              </div>
            )}
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Risk Seviyesi:</span>
              <Progress value={position.risk} className="h-2" />
              {position.risk > 60 && (
                <AlertTriangle className="h-4 w-4 text-destructive" />
              )}
            </div>
          </div>

          <div className="flex justify-between items-center">
            <div className={`font-medium ${position.pnl >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              {position.pnl}%
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleModifyPosition(position.symbol, "Stop Loss Güncelleme")}
              >
                Stop Güncelle
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleModifyPosition(position.symbol, "Hedef Güncelleme")}
              >
                Hedef Güncelle
              </Button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default PositionPanel;
