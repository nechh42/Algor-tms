import React from 'react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { LineChart, Newspaper, MessageSquare, TrendingUp, AlertTriangle } from 'lucide-react';
import { toast } from './ui/use-toast';

interface SentimentData {
  source: string;
  sentiment: number;
  confidence: number;
  impact: 'high' | 'medium' | 'low';
  volume: number;
  trend: 'up' | 'down' | 'neutral';
  keywords: string[];
}

const SentimentAnalysis = () => {
  const sentiments: SentimentData[] = [
    {
      source: 'Sosyal Medya',
      sentiment: 65,
      confidence: 78,
      impact: 'high',
      volume: 12500,
      trend: 'up',
      keywords: ['büyüme', 'ihracat', 'yatırım']
    },
    {
      source: 'Haberler',
      sentiment: 45,
      confidence: 82,
      impact: 'medium',
      volume: 8300,
      trend: 'down',
      keywords: ['enflasyon', 'faiz', 'kur']
    },
    {
      source: 'Forum Tartışmaları',
      sentiment: 58,
      confidence: 71,
      impact: 'medium',
      volume: 5600,
      trend: 'neutral',
      keywords: ['teknik analiz', 'destek', 'direnç']
    }
  ];

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high':
        return 'text-green-500';
      case 'medium':
        return 'text-yellow-500';
      default:
        return 'text-gray-500';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'down':
        return <TrendingUp className="h-4 w-4 text-red-500 rotate-180" />;
      default:
        return <TrendingUp className="h-4 w-4 text-gray-500 rotate-90" />;
    }
  };

  const handleSourceClick = (source: string, sentiment: number) => {
    toast({
      title: `${source} Duygu Analizi`,
      description: `Güncel duygu skoru: ${sentiment}%. Detaylı rapor hazırlanıyor...`,
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Duygu Analizi</h2>
        </div>
        {sentiments.some(s => s.confidence < 75) && (
          <div className="flex items-center gap-1 text-yellow-500">
            <AlertTriangle className="h-4 w-4" />
            <span className="text-xs">Düşük güven skorları mevcut</span>
          </div>
        )}
      </div>
      
      {sentiments.map((sentiment, index) => (
        <Card 
          key={index} 
          className="p-4 space-y-3 hover:shadow-md transition-shadow cursor-pointer"
          onClick={() => handleSourceClick(sentiment.source, sentiment.sentiment)}
        >
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              {sentiment.source === 'Sosyal Medya' ? (
                <MessageSquare className="h-4 w-4" />
              ) : sentiment.source === 'Haberler' ? (
                <Newspaper className="h-4 w-4" />
              ) : (
                <LineChart className="h-4 w-4" />
              )}
              <span className="text-sm font-medium">{sentiment.source}</span>
            </div>
            {getTrendIcon(sentiment.trend)}
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Duygu Skoru</span>
              <span>{sentiment.sentiment}%</span>
            </div>
            <Progress value={sentiment.sentiment} className="h-2" />
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Güven</span>
              <span>{sentiment.confidence}%</span>
            </div>
            <Progress value={sentiment.confidence} className="h-2" />
          </div>

          <div className="flex flex-wrap gap-2">
            {sentiment.keywords.map((keyword, idx) => (
              <span 
                key={idx}
                className="text-xs bg-muted px-2 py-1 rounded-full"
              >
                {keyword}
              </span>
            ))}
          </div>

          <div className="text-xs text-muted-foreground">
            İşlem Hacmi: {sentiment.volume.toLocaleString()} etkileşim
          </div>
        </Card>
      ))}
    </div>
  );
};

export default SentimentAnalysis;