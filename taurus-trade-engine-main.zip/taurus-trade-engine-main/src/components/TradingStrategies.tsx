import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { toast } from './ui/use-toast';
import { Brain, TrendingUp, Activity, BarChart2 } from 'lucide-react';

interface TradingStrategiesProps {
  data: Array<{ date: string; price: number; volume?: number }>;
}

const TradingStrategies: React.FC<TradingStrategiesProps> = ({ data }) => {
  const strategies = [
    {
      name: "Yapay Zeka Stratejisi",
      signal: "AL",
      confidence: 92,
      description: "Derin öğrenme modeli yükseliş öngörüyor",
      details: "Son 1000 veri noktası analiz edildi",
      icon: Brain,
      active: true
    },
    {
      name: "Trend Takibi",
      signal: "AL",
      confidence: 85,
      description: "Güçlü yükselen trend",
      details: "20/50/200 günlük MA analizi",
      icon: TrendingUp,
      active: false
    },
    {
      name: "Volatilite Stratejisi",
      signal: "BEKLE",
      confidence: 60,
      description: "Yüksek volatilite tespit edildi",
      details: "Bollinger bantları genişliyor",
      icon: Activity,
      active: false
    },
    {
      name: "Hacim Analizi",
      signal: "AL",
      confidence: 78,
      description: "Yüksek alım hacmi",
      details: "OBV ve MFI pozitif",
      icon: BarChart2,
      active: true
    }
  ];

  const handleStrategyActivation = (strategyName: string) => {
    toast({
      title: "Strateji Aktifleştirildi",
      description: `${strategyName} stratejisi başarıyla aktif edildi.`,
    });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {strategies.map((strategy, index) => (
        <div key={index} className="border rounded-lg p-4 space-y-3 hover:shadow-lg transition-shadow">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <strategy.icon className="h-5 w-5 text-primary" />
              <h3 className="font-medium">{strategy.name}</h3>
            </div>
            <Badge variant={
              strategy.signal === "AL" ? "default" :
              strategy.signal === "SAT" ? "destructive" : "secondary"
            }>
              {strategy.signal}
            </Badge>
          </div>
          <Progress value={strategy.confidence} className="h-2" />
          <div className="text-sm">
            <p className="text-foreground">{strategy.description}</p>
            <p className="text-muted-foreground text-xs mt-1">{strategy.details}</p>
          </div>
          <div className="flex justify-between items-center gap-2">
            <Button 
              variant={strategy.active ? "default" : "outline"}
              size="sm" 
              className="flex-1"
              onClick={() => handleStrategyActivation(strategy.name)}
            >
              {strategy.active ? 'Aktif' : 'Aktifleştir'}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => toast({
                title: "Strateji Detayları",
                description: `${strategy.name} stratejisi için detaylı analiz görüntüleniyor.`,
              })}
            >
              Detaylar
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TradingStrategies;