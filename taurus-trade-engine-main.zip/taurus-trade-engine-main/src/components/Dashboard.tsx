import React, { useState, useEffect } from 'react';
import DashboardLayout from './dashboard/DashboardLayout';
import { TradingService } from '../services/TradingService';
import NotificationService from '../services/NotificationService';
import { AutoScheduleService } from '../services/AutoScheduleService';
import { toast } from '@/hooks/use-toast';
import MarketDataFetcher from './trading/MarketDataFetcher';
import AutoTrader from './trading/AutoTrader';
import { MockTradingDataService } from '../services/trading/MockTradingDataService';
import { Button } from './ui/button';
import { ToggleGroup, ToggleGroupItem } from './ui/toggle-group';

const Dashboard = () => {
  const [isAutoTrading, setIsAutoTrading] = useState(false);
  const [isAutoScheduleEnabled, setIsAutoScheduleEnabled] = useState(false);
  const [currentPositions, setCurrentPositions] = useState<any[]>([]);
  const [isDemoMode, setIsDemoMode] = useState(true);
  const [selectedMarkets, setSelectedMarkets] = useState<string[]>(['SPOT']);
  const [autoSettings, setAutoSettings] = useState({
    riskManagement: true,
    gridTrading: true,
    positionManagement: true,
    autoSchedule: false
  });
  const [marketData, setMarketData] = useState<Array<{
    date: string;
    price: number;
    volume?: number;
    high?: number;
    low?: number;
    open?: number;
  }>>([]);

  useEffect(() => {
    const loadIndexData = async () => {
      try {
        const indexData = await MockTradingDataService.fetchStockData('XU100');
        setMarketData(indexData);
      } catch (error) {
        console.error('Endeks verisi yüklenirken hata:', error);
      }
    };
    loadIndexData();
  }, []);

  useEffect(() => {
    const autoScheduleService = AutoScheduleService.getInstance();
    
    if (autoSettings.autoSchedule) {
      autoScheduleService.start();
      setIsAutoScheduleEnabled(true);
    } else {
      autoScheduleService.stop();
      setIsAutoScheduleEnabled(false);
    }

    return () => {
      autoScheduleService.stop();
    };
  }, [autoSettings.autoSchedule]);

  const handleAutoTrade = () => {
    if (selectedMarkets.length === 0) {
      toast({
        title: "Uyarı",
        description: "Lütfen en az bir piyasa seçin (SPOT/VİOP)",
        variant: "destructive",
      });
      return;
    }

    setIsAutoTrading(!isAutoTrading);
    if (!isAutoTrading) {
      NotificationService.systemNotification(
        `${isDemoMode ? "Demo: " : ""}${selectedMarkets.join(' ve ')} için akıllı işlem başlatıldı`
      );
      toast({
        title: isDemoMode ? "Demo Modu - Akıllı İşlem" : "Akıllı İşlem",
        description: `${selectedMarkets.join(' ve ')} piyasalarında bot başlatıldı`,
      });
    } else {
      NotificationService.systemNotification(
        isDemoMode ? "Demo: Akıllı işlem durduruldu" : "Akıllı işlem durduruldu"
      );
      toast({
        title: isDemoMode ? "Demo Modu - Akıllı İşlem" : "Akıllı İşlem",
        description: "Bot durduruldu",
      });
    }
  };

  const handleEmergencyStop = () => {
    const closedPositions = TradingService.closeAllPositions();
    setIsAutoTrading(false);
    setCurrentPositions([]);
    
    if (isAutoScheduleEnabled) {
      setAutoSettings(prev => ({ ...prev, autoSchedule: false }));
    }
    
    toast({
      title: isDemoMode ? "Demo Modu - Acil Durum" : "Acil Durum Durdurma",
      description: "Tüm işlemler durduruldu ve pozisyonlar kapatıldı.",
      variant: "destructive",
    });
  };

  const handleMarketSelection = (values: string[]) => {
    if (values.length === 0) {
      toast({
        title: "Uyarı",
        description: "En az bir piyasa seçili olmalıdır",
        variant: "destructive",
      });
      return;
    }
    setSelectedMarkets(values);
    toast({
      title: "Piyasa Seçimi",
      description: `Seçilen piyasalar: ${values.join(' ve ')}`,
    });
  };

  return (
    <>
      <MarketDataFetcher onDataUpdate={setMarketData} />
      <AutoTrader
        isAutoTrading={isAutoTrading}
        isDemoMode={isDemoMode}
        currentPositions={currentPositions}
        onPositionUpdate={setCurrentPositions}
        autoSettings={autoSettings}
        selectedMarkets={selectedMarkets}
      />
      <div className="mb-4">
        <h2 className="text-lg font-semibold mb-2">İşlem Yapılacak Piyasalar</h2>
        <ToggleGroup type="multiple" value={selectedMarkets} onValueChange={handleMarketSelection}>
          <ToggleGroupItem value="SPOT">SPOT</ToggleGroupItem>
          <ToggleGroupItem value="VIOP">VİOP</ToggleGroupItem>
        </ToggleGroup>
      </div>
      <DashboardLayout
        isAutoTrading={isAutoTrading}
        onAutoTradeToggle={handleAutoTrade}
        onEmergencyStop={handleEmergencyStop}
        marketData={marketData}
        isDemoMode={isDemoMode}
        onDemoModeToggle={() => setIsDemoMode(!isDemoMode)}
        autoSettings={autoSettings}
        onAutoSettingsChange={setAutoSettings}
        isAutoScheduleEnabled={isAutoScheduleEnabled}
        selectedMarkets={selectedMarkets}
      />
    </>
  );
};

export default Dashboard;