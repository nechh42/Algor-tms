import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, PieChart, Activity, Calendar } from 'lucide-react';

const PerformanceMetrics = () => {
  const [timeFrame, setTimeFrame] = useState('daily');
  
  const metrics = {
    totalTrades: 15,
    winRate: 68,
    avgProfit: 2.4,
    avgLoss: -1.2,
    profitFactor: 2.0,
    dailyPnL: 3.5,
    maxDrawdown: 8.2,
    activeTime: '4s 12d',
    strategies: {
      'Trend Takibi': { winRate: 72, profit: 4.2 },
      'Momentum': { winRate: 65, profit: 3.1 },
      'Breakout': { winRate: 58, profit: 2.8 }
    }
  };

  const performanceData = [
    { date: '2024-01', pnl: 2500 },
    { date: '2024-02', pnl: 3200 },
    { date: '2024-03', pnl: 2800 },
    { date: '2024-04', pnl: 4100 },
    { date: '2024-05', pnl: 3900 }
  ];

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <Activity className="h-5 w-5 text-primary" />
          Performans Metrikleri
        </h2>
        <Select value={timeFrame} onValueChange={setTimeFrame}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="Zaman Aralığı" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="daily">Günlük</SelectItem>
            <SelectItem value="weekly">Haftalık</SelectItem>
            <SelectItem value="monthly">Aylık</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Genel Bakış</TabsTrigger>
          <TabsTrigger value="strategies">Stratejiler</TabsTrigger>
          <TabsTrigger value="pnl">Kar/Zarar</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="p-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-muted-foreground">Kazanma Oranı</span>
                <span className="font-medium">{metrics.winRate}%</span>
              </div>
              <Progress value={metrics.winRate} className="h-2" />
            </Card>

            <Card className="p-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Toplam İşlem</span>
                <span className="font-medium">{metrics.totalTrades}</span>
              </div>
            </Card>

            <Card className="p-4 space-y-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-500" />
                <span className="text-muted-foreground">Ortalama Kazanç</span>
                <span className="font-medium text-green-500">%{metrics.avgProfit}</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingDown className="h-4 w-4 text-red-500" />
                <span className="text-muted-foreground">Ortalama Kayıp</span>
                <span className="font-medium text-red-500">%{metrics.avgLoss}</span>
              </div>
            </Card>

            <Card className="p-4 space-y-2">
              <div className="flex items-center gap-2">
                <PieChart className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">Kar Faktörü</span>
                <span className="font-medium">{metrics.profitFactor}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Maksimum Düşüş</span>
                <span className="font-medium text-destructive">%{metrics.maxDrawdown}</span>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="strategies">
          <div className="space-y-4">
            {Object.entries(metrics.strategies).map(([strategy, data]) => (
              <Card key={strategy} className="p-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-medium">{strategy}</span>
                  <span className="text-green-500">+{data.profit}%</span>
                </div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm text-muted-foreground">Kazanma Oranı</span>
                  <span className="text-sm">{data.winRate}%</span>
                </div>
                <Progress value={data.winRate} className="h-2" />
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="pnl">
          <Card className="p-4">
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="pnl"
                    stroke="#10B981"
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PerformanceMetrics;