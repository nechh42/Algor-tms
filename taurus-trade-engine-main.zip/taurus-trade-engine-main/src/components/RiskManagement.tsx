import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';
import {
  Shield,
  PieChart,
  TrendingDown,
  BarChart2,
  AlertTriangle,
  RefreshCcw,
  Settings,
  Target
} from 'lucide-react';

const RiskManagement = () => {
  const [stopLossPercentage, setStopLossPercentage] = useState(2);
  const [positionSize, setPositionSize] = useState(1000);
  const [riskRewardRatio, setRiskRewardRatio] = useState(2);

  const portfolioMetrics = {
    totalValue: 125000,
    riskScore: 68,
    diversificationScore: 82,
    volatility: 15.5,
    maxDrawdown: 8.2,
    sharpeRatio: 1.8,
    correlationScore: 75,
    sectors: [
      { name: 'Teknoloji', allocation: 35, risk: 'high' },
      { name: 'Finans', allocation: 25, risk: 'medium' },
      { name: 'Sanayi', allocation: 20, risk: 'medium' },
      { name: 'Enerji', allocation: 15, risk: 'high' },
      { name: 'Sağlık', allocation: 5, risk: 'low' }
    ]
  };

  const handleOptimize = () => {
    const optimizedStopLoss = Math.max(1, stopLossPercentage * 0.8);
    const optimizedPositionSize = Math.min(positionSize * 1.2, portfolioMetrics.totalValue * 0.1);
    
    setStopLossPercentage(optimizedStopLoss);
    setPositionSize(optimizedPositionSize);
    
    toast({
      title: "Risk Optimizasyonu",
      description: "Portföy risk parametreleri optimize edildi.",
    });
  };

  const handleRebalance = () => {
    toast({
      title: "Portföy Dengeleme",
      description: "Portföy yeniden dengeleme önerileri hesaplanıyor...",
    });
  };

  const calculateMaxLoss = () => {
    return (positionSize * stopLossPercentage) / 100;
  };

  const calculatePotentialGain = () => {
    return calculateMaxLoss() * riskRewardRatio;
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-4 space-y-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <h3 className="font-medium">Genel Risk Skoru</h3>
            </div>
            <Badge variant={portfolioMetrics.riskScore > 75 ? "destructive" : "default"}>
              {portfolioMetrics.riskScore}/100
            </Badge>
          </div>
          <Progress value={portfolioMetrics.riskScore} className="h-2" />
          <p className="text-sm text-muted-foreground">
            Portföyünüzün genel risk seviyesi {portfolioMetrics.riskScore > 75 ? "yüksek" : "orta"} düzeyde
          </p>
        </Card>

        <Card className="p-4 space-y-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              <h3 className="font-medium">Stop Loss Ayarları</h3>
            </div>
            <Badge variant="secondary">%{stopLossPercentage}</Badge>
          </div>
          <Slider
            value={[stopLossPercentage]}
            onValueChange={(value) => setStopLossPercentage(value[0])}
            max={10}
            step={0.5}
            className="my-4"
          />
          <p className="text-sm text-muted-foreground">
            Maksimum kayıp: {calculateMaxLoss().toFixed(2)} ₺
          </p>
        </Card>

        <Card className="p-4 space-y-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Settings className="h-5 w-5 text-primary" />
              <h3 className="font-medium">Pozisyon Büyüklüğü</h3>
            </div>
          </div>
          <Input
            type="number"
            value={positionSize}
            onChange={(e) => setPositionSize(Number(e.target.value))}
            className="w-full"
          />
          <p className="text-sm text-muted-foreground">
            Önerilen maksimum: {(portfolioMetrics.totalValue * 0.1).toFixed(2)} ₺
          </p>
        </Card>

        <Card className="p-4 space-y-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <BarChart2 className="h-5 w-5 text-primary" />
              <h3 className="font-medium">Risk/Ödül Oranı</h3>
            </div>
            <Badge>{riskRewardRatio}:1</Badge>
          </div>
          <Slider
            value={[riskRewardRatio]}
            onValueChange={(value) => setRiskRewardRatio(value[0])}
            min={1}
            max={5}
            step={0.5}
            className="my-4"
          />
          <p className="text-sm text-muted-foreground">
            Potansiyel kazanç: {calculatePotentialGain().toFixed(2)} ₺
          </p>
        </Card>
      </div>

      <Card className="p-4">
        <h3 className="font-medium mb-4">Sektör Dağılımı ve Risk Analizi</h3>
        <div className="space-y-4">
          {portfolioMetrics.sectors.map((sector, index) => (
            <div key={index} className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm">{sector.name}</span>
                <div className="flex items-center gap-2">
                  <Badge variant={sector.risk === 'high' ? 'destructive' : 'default'}>
                    {sector.risk === 'high' ? 'Yüksek Risk' : sector.risk === 'medium' ? 'Orta Risk' : 'Düşük Risk'}
                  </Badge>
                  <span className="text-sm font-medium">%{sector.allocation}</span>
                </div>
              </div>
              <Progress value={sector.allocation} className="h-1.5" />
            </div>
          ))}
        </div>
      </Card>

      <div className="flex gap-4">
        <Button 
          className="flex-1" 
          onClick={handleOptimize}
        >
          <AlertTriangle className="mr-2 h-4 w-4" />
          Risk Optimizasyonu
        </Button>
        <Button 
          variant="outline" 
          className="flex-1"
          onClick={handleRebalance}
        >
          <RefreshCcw className="mr-2 h-4 w-4" />
          Portföy Dengeleme
        </Button>
      </div>
    </div>
  );
};

export default RiskManagement;