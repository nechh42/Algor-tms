import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowUpRight, ArrowDownRight, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';

interface Trade {
  id: number;
  type: 'AL' | 'SAT';
  symbol: string;
  price: number;
  amount: number;
  timestamp: string;
  pnl?: number;
  market: 'SPOT' | 'VIOP';
  contractSize?: number;
  leverage?: number;
}

const TradeHistory = () => {
  const [activeTab, setActiveTab] = useState<'SPOT' | 'VIOP'>('SPOT');

  const trades: Trade[] = [
    {
      id: 1,
      type: 'AL',
      symbol: 'THYAO',
      price: 85.40,
      amount: 100,
      timestamp: '2024-04-10 14:30',
      pnl: 2.5,
      market: 'SPOT'
    },
    {
      id: 2,
      type: 'SAT',
      symbol: 'GARAN',
      price: 44.80,
      amount: 200,
      timestamp: '2024-04-10 14:25',
      pnl: -1.2,
      market: 'SPOT'
    },
    {
      id: 3,
      type: 'AL',
      symbol: 'F_XU0300424',
      price: 9850,
      amount: 1,
      timestamp: '2024-04-10 15:10',
      pnl: 1.8,
      market: 'VIOP',
      contractSize: 100,
      leverage: 10
    }
  ];

  const filteredTrades = trades.filter(trade => trade.market === activeTab);

  const getDailyReport = () => {
    const totalTrades = trades.length;
    const profitableTrades = trades.filter(t => (t.pnl || 0) > 0).length;
    const totalPnl = trades.reduce((sum, t) => sum + (t.pnl || 0), 0);
    
    return {
      totalTrades,
      profitableTrades,
      successRate: ((profitableTrades / totalTrades) * 100).toFixed(1),
      totalPnl: totalPnl.toFixed(2)
    };
  };

  const report = getDailyReport();

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl font-semibold">İşlem Geçmişi</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={(value: 'SPOT' | 'VIOP') => setActiveTab(value)}>
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="SPOT">SPOT İşlemler</TabsTrigger>
            <TabsTrigger value="VIOP">VİOP İşlemler</TabsTrigger>
          </TabsList>

          <div className="mb-4 grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="p-3">
              <div className="text-sm text-muted-foreground">Toplam İşlem</div>
              <div className="text-2xl font-bold">{report.totalTrades}</div>
            </Card>
            <Card className="p-3">
              <div className="text-sm text-muted-foreground">Karlı İşlem</div>
              <div className="text-2xl font-bold">{report.profitableTrades}</div>
            </Card>
            <Card className="p-3">
              <div className="text-sm text-muted-foreground">Başarı Oranı</div>
              <div className="text-2xl font-bold">%{report.successRate}</div>
            </Card>
            <Card className="p-3">
              <div className="text-sm text-muted-foreground">Toplam PnL</div>
              <div className={`text-2xl font-bold ${Number(report.totalPnl) >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                %{report.totalPnl}
              </div>
            </Card>
          </div>

          <ScrollArea className="h-[400px]">
            <div className="space-y-3">
              {filteredTrades.map((trade) => (
                <div
                  key={trade.id}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    {trade.type === 'AL' ? (
                      <ArrowUpRight className="h-4 w-4 text-green-500" />
                    ) : (
                      <ArrowDownRight className="h-4 w-4 text-red-500" />
                    )}
                    <div>
                      <div className="font-medium">{trade.symbol}</div>
                      <div className="text-sm text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {trade.timestamp}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">
                      {trade.price.toFixed(2)} TL x {trade.amount}
                      {trade.market === 'VIOP' && (
                        <span className="text-sm text-muted-foreground">
                          {' '}(x{trade.leverage})
                        </span>
                      )}
                    </div>
                    {trade.pnl !== undefined && (
                      <Badge variant={trade.pnl >= 0 ? "default" : "destructive"}>
                        {trade.pnl >= 0 ? '+' : ''}{trade.pnl}%
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default TradeHistory;