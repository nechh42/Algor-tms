import React from 'react';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';
import { Power, ShieldAlert } from 'lucide-react';
import NotificationService from '@/services/NotificationService';
import { TradingService } from '@/services/TradingService';

interface AutoTradeControlsProps {
  isAutoTrading: boolean;
  onAutoTradeToggle: () => void;
  onEmergencyStop: () => void;
}

const AutoTradeControls = ({
  isAutoTrading,
  onAutoTradeToggle,
  onEmergencyStop
}: AutoTradeControlsProps) => {
  const handleEmergencyStop = () => {
    onEmergencyStop();
    NotificationService.riskAlert('Tüm pozisyonlar acil durum protokolü ile kapatıldı.', 'high');
    toast({
      title: "Acil Durum",
      description: "Tüm pozisyonlar kapatıldı",
      variant: "destructive",
    });
  };

  return (
    <div className="flex items-center gap-4">
      <Button 
        variant="destructive"
        onClick={handleEmergencyStop}
        className="gap-2"
      >
        <ShieldAlert className="h-4 w-4" />
        Acil Durum
      </Button>
      <Button 
        variant={isAutoTrading ? "destructive" : "default"}
        onClick={onAutoTradeToggle}
        className="min-w-[120px]"
      >
        <Power className="mr-2 h-4 w-4" />
        {isAutoTrading ? 'Durdur' : 'Başlat'}
      </Button>
    </div>
  );
};

export default AutoTradeControls;