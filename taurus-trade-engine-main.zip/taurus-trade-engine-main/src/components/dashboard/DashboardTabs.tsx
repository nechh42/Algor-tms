import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LineChart, Brain, History, BarChart2 } from 'lucide-react';
import { Card } from '@/components/ui/card';
import TradingChart from '../TradingChart';
import IndicatorsPanel from '../IndicatorsPanel';
import RiskManagement from '../RiskManagement';
import TradingStrategies from '../TradingStrategies';
import PositionPanel from '../PositionPanel';
import TradeHistory from '../TradeHistory';
import MLPrediction from '../MLPrediction';
import SentimentAnalysis from '../SentimentAnalysis';
import PerformanceMetrics from '../PerformanceMetrics';
import ViopPanel from '../trading/ViopPanel';
import { Button } from '../ui/button';
import { AlertTriangle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface DashboardTabsProps {
  marketData: Array<{
    date: string;
    price: number;
    volume?: number;
  }>;
}

const DashboardTabs = ({ marketData }: DashboardTabsProps) => {
  return (
    <Tabs defaultValue="trading" className="w-full">
      <TabsList className="grid w-full grid-cols-4 mb-4">
        <TabsTrigger value="trading" className="gap-2">
          <BarChart2 className="h-4 w-4" />
          İşlemler
        </TabsTrigger>
        <TabsTrigger value="market" className="gap-2">
          <LineChart className="h-4 w-4" />
          Piyasa
        </TabsTrigger>
        <TabsTrigger value="analysis" className="gap-2">
          <Brain className="h-4 w-4" />
          Analiz
        </TabsTrigger>
        <TabsTrigger value="history" className="gap-2">
          <History className="h-4 w-4" />
          Geçmiş
        </TabsTrigger>
      </TabsList>

      <div className="space-y-4">
        <TabsContent value="trading" className="mt-0">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card className="lg:col-span-2 p-4">
              <h2 className="text-xl font-semibold mb-4">Açık Pozisyonlar</h2>
              <PositionPanel />
            </Card>
            <Card className="p-4">
              <h2 className="text-xl font-semibold mb-4">İşlem Geçmişi</h2>
              <TradeHistory />
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="market" className="mt-0">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card className="col-span-2 p-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Piyasa Görünümü</h2>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => toast({
                    title: "Uyarı",
                    description: "Yüksek volatilite tespit edildi!",
                    variant: "destructive",
                  })}
                >
                  <AlertTriangle className="mr-2 h-4 w-4" />
                  Risk Uyarıları
                </Button>
              </div>
              <TradingChart data={marketData} />
            </Card>
            <Card className="p-4">
              <h2 className="text-xl font-semibold mb-4">Teknik Göstergeler</h2>
              <IndicatorsPanel data={marketData} />
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analysis" className="mt-0">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <MLPrediction />
            <SentimentAnalysis />
            <Card className="col-span-2 p-4">
              <h2 className="text-xl font-semibold mb-4">Risk Yönetimi</h2>
              <RiskManagement />
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history" className="mt-0">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card className="lg:col-span-2 p-4">
              <h2 className="text-xl font-semibold mb-4">Performans Metrikleri</h2>
              <PerformanceMetrics />
            </Card>
            <Card className="p-4">
              <h2 className="text-xl font-semibold mb-4">Ticaret Stratejileri</h2>
              <TradingStrategies data={marketData} />
            </Card>
          </div>
        </TabsContent>
      </div>
    </Tabs>
  );
};

export default DashboardTabs;