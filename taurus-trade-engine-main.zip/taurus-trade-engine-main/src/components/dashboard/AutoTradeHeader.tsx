import React from 'react';
import { Button } from '@/components/ui/button';
import { Settings2, ShieldAlert, Power, TestTube2 } from 'lucide-react';
import NotificationCenter from '../NotificationCenter';
import { toast } from '@/hooks/use-toast';
import NotificationService from '@/services/NotificationService';

interface AutoTradeHeaderProps {
  isAutoTrading: boolean;
  onAutoTradeToggle: () => void;
  onEmergencyStop: () => void;
  isDemoMode: boolean;
  onDemoModeToggle: () => void;
}

const AutoTradeHeader = ({ 
  isAutoTrading, 
  onAutoTradeToggle, 
  onEmergencyStop,
  isDemoMode,
  onDemoModeToggle
}: AutoTradeHeaderProps) => {
  return (
    <div className="flex justify-between items-center">
      <div className="space-y-1">
        <h1 className="text-3xl font-bold text-foreground">
          Taurus Trading Bot
          {isDemoMode && (
            <span className="ml-2 text-sm font-normal bg-yellow-100 text-yellow-800 px-2 py-1 rounded">
              Demo Modu
            </span>
          )}
        </h1>
        <p className="text-muted-foreground">Gelişmiş Otomatik İşlem Platformu</p>
      </div>
      <div className="flex items-center gap-4">
        <NotificationCenter />
        <Button
          variant="outline"
          onClick={onDemoModeToggle}
          className={`gap-2 ${isDemoMode ? 'bg-yellow-100 hover:bg-yellow-200 border-yellow-300' : ''}`}
        >
          <TestTube2 className="h-4 w-4" />
          {isDemoMode ? 'Demo Modu Aktif' : 'Demo Modu'}
        </Button>
        <Button 
          variant="destructive"
          onClick={onEmergencyStop}
          className="gap-2"
        >
          <ShieldAlert className="h-4 w-4" />
          Acil Durum
        </Button>
        <Button 
          variant="outline"
          onClick={() => {
            NotificationService.systemNotification("Bot ayarları güncellendi");
            toast({
              title: "Ayarlar",
              description: "Bot ayarları güncellendi",
            });
          }}
        >
          <Settings2 className="mr-2 h-4 w-4" />
          Ayarlar
        </Button>
        <Button 
          variant={isAutoTrading ? "destructive" : "default"}
          onClick={onAutoTradeToggle}
          className="min-w-[120px]"
        >
          <Power className="mr-2 h-4 w-4" />
          {isAutoTrading ? 'Durdur' : 'Başlat'}
        </Button>
      </div>
    </div>
  );
};

export default AutoTradeHeader;