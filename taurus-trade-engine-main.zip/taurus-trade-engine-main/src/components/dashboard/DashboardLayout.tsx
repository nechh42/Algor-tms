import React from 'react';
import DashboardTabs from './DashboardTabs';
import AutoTradeHeader from './AutoTradeHeader';
import AccountOverview from '../AccountOverview';
import AccountIntegration from '../AccountIntegration';
import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Brain, TrendingUp, BarChart2, Clock } from 'lucide-react';

interface DashboardLayoutProps {
  isAutoTrading: boolean;
  onAutoTradeToggle: () => void;
  onEmergencyStop: () => void;
  marketData: Array<{ date: string; price: number; volume?: number }>;
  isDemoMode: boolean;
  onDemoModeToggle: () => void;
  autoSettings: {
    riskManagement: boolean;
    gridTrading: boolean;
    positionManagement: boolean;
    autoSchedule: boolean;
  };
  onAutoSettingsChange: (settings: any) => void;
  isAutoScheduleEnabled: boolean;
  selectedMarkets: string[];
}

const DashboardLayout = ({
  isAutoTrading,
  onAutoTradeToggle,
  onEmergencyStop,
  marketData,
  isDemoMode,
  onDemoModeToggle,
  autoSettings,
  onAutoSettingsChange,
  isAutoScheduleEnabled,
  selectedMarkets
}: DashboardLayoutProps) => {
  const botPerformance = {
    spotSuccessRate: 78.5,
    viopSuccessRate: 72.3,
    totalTrades: 156,
    profitableTrades: 118,
    avgProfitPerTrade: 2.4
  };

  return (
    <div className="container mx-auto p-4 space-y-4">
      {/* Üst Bölüm - Hesap Durumu ve Entegrasyon */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <div className="lg:col-span-3">
          <AccountOverview />
        </div>
        <div className="lg:col-span-1">
          <AccountIntegration />
        </div>
      </div>

      {/* Bot Kontrolleri */}
      <AutoTradeHeader 
        isAutoTrading={isAutoTrading}
        onAutoTradeToggle={onAutoTradeToggle}
        onEmergencyStop={onEmergencyStop}
        isDemoMode={isDemoMode}
        onDemoModeToggle={onDemoModeToggle}
      />
      
      {/* Ana İçerik Bölümü */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Sol Kenar - Bot Ayarları */}
        <Card className="p-4">
          <h2 className="text-lg font-semibold mb-4">Bot Ayarları</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="demoMode">Demo Mod</Label>
              <Switch
                id="demoMode"
                checked={isDemoMode}
                onCheckedChange={onDemoModeToggle}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="autoTrading">Otomatik İşlem</Label>
              <Switch
                id="autoTrading"
                checked={isAutoTrading}
                onCheckedChange={onAutoTradeToggle}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="autoSchedule" className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Otomatik Çalışma (09:45-18:15)
              </Label>
              <Switch
                id="autoSchedule"
                checked={autoSettings.autoSchedule}
                onCheckedChange={(checked) => {
                  onAutoSettingsChange({
                    ...autoSettings,
                    autoSchedule: checked
                  });
                }}
              />
            </div>

            <div className="mt-6 space-y-3">
              <h3 className="text-sm font-medium">Bot Performansı</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center">
                  <span>SPOT Başarı:</span>
                  <Badge variant="default">%{botPerformance.spotSuccessRate}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>VİOP Başarı:</span>
                  <Badge variant="default">%{botPerformance.viopSuccessRate}</Badge>
                </div>
                {isAutoScheduleEnabled && (
                  <div className="mt-2 text-xs text-green-600 flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Otomatik çalışma aktif
                  </div>
                )}
              </div>
            </div>
          </div>
        </Card>
        
        {/* Ana İçerik - Dashboard Tabs */}
        <div className="lg:col-span-3">
          <DashboardTabs marketData={marketData} />
        </div>
      </div>
    </div>
  );
};

export default DashboardLayout;