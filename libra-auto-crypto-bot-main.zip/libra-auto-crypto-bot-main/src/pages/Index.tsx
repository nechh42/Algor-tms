import React from 'react';
import TradingView from '@/components/TradingView';
import TradingControls from '@/components/TradingControls';
import Indicators from '@/components/Indicators';
import ApiKeyForm from '@/components/ApiKeyForm';
import MultiCoinView from '@/components/MultiCoinView';
import PortfolioView from '@/components/PortfolioView';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { Moon, Sun } from 'lucide-react';

const Index = () => {
  const { theme, setTheme } = useTheme();

  return (
    <div className="min-h-screen bg-background text-foreground p-2 sm:p-4 transition-colors">
      <div className="max-w-7xl mx-auto space-y-4">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold">Libra Trading Bot</h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="ml-auto"
          >
            {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
        </div>
        
        <div className="mb-6">
          <ApiKeyForm />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-2 sm:gap-4">
          <div className="lg:col-span-3 space-y-2 sm:space-y-4">
            <TradingView />
          </div>
          <div className="space-y-2 sm:space-y-4">
            <TradingControls />
            <Indicators />
            <PortfolioView />
          </div>
        </div>

        <div className="mt-4 sm:mt-8">
          <h2 className="text-xl sm:text-2xl font-bold mb-2 sm:mb-4">Çoklu Coin Analizi</h2>
          <MultiCoinView />
        </div>
      </div>
    </div>
  );
};

export default Index;