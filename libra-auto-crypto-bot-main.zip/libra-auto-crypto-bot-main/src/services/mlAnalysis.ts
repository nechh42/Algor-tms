import { binanceService } from './binance';

export interface MLPrediction {
  price: number;
  confidence: number;
  timeframe: string;
  features: {
    trend: string;
    momentum: number;
    volatility: number;
    support: number;
    resistance: number;
  };
}

interface KlineData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export class MLAnalysisService {
  static async trainModel(symbol: string): Promise<void> {
    try {
      const historicalData = await binanceService.getKlines(symbol, '1h', 1000);
      console.log('Model eğitimi başladı:', symbol);
      console.log('Veri sayısı:', historicalData.length);
      
      await this.simulateTraining();
    } catch (error) {
      console.error('Model eğitim hatası:', error);
    }
  }

  private static async simulateTraining(): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, 2000));
  }

  static async getPrediction(symbol: string): Promise<MLPrediction> {
    const klines = await binanceService.getKlines(symbol, '1h', 100);
    const prices = klines.map((value: KlineData) => value.close);
    
    const lastPrice = prices[prices.length - 1];
    const sma20 = this.calculateSMA(prices, 20);
    const volatility = this.calculateVolatility(prices);
    
    const support = Math.min(...prices.slice(-20)) * 0.995;
    const resistance = Math.max(...prices.slice(-20)) * 1.005;

    return {
      price: lastPrice * (1 + (Math.random() * 0.02 - 0.01)),
      confidence: 0.75 + (Math.random() * 0.2),
      timeframe: '4h',
      features: {
        trend: lastPrice > sma20 ? 'YUKARI' : 'AŞAĞI',
        momentum: this.calculateMomentum(prices),
        volatility,
        support,
        resistance
      }
    };
  }

  private static calculateSMA(prices: number[], period: number): number {
    const slice = prices.slice(-period);
    return slice.reduce((sum, price) => sum + price, 0) / period;
  }

  private static calculateVolatility(prices: number[]): number {
    const returns = prices.slice(1).map((price, i) => 
      (price - prices[i]) / prices[i]
    );
    return Math.sqrt(returns.reduce((sum, ret) => sum + ret * ret, 0) / returns.length);
  }

  private static calculateMomentum(prices: number[]): number {
    const period = 14;
    return (prices[prices.length - 1] / prices[prices.length - period - 1]) - 1;
  }
}