import { binanceService } from './binance';
import { SMA, RSI, MACD, BollingerBands } from 'technicalindicators';

export interface TechnicalAnalysisResult {
  trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  confidence: number;
  signals: {
    sma: number;
    rsi: number;
    macd: {
      histogram: number;
      signal: number;
      macd: number;
    };
    bb: {
      upper: number;
      middle: number;
      lower: number;
    };
  };
}

interface KlineData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export class TechnicalAnalysisService {
  static async analyze(symbol: string): Promise<TechnicalAnalysisResult> {
    const klines = await binanceService.getKlines(symbol, '1h', 100);
    const prices = klines.map((value: KlineData) => value.close);
    
    const sma = SMA.calculate({ period: 20, values: prices });
    const rsi = RSI.calculate({ period: 14, values: prices });
    const macd = MACD.calculate({
      fastPeriod: 12,
      slowPeriod: 26,
      signalPeriod: 9,
      values: prices,
      SimpleMAOscillator: false,
      SimpleMASignal: false
    });
    const bb = BollingerBands.calculate({
      period: 20,
      values: prices,
      stdDev: 2
    });

    const lastPrice = prices[prices.length - 1];
    const lastBB = bb[bb.length - 1];
    const lastRSI = rsi[rsi.length - 1];
    const lastMACD = macd[macd.length - 1];

    let trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
    let confidence = 0;

    if (lastPrice > lastBB.upper && lastRSI > 70 && lastMACD.histogram < 0) {
      trend = 'BEARISH';
      confidence = 0.8;
    } else if (lastPrice < lastBB.lower && lastRSI < 30 && lastMACD.histogram > 0) {
      trend = 'BULLISH';
      confidence = 0.8;
    }

    return {
      trend,
      confidence,
      signals: {
        sma: sma[sma.length - 1],
        rsi: lastRSI,
        macd: {
          histogram: lastMACD.histogram,
          signal: lastMACD.signal,
          macd: lastMACD.MACD
        },
        bb: lastBB
      }
    };
  }
}