interface RiskParameters {
  accountBalance: number;
  maxPositionSize: number;
  maxDrawdown: number;
  stopLossPercent: number;
  takeProfitPercent: number;
}

interface PositionSize {
  amount: number;
  leverage: number;
  stopLoss: number;
  takeProfit: number;
}

export class RiskManagementService {
  private static readonly DEFAULT_PARAMS: RiskParameters = {
    accountBalance: 10000,
    maxPositionSize: 0.1,
    maxDrawdown: 0.02,
    stopLossPercent: 0.02,
    takeProfitPercent: 0.04
  };

  static calculatePositionSize(
    price: number,
    volatility: number,
    params: Partial<RiskParameters> = {}
  ): PositionSize {
    const settings = { ...this.DEFAULT_PARAMS, ...params };
    
    // Volatiliteye göre pozisyon büyüklüğünü ayarla
    const riskAdjustment = Math.max(0.5, 1 - volatility);
    const maxPosition = settings.accountBalance * settings.maxPositionSize * riskAdjustment;
    
    // Kaldıraç hesaplama
    const leverage = Math.min(Math.floor(1 / volatility), 20);
    
    // Stop loss ve take profit hesaplama
    const stopLossPercent = settings.stopLossPercent * (1 + volatility);
    const takeProfitPercent = settings.takeProfitPercent * (1 + volatility);
    
    const amount = maxPosition / price;
    const stopLoss = price * (1 - stopLossPercent);
    const takeProfit = price * (1 + takeProfitPercent);

    return {
      amount,
      leverage,
      stopLoss,
      takeProfit
    };
  }

  static validateRisk(
    positions: any[],
    accountBalance: number,
    maxDrawdown: number = this.DEFAULT_PARAMS.maxDrawdown
  ): {
    isValid: boolean;
    message: string;
    currentRisk: number;
  } {
    const totalRisk = positions.reduce((sum, pos) => {
      const positionValue = pos.amount * pos.currentPrice;
      const potentialLoss = positionValue * pos.risk;
      return sum + potentialLoss;
    }, 0);

    const currentRisk = totalRisk / accountBalance;
    const isValid = currentRisk <= maxDrawdown;

    return {
      isValid,
      message: isValid ? 
        'Risk seviyeleri kabul edilebilir durumda' : 
        'Toplam risk çok yüksek, pozisyonları azaltın',
      currentRisk
    };
  }
}