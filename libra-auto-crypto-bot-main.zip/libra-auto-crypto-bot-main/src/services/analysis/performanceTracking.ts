export interface PerformanceMetrics {
  trades: number;
  successfulTrades: number;
  totalProfit: number;
  avgProfit: number;
  successRate: number;
}

export class PerformanceTrackingService {
  private static metrics: Map<string, PerformanceMetrics> = new Map();

  static loadFromStorage() {
    const savedData = localStorage.getItem('tradingPerformance');
    if (savedData) {
      this.metrics = new Map(JSON.parse(savedData));
    }
  }

  static saveToStorage() {
    localStorage.setItem('tradingPerformance', 
      JSON.stringify(Array.from(this.metrics.entries())));
  }

  static updateMetrics(symbol: string, profit: number) {
    const current = this.metrics.get(symbol) || {
      trades: 0,
      successfulTrades: 0,
      totalProfit: 0,
      avgProfit: 0,
      successRate: 0
    };

    current.trades++;
    if (profit > 0) {
      current.successfulTrades++;
    }
    current.totalProfit += profit;
    current.avgProfit = current.totalProfit / current.trades;
    current.successRate = current.successfulTrades / current.trades;

    this.metrics.set(symbol, current);
    this.saveToStorage();
  }

  static getMetrics(symbol: string): PerformanceMetrics {
    return this.metrics.get(symbol) || {
      trades: 0,
      successfulTrades: 0,
      totalProfit: 0,
      avgProfit: 0,
      successRate: 0
    };
  }
}