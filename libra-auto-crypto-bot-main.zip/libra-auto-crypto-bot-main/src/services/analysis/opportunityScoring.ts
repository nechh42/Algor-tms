import { SentimentService } from '../sentiment';

export interface OpportunityScore {
  score: number;
  reason: string;
  profitPotential: number;
  risk: number;
}

export class OpportunityScoringService {
  static calculateScore(
    technicalSignals: any,
    mlPrediction: any,
    sentiment: any,
    volumeData: any
  ): OpportunityScore {
    let score = 50;
    let reasons: string[] = [];
    let profitPotential = 0;
    let risk = 0;

    // RSI Analizi
    if (technicalSignals.rsi < 30) {
      score += 15;
      reasons.push("Aşırı satım bölgesi");
      profitPotential += 0.2;
    } else if (technicalSignals.rsi > 70) {
      score -= 15;
      reasons.push("Aşırı alım bölgesi");
      risk += 0.2;
    }

    // MACD Analizi
    if (technicalSignals.macd.histogram > 0 && technicalSignals.macd.histogram > technicalSignals.macd.signal) {
      score += 10;
      reasons.push("Güçlü yükseliş sinyali");
      profitPotential += 0.15;
    }

    // Yapay Zeka Tahmin Analizi
    if (mlPrediction.confidence > 0.8) {
      if (mlPrediction.price > parseFloat(volumeData.lastPrice)) {
        score += 20;
        reasons.push("AI yükseliş öngörüyor");
        profitPotential += 0.25;
      }
    }

    // Sosyal Sentiment Analizi
    if (sentiment.sentiment > 0.6) {
      score += 8;
      reasons.push("Pozitif topluluk sentiment'i");
      profitPotential += 0.1;
    }

    return {
      score: Math.max(0, Math.min(100, score)),
      reason: reasons.join(", "),
      profitPotential: Math.min(1, profitPotential),
      risk: Math.min(1, risk)
    };
  }
}