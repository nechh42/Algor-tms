import { binanceService } from '../binance';
import { technicalIndicators } from '../analysis';

export interface TechnicalSignals {
  rsi: number;
  macd: any;
  bb: any;
}

export class TechnicalAnalysisService {
  static async analyzeCoin(symbol: string): Promise<TechnicalSignals> {
    const historicalData = await binanceService.getKlines(symbol, '1h', 100);
    const prices = historicalData.map(candle => candle.close);
    
    const rsi = technicalIndicators.calculateRSI(prices);
    const macd = technicalIndicators.calculateMACD(prices);
    const bb = technicalIndicators.calculateBollingerBands(prices);

    return {
      rsi: rsi[rsi.length - 1],
      macd: macd[macd.length - 1],
      bb: bb[bb.length - 1]
    };
  }
}