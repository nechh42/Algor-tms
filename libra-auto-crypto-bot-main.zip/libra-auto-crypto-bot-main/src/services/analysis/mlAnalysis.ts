import { binanceService } from '../binance';

interface MLPrediction {
  price: number;
  trend: 'UP' | 'DOWN' | 'SIDEWAYS';
  confidence: number;
  timeframe: string;
}

export class MLAnalysisService {
  static async predictPrice(symbol: string, timeframe: string = '1h'): Promise<MLPrediction> {
    const klines = await binanceService.getKlines(symbol, timeframe, 100);
    const prices = klines.map(k => k.close);
    const volumes = klines.map(k => k.volume);
    
    // Basit trend analizi
    const lastPrice = prices[prices.length - 1];
    const sma20 = this.calculateSMA(prices, 20);
    const sma50 = this.calculateSMA(prices, 50);
    
    // Trend belirleme
    let trend: 'UP' | 'DOWN' | 'SIDEWAYS' = 'SIDEWAYS';
    if (sma20 > sma50) {
      trend = 'UP';
    } else if (sma20 < sma50) {
      trend = 'DOWN';
    }

    // Basit fiyat tahmini
    const predictedChange = this.calculatePredictedChange(prices, volumes);
    const predictedPrice = lastPrice * (1 + predictedChange);
    
    // Güven skoru hesaplama
    const confidence = this.calculateConfidence(prices, volumes, trend);

    return {
      price: predictedPrice,
      trend,
      confidence,
      timeframe
    };
  }

  private static calculateSMA(prices: number[], period: number): number {
    const slice = prices.slice(-period);
    return slice.reduce((sum, price) => sum + price, 0) / period;
  }

  private static calculatePredictedChange(prices: number[], volumes: number[]): number {
    const recentPrices = prices.slice(-5);
    const recentVolumes = volumes.slice(-5);
    
    let weightedChange = 0;
    let totalWeight = 0;
    
    for (let i = 1; i < recentPrices.length; i++) {
      const priceChange = (recentPrices[i] - recentPrices[i-1]) / recentPrices[i-1];
      const volumeWeight = recentVolumes[i] / Math.max(...recentVolumes);
      weightedChange += priceChange * volumeWeight;
      totalWeight += volumeWeight;
    }
    
    return weightedChange / totalWeight;
  }

  private static calculateConfidence(prices: number[], volumes: number[], trend: string): number {
    const volatility = this.calculateVolatility(prices);
    const volumeStrength = this.calculateVolumeStrength(volumes);
    const trendStrength = trend === 'SIDEWAYS' ? 0.5 : 0.8;
    
    return Math.min(0.95, (trendStrength + volumeStrength) / (2 * volatility));
  }

  private static calculateVolatility(prices: number[]): number {
    const returns = prices.slice(1).map((price, i) => 
      Math.log(price / prices[i])
    );
    const meanReturn = returns.reduce((sum, ret) => sum + ret, 0) / returns.length;
    const squaredDiffs = returns.map(ret => Math.pow(ret - meanReturn, 2));
    return Math.sqrt(squaredDiffs.reduce((sum, diff) => sum + diff, 0) / returns.length);
  }

  private static calculateVolumeStrength(volumes: number[]): number {
    const recentVolumes = volumes.slice(-5);
    const avgVolume = volumes.reduce((sum, vol) => sum + vol, 0) / volumes.length;
    const recentAvg = recentVolumes.reduce((sum, vol) => sum + vol, 0) / recentVolumes.length;
    
    return Math.min(1, recentAvg / avgVolume);
  }
}