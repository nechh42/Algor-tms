import { binanceService } from '../binance';

export interface VolumeProfile {
  buyVolume: number;
  sellVolume: number;
  ratio: number;
  trend: 'ACCUMULATION' | 'DISTRIBUTION' | 'NEUTRAL';
  strength: number;
}

export class EnhancedVolumeAnalysis {
  static async analyzeVolume(symbol: string, timeframe: string = '1h'): Promise<VolumeProfile> {
    const klines = await binanceService.getKlines(symbol, timeframe, 24);
    
    let buyVolume = 0;
    let sellVolume = 0;
    
    klines.forEach(candle => {
      if (candle.close > candle.open) {
        buyVolume += candle.volume;
      } else {
        sellVolume += candle.volume;
      }
    });

    const ratio = buyVolume / (buyVolume + sellVolume);
    const strength = this.calculateVolumeStrength(klines);
    
    let trend: 'ACCUMULATION' | 'DISTRIBUTION' | 'NEUTRAL' = 'NEUTRAL';
    if (ratio > 0.6 && strength > 0.7) {
      trend = 'ACCUMULATION';
    } else if (ratio < 0.4 && strength > 0.7) {
      trend = 'DISTRIBUTION';
    }

    return {
      buyVolume,
      sellVolume,
      ratio,
      trend,
      strength
    };
  }

  private static calculateVolumeStrength(klines: any[]): number {
    const volumes = klines.map(k => k.volume);
    const avgVolume = volumes.reduce((sum, vol) => sum + vol, 0) / volumes.length;
    const recentVolumes = volumes.slice(-6);
    const recentAvg = recentVolumes.reduce((sum, vol) => sum + vol, 0) / recentVolumes.length;
    
    return Math.min(1, recentAvg / avgVolume);
  }

  static async detectVolumeSpikes(symbol: string, timeframe: string = '1h'): Promise<{
    hasSpike: boolean;
    spikeSize: number;
    direction: 'UP' | 'DOWN' | 'NONE';
  }> {
    const klines = await binanceService.getKlines(symbol, timeframe, 24);
    const volumes = klines.map(k => k.volume);
    const prices = klines.map(k => k.close);
    
    const avgVolume = volumes.slice(0, -1).reduce((sum, vol) => sum + vol, 0) / (volumes.length - 1);
    const lastVolume = volumes[volumes.length - 1];
    const volumeRatio = lastVolume / avgVolume;
    
    const hasSpike = volumeRatio > 2;
    const lastPrice = prices[prices.length - 1];
    const prevPrice = prices[prices.length - 2];
    
    let direction: 'UP' | 'DOWN' | 'NONE' = 'NONE';
    if (hasSpike) {
      direction = lastPrice > prevPrice ? 'UP' : 'DOWN';
    }

    return {
      hasSpike,
      spikeSize: volumeRatio,
      direction
    };
  }
}