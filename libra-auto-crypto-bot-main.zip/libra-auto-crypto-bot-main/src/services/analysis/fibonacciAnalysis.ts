interface FibonacciLevels {
  extension: number[];
  retracement: number[];
  pivot: number;
  support1: number;
  support2: number;
  resistance1: number;
  resistance2: number;
}

export class FibonacciAnalysisService {
  static calculateLevels(high: number, low: number, close: number): FibonacciLevels {
    const difference = high - low;
    
    // Fibonacci retracement seviyeleri (0.236, 0.382, 0.5, 0.618, 0.786)
    const retracement = [
      high - difference * 0.236,
      high - difference * 0.382,
      high - difference * 0.5,
      high - difference * 0.618,
      high - difference * 0.786
    ];

    // Fibonacci extension seviyeleri (1.272, 1.618, 2.618, 3.618, 4.236)
    const extension = [
      low + difference * 1.272,
      low + difference * 1.618,
      low + difference * 2.618,
      low + difference * 3.618,
      low + difference * 4.236
    ];

    // Pivot noktaları hesaplama
    const pivot = (high + low + close) / 3;
    const support1 = (pivot * 2) - high;
    const support2 = pivot - (high - low);
    const resistance1 = (pivot * 2) - low;
    const resistance2 = pivot + (high - low);

    return {
      retracement,
      extension,
      pivot,
      support1,
      support2,
      resistance1,
      resistance2
    };
  }

  static analyzeTrend(currentPrice: number, levels: FibonacciLevels): {
    trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    strength: number;
    nextTarget: number;
  } {
    let trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
    let strength = 0;
    let nextTarget = currentPrice;

    if (currentPrice > levels.pivot) {
      trend = 'BULLISH';
      strength = (currentPrice - levels.pivot) / (levels.resistance1 - levels.pivot);
      nextTarget = levels.resistance1;
    } else if (currentPrice < levels.pivot) {
      trend = 'BEARISH';
      strength = (levels.pivot - currentPrice) / (levels.pivot - levels.support1);
      nextTarget = levels.support1;
    }

    return {
      trend,
      strength: Math.min(Math.max(strength, 0), 1),
      nextTarget
    };
  }
}