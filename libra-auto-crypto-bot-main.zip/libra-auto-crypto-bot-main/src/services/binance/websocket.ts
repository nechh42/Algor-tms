import { TickerData } from './types';

export class BinanceWebSocketService {
  private ws: WebSocket | null = null;
  private callbacks: Map<string, Function> = new Map();

  constructor() {
    this.initializeWebSocket();
  }

  private initializeWebSocket() {
    this.ws = new WebSocket('wss://stream.binance.com:9443/ws');
    
    this.ws.onopen = () => {
      console.log('WebSocket Bağlandı');
      this.subscribeTicker('BTCUSDT');
    };

    this.ws.onmessage = (event) => {
      const data = JSON.parse(event.data) as TickerData;
      if (data.e === '24hrTicker') {
        this.handleTickerData(data);
      }
    };

    this.ws.onerror = (error) => {
      console.error('WebSocket Hatası:', error);
    };

    this.ws.onclose = () => {
      console.log('WebSocket Bağlantısı Kesildi');
      setTimeout(() => this.initializeWebSocket(), 5000);
    };
  }

  subscribeTicker(symbol: string) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      const subscribeMessage = {
        method: 'SUBSCRIBE',
        params: [`${symbol.toLowerCase()}@ticker`],
        id: 1
      };
      this.ws.send(JSON.stringify(subscribeMessage));
    }
  }

  private handleTickerData(data: TickerData) {
    const price = {
      symbol: data.s,
      price: data.c,
      volume: data.v,
      priceChange: data.p,
      priceChangePercent: data.P
    };

    this.callbacks.forEach(callback => callback(price));
  }

  onPriceUpdate(callback: Function) {
    this.callbacks.set(callback.toString(), callback);
  }

  removeCallback(callback: Function) {
    this.callbacks.delete(callback.toString());
  }
}