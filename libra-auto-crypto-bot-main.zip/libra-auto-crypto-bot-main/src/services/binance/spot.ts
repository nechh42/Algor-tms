export class BinanceSpotService {
  private apiKey: string | null = null;
  private apiSecret: string | null = null;
  private baseUrl = 'https://api.binance.com';

  constructor(apiKey?: string, apiSecret?: string) {
    if (apiKey && apiSecret) {
      this.apiKey = apiKey;
      this.apiSecret = apiSecret;
    }
  }

  async getPrice(symbol: string) {
    const response = await fetch(`${this.baseUrl}/api/v3/ticker/price?symbol=${symbol}`);
    if (!response.ok) {
      throw new Error('Price data fetch failed');
    }
    return response.json();
  }

  async get24hrStats(symbol: string) {
    const response = await fetch(`${this.baseUrl}/api/v3/ticker/24hr?symbol=${symbol}`);
    if (!response.ok) {
      throw new Error('24hr stats fetch failed');
    }
    return response.json();
  }

  async getAccountInfo() {
    if (!this.apiKey || !this.apiSecret) {
      throw new Error('API credentials not set');
    }
    // Implement account info fetch logic here
    return {};
  }

  async getKlines(symbol: string, interval: string, limit: number) {
    const response = await fetch(
      `${this.baseUrl}/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`
    );
    
    if (!response.ok) {
      throw new Error('Klines data fetch failed');
    }

    const data = await response.json();
    return data.map((k: any[]) => ({
      time: k[0],
      open: parseFloat(k[1]),
      high: parseFloat(k[2]),
      low: parseFloat(k[3]),
      close: parseFloat(k[4]),
      volume: parseFloat(k[5])
    }));
  }
}