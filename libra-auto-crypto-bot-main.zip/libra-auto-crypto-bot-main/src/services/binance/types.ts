export interface TickerData {
  s: string;  // symbol
  c: string;  // close price
  v: string;  // volume
  p: string;  // price change
  P: string;  // price change percent
  e?: string; // event type
}

export interface PriceData {
  symbol: string;
  price: string;
}

export interface Stats24hr {
  volume: string;
  priceChange: string;
  priceChangePercent: string;
}

export interface AccountInfo {
  balances: Array<{
    asset: string;
    free: string;
    locked: string;
  }>;
}

export interface FuturesAccountInfo {
  assets: any[];
  totalUnrealizedProfit: string;
  totalWalletBalance: string;
  totalMarginBalance: string;
}