import { FuturesAccountInfo } from './types';
import { BINANCE_API_URLS, generateSignature, createQueryString } from './utils';

export class BinanceFuturesService {
  private apiKey: string = '';
  private apiSecret: string = '';

  constructor(apiKey: string = '', apiSecret: string = '') {
    this.apiKey = apiKey;
    this.apiSecret = apiSecret;
  }

  private async signedRequest(endpoint: string, params: Record<string, string> = {}) {
    if (!this.apiKey || !this.apiSecret) {
      throw new Error('API anahtarları ayarlanmamış');
    }

    try {
      const timestamp = Date.now().toString();
      const queryString = createQueryString({ ...params, timestamp });
      const signature = await generateSignature(queryString, this.apiSecret);
      const url = `${BINANCE_API_URLS.FUTURES}${endpoint}?${queryString}&signature=${signature}`;

      const response = await fetch(url, {
        headers: {
          'X-MBX-APIKEY': this.apiKey,
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`API Hatası: ${errorData.msg || 'Bilinmeyen hata'}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Futures API isteği hatası:', error);
      throw error;
    }
  }

  async getAccountInfo(): Promise<FuturesAccountInfo> {
    const data = await this.signedRequest('/fapi/v2/account');
    return {
      assets: data.assets,
      totalUnrealizedProfit: data.totalUnrealizedProfit,
      totalWalletBalance: data.totalWalletBalance,
      totalMarginBalance: data.totalMarginBalance
    };
  }
}