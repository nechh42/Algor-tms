import { TechnicalAnalysisService } from './technicalAnalysis';
import { VolumeAnalysisService } from './volumeAnalysis';
import { MomentumAnalysisService } from './momentumAnalysis';
import { binanceService } from './binance';
import { autoTrader } from './trading/autoTrader';
import { FibonacciAnalysisService } from './analysis/fibonacciAnalysis';
import { RiskManagementService } from './risk/riskManagement';
import { MLAnalysisService } from './analysis/mlAnalysis';
import { EnhancedVolumeAnalysis } from './analysis/volumeAnalysis';

export interface TradeSignal {
  action: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  price: number;
  reason: string;
  stopLoss?: number;
  takeProfit?: number;
  riskScore: number;
  fibLevels?: any;
  pivotPoints?: any;
  mlPrediction?: any;
  volumeProfile?: any;
}

interface RiskParameters {
  maxPositionSize: number;
  maxDrawdown: number;
  volatilityThreshold: number;
  profitTarget: number;
  adaptiveThreshold: boolean;
}

export class StrategyService {
  private static riskParams: RiskParameters = {
    maxPositionSize: 0.15,
    maxDrawdown: 0.15,
    volatilityThreshold: 0.02,
    profitTarget: 0.03,
    adaptiveThreshold: true
  };

  private static lastOptimization: number = Date.now();
  private static successfulTrades: number = 0;
  private static totalTrades: number = 0;

  static async analyzeMarket(symbol: string = 'BTCUSDT'): Promise<TradeSignal> {
    const [technical, volume, momentum, mlPrediction, volumeProfile] = await Promise.all([
      TechnicalAnalysisService.analyze(symbol),
      VolumeAnalysisService.analyze(symbol),
      MomentumAnalysisService.analyze(symbol),
      MLAnalysisService.predictPrice(symbol),
      EnhancedVolumeAnalysis.analyzeVolume(symbol)
    ]);

    const klines = await binanceService.getKlines(symbol, '1h', 24);
    const prices = klines.map(k => k.close);
    const highs = klines.map(k => k.high);
    const lows = klines.map(k => k.low);
    
    const lastPrice = prices[prices.length - 1];
    const highPrice = Math.max(...highs);
    const lowPrice = Math.min(...lows);

    const fibLevels = FibonacciAnalysisService.calculateLevels(
      highPrice,
      lowPrice,
      lastPrice
    );

    const fibAnalysis = FibonacciAnalysisService.analyzeTrend(lastPrice, fibLevels);
    const volatility = this.calculateVolatility(prices);
    
    const positionSize = RiskManagementService.calculatePositionSize(
      lastPrice,
      volatility,
      { accountBalance: 10000 }
    );

    let action: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
    let confidence = 0;
    let reasons: string[] = [];
    let riskScore = this.calculateRiskScore(volatility, technical.trend);

    // ML ve Hacim analizi entegrasyonu
    if (mlPrediction.confidence > 0.8) {
      confidence += 0.2;
      reasons.push(`ML tahmini: ${mlPrediction.trend} (${(mlPrediction.confidence * 100).toFixed(0)}% güven)`);
    }

    if (volumeProfile.trend === 'ACCUMULATION' && volumeProfile.strength > 0.7) {
      confidence += 0.15;
      reasons.push('Güçlü alım hacmi tespit edildi');
    } else if (volumeProfile.trend === 'DISTRIBUTION' && volumeProfile.strength > 0.7) {
      confidence -= 0.15;
      reasons.push('Güçlü satış hacmi tespit edildi');
    }

    // Fibonacci ve pivot analizi
    if (fibAnalysis.trend === 'BULLISH' && lastPrice > fibLevels.pivot) {
      confidence += 0.2;
      reasons.push(`Fiyat pivot seviyesi üzerinde (${fibLevels.pivot.toFixed(2)})`);
    } else if (fibAnalysis.trend === 'BEARISH' && lastPrice < fibLevels.pivot) {
      confidence += 0.2;
      reasons.push(`Fiyat pivot seviyesi altında (${fibLevels.pivot.toFixed(2)})`);
    }

    // Mevcut analiz mantığı
    if (this.isProfitableOpportunity(technical, volume, momentum)) {
      if (technical.trend === 'BULLISH' && momentum.momentum.includes('STRONG_UP')) {
        action = 'BUY';
        confidence = Math.min((technical.confidence + momentum.confidence) * 1.2, 1);
        reasons.push(`Güçlü alım fırsatı tespit edildi (${(confidence * 100).toFixed(0)}% güven)`);
      } else if (technical.trend === 'BEARISH' && momentum.momentum.includes('STRONG_DOWN')) {
        action = 'SELL';
        confidence = Math.min((technical.confidence + momentum.confidence) * 1.2, 1);
        reasons.push(`Güçlü satış fırsatı tespit edildi (${(confidence * 100).toFixed(0)}% güven)`);
      }
    }

    // Risk kontrolü
    const riskValidation = RiskManagementService.validateRisk(
      [], // Mevcut pozisyonlar buraya eklenecek
      10000 // Gerçek hesap bakiyesi buraya eklenecek
    );

    if (!riskValidation.isValid) {
      confidence *= 0.5;
      reasons.push(riskValidation.message);
    }

    return {
      action,
      confidence,
      price: lastPrice,
      reason: reasons.join('. '),
      stopLoss: positionSize.stopLoss,
      takeProfit: positionSize.takeProfit,
      riskScore,
      fibLevels,
      pivotPoints: {
        pivot: fibLevels.pivot,
        r1: fibLevels.resistance1,
        r2: fibLevels.resistance2,
        s1: fibLevels.support1,
        s2: fibLevels.support2
      },
      mlPrediction,
      volumeProfile
    };
  }

  private static isProfitableOpportunity(technical: any, volume: any, momentum: any): boolean {
    const profitPotential = 
      (technical.confidence * 0.4) + 
      (volume.confidence * 0.3) + 
      (momentum.confidence * 0.3);
    
    return profitPotential > this.riskParams.profitTarget;
  }

  private static calculateDynamicStopLoss(volatility: number, riskScore: number): number {
    const baseStopLoss = Math.max(0.01, volatility * 2);
    return baseStopLoss * (1 + riskScore);
  }

  private static calculateDynamicTakeProfit(volatility: number, confidence: number): number {
    const baseTakeProfit = Math.max(0.02, volatility * 4);
    return baseTakeProfit * (1 + confidence);
  }

  private static async optimizeStrategyIfNeeded(): Promise<void> {
    const now = Date.now();
    if (now - this.lastOptimization > 3600000) {
      const winRate = this.successfulTrades / Math.max(1, this.totalTrades);
      
      if (winRate < 0.5) {
        this.riskParams.maxPositionSize = Math.max(0.05, this.riskParams.maxPositionSize - 0.02);
        this.riskParams.profitTarget = Math.min(0.05, this.riskParams.profitTarget + 0.005);
      } else {
        this.riskParams.maxPositionSize = Math.min(0.2, this.riskParams.maxPositionSize + 0.01);
        this.riskParams.profitTarget = Math.max(0.02, this.riskParams.profitTarget - 0.002);
      }

      this.lastOptimization = now;
      this.successfulTrades = 0;
      this.totalTrades = 0;
    }
  }

  private static calculateVolatility(prices: number[]): number {
    const returns = prices.slice(1).map((price, i) => 
      Math.log(price / prices[i])
    );
    const meanReturn = returns.reduce((sum, ret) => sum + ret, 0) / returns.length;
    const squaredDiffs = returns.map(ret => Math.pow(ret - meanReturn, 2));
    return Math.sqrt(squaredDiffs.reduce((sum, diff) => sum + diff, 0) / returns.length);
  }

  private static calculateRiskScore(volatility: number, trend: string): number {
    let riskScore = volatility / this.riskParams.volatilityThreshold;
    
    if (trend === 'BEARISH') {
      riskScore *= 1.2;
    }
    
    return Math.min(1, Math.max(0, riskScore));
  }

  static async startAutoTrading(amount: number, leverage: number = 1) {
    return autoTrader.startTrading(amount, leverage);
  }
}