import { binanceService } from './binance';

export interface VolumeAnalysisResult {
  volumeProfile: 'HIGH' | 'MEDIUM' | 'LOW';
  confidence: number;
  vwap: number;
  volumeChange24h: number;
}

interface KlineData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export class VolumeAnalysisService {
  static async analyze(symbol: string): Promise<VolumeAnalysisResult> {
    const stats = await binanceService.get24hrStats(symbol);
    const klines = await binanceService.getKlines(symbol, '1h', 24);
    
    let totalVolume = 0;
    let totalVolumePrice = 0;
    
    klines.forEach((value: KlineData) => {
      const volume = value.volume;
      const typicalPrice = (value.high + value.low + value.close) / 3;
      totalVolume += volume;
      totalVolumePrice += volume * typicalPrice;
    });

    const vwap = totalVolumePrice / totalVolume;
    const volumeChange24h = parseFloat(stats.volume);
    const avgVolume = totalVolume / 24;

    let volumeProfile: 'HIGH' | 'MEDIUM' | 'LOW' = 'MEDIUM';
    let confidence = 0.5;

    if (volumeChange24h > avgVolume * 1.5) {
      volumeProfile = 'HIGH';
      confidence = 0.8;
    } else if (volumeChange24h < avgVolume * 0.5) {
      volumeProfile = 'LOW';
      confidence = 0.7;
    }

    return {
      volumeProfile,
      confidence,
      vwap,
      volumeChange24h
    };
  }
}