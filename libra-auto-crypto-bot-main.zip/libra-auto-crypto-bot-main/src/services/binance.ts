import { BinanceWebSocketService } from './binance/websocket';
import { BinanceSpotService } from './binance/spot';
import { BinanceFuturesService } from './binance/futures';

class BinanceService {
  private webSocket: BinanceWebSocketService;
  private spot: BinanceSpotService;
  private futures: BinanceFuturesService;

  constructor() {
    this.webSocket = new BinanceWebSocketService();
    this.spot = new BinanceSpotService();
    this.futures = new BinanceFuturesService();
  }

  initialize(apiKey: string, apiSecret: string) {
    this.spot = new BinanceSpotService(apiKey, apiSecret);
    this.futures = new BinanceFuturesService(apiKey, apiSecret);
    console.log('Binance API başlatıldı - Gerçek Hesap');
  }

  isInitialized() {
    return this.spot !== null && this.futures !== null;
  }

  // WebSocket metodları
  onPriceUpdate(callback: Function) {
    this.webSocket.onPriceUpdate(callback);
  }

  // Spot metodları
  getPrice(symbol: string) {
    return this.spot.getPrice(symbol);
  }

  get24hrStats(symbol: string) {
    return this.spot.get24hrStats(symbol);
  }

  getAccountInfo() {
    return this.spot.getAccountInfo();
  }

  // Add getKlines method
  getKlines(symbol: string, interval: string, limit: number) {
    return this.spot.getKlines(symbol, interval, limit);
  }

  // Futures metodları
  getFuturesAccountInfo() {
    return this.futures.getAccountInfo();
  }
}

export const binanceService = new BinanceService();