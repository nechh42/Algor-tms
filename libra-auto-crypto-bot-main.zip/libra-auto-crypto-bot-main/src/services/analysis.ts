import { SMA, RSI, MACD, BollingerBands, EMA, ADX } from 'technicalindicators';

export class AnalysisService {
  static calculateSMA(prices: number[], period: number = 14) {
    return SMA.calculate({ period, values: prices });
  }

  static calculateRSI(prices: number[], period: number = 14) {
    return RSI.calculate({ period, values: prices });
  }

  static calculateMACD(prices: number[]) {
    return MACD.calculate({
      fastPeriod: 12,
      slowPeriod: 26,
      signalPeriod: 9,
      values: prices,
      SimpleMAOscillator: false,
      SimpleMASignal: false
    });
  }

  static calculateBollingerBands(prices: number[], period: number = 20) {
    return BollingerBands.calculate({
      period,
      values: prices,
      stdDev: 2
    });
  }

  static calculateEMA(prices: number[], period: number = 14) {
    return EMA.calculate({ period, values: prices });
  }

  static calculateStochRSI(prices: number[], period: number = 14) {
    try {
      // First calculate RSI
      const rsiValues = this.calculateRSI(prices, period);
      
      // Calculate StochRSI manually since the library implementation has issues
      const stochPeriod = 14;
      const kPeriod = 3;
      const dPeriod = 3;
      
      const stochRsiValues = [];
      
      for (let i = stochPeriod - 1; i < rsiValues.length; i++) {
        const rsiSlice = rsiValues.slice(i - stochPeriod + 1, i + 1);
        const highestRsi = Math.max(...rsiSlice);
        const lowestRsi = Math.min(...rsiSlice);
        
        const k = ((rsiValues[i] - lowestRsi) / (highestRsi - lowestRsi)) * 100;
        stochRsiValues.push({ k, d: 0 }); // Initialize with d = 0
      }
      
      // Calculate K-period SMA for final K values
      const kSma = [];
      for (let i = kPeriod - 1; i < stochRsiValues.length; i++) {
        const kSlice = stochRsiValues.slice(i - kPeriod + 1, i + 1).map(v => v.k);
        const kValue = kSlice.reduce((a, b) => a + b) / kPeriod;
        kSma.push({ k: kValue, d: 0 });
      }
      
      // Calculate D-period SMA for final D values
      const result = [];
      for (let i = dPeriod - 1; i < kSma.length; i++) {
        const dSlice = kSma.slice(i - dPeriod + 1, i + 1).map(v => v.k);
        const dValue = dSlice.reduce((a, b) => a + b) / dPeriod;
        result.push({ k: kSma[i].k, d: dValue });
      }
      
      return result;
    } catch (error) {
      console.error('StochRSI calculation error:', error);
      return [{ k: 50, d: 50 }]; // Return neutral values in case of error
    }
  }

  static calculateADX(high: number[], low: number[], close: number[], period: number = 14) {
    return ADX.calculate({ high, low, close, period });
  }

  static predictNextPrice(prices: number[]): number {
    const sma = this.calculateSMA(prices, 14);
    const ema = this.calculateEMA(prices, 14);
    const rsi = this.calculateRSI(prices, 14);
    const macd = this.calculateMACD(prices);
    const bb = this.calculateBollingerBands(prices);
    const stochRsi = this.calculateStochRSI(prices);

    const lastPrice = prices[prices.length - 1];
    const lastRSI = rsi[rsi.length - 1];
    const lastMACD = macd[macd.length - 1];
    const lastBB = bb[bb.length - 1];
    const lastStochRSI = stochRsi[stochRsi.length - 1];
    const lastEMA = ema[ema.length - 1];

    let prediction = lastPrice;
    let weight = 0;
    let totalWeight = 0;

    if (lastRSI < 30) {
      prediction += lastPrice * 0.02;
      weight += 2;
    } else if (lastRSI > 70) {
      prediction -= lastPrice * 0.02;
      weight += 2;
    }
    totalWeight += 2;

    if (lastMACD.histogram > 0) {
      prediction += lastPrice * 0.015;
      weight += 1.5;
    } else if (lastMACD.histogram < 0) {
      prediction -= lastPrice * 0.015;
      weight += 1.5;
    }
    totalWeight += 1.5;

    if (lastPrice < lastBB.lower) {
      prediction += lastPrice * 0.025;
      weight += 2.5;
    } else if (lastPrice > lastBB.upper) {
      prediction -= lastPrice * 0.025;
      weight += 2.5;
    }
    totalWeight += 2.5;

    if (lastStochRSI.k < 20) {
      prediction += lastPrice * 0.01;
      weight += 1;
    } else if (lastStochRSI.k > 80) {
      prediction -= lastPrice * 0.01;
      weight += 1;
    }
    totalWeight += 1;

    const emaDiff = lastPrice - lastEMA;
    prediction += emaDiff * 0.5;
    weight += 1;
    totalWeight += 1;

    return (prediction * weight) / totalWeight;
  }

  static calculateTrendStrength(prices: number[]): number {
    const adx = this.calculateADX(
      prices.map((p, i) => Math.max(p, prices[i - 1] || p)),
      prices.map((p, i) => Math.min(p, prices[i - 1] || p)),
      prices,
      14
    );
    
    const lastADX = adx[adx.length - 1];
    return lastADX?.adx || 0;
  }
}

export const technicalIndicators = {
  calculateRSI: AnalysisService.calculateRSI,
  calculateMACD: AnalysisService.calculateMACD,
  calculateBollingerBands: AnalysisService.calculateBollingerBands
};