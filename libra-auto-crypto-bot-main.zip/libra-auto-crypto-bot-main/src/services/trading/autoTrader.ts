import { StrategyService } from '../strategy';
import { orderService } from './orderService';

class AutoTrader {
  private tradingInterval: NodeJS.Timeout | null = null;

  async startTrading(amount: number, leverage: number = 1) {
    // Önceki interval'ı temizle
    if (this.tradingInterval) {
      clearInterval(this.tradingInterval);
    }

    // 3 saniyede bir kontrol et
    this.tradingInterval = setInterval(async () => {
      try {
        const signal = await StrategyService.analyzeMarket();
        if (signal.action !== 'HOLD') {
          await orderService.executeAutoTrade(signal, amount, leverage);
        }
      } catch (error) {
        console.error('Otomatik işlem hatası:', error);
      }
    }, 3000); // 3 saniye
  }

  stopTrading() {
    if (this.tradingInterval) {
      clearInterval(this.tradingInterval);
      this.tradingInterval = null;
    }
  }
}

export const autoTrader = new AutoTrader();