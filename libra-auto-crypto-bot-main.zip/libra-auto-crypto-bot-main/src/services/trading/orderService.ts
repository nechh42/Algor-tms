import { binanceService } from '../binance';

export interface OrderParams {
  symbol: string;
  side: 'BUY' | 'SELL';
  amount: number;
  leverage: number;
  stopLoss?: number;
  takeProfit?: number;
}

class OrderService {
  async createOrder(params: OrderParams) {
    if (!binanceService.isInitialized()) {
      throw new Error('API bağlantısı gerekli');
    }

    try {
      console.log('Gerçek işlem oluşturuluyor:', params);
      const timestamp = Date.now();
      const orderData = {
        symbol: params.symbol,
        side: params.side,
        type: 'MARKET',
        quantity: params.amount.toString(),
        timestamp: timestamp.toString()
      };

      // Gerçek sipariş oluşturma işlemi burada yapılacak
      return await binanceService.getPrice(params.symbol);
    } catch (error) {
      console.error('İşlem oluşturma hatası:', error);
      throw error;
    }
  }

  async executeAutoTrade(signal: any, amount: number, leverage: number = 1) {
    if (!binanceService.isInitialized()) {
      throw new Error('API bağlantısı gerekli');
    }

    if (signal.confidence < 0.7) {
      console.log('Sinyal güven seviyesi yetersiz:', signal.confidence);
      return;
    }

    try {
      console.log(`Gerçek otomatik işlem başlatılıyor: ${signal.action}`, {
        price: signal.price,
        stopLoss: signal.stopLoss,
        takeProfit: signal.takeProfit,
        confidence: signal.confidence
      });

      const orderParams: OrderParams = {
        symbol: 'BTCUSDT',
        side: signal.action,
        amount,
        leverage,
        stopLoss: signal.stopLoss,
        takeProfit: signal.takeProfit
      };

      return await this.createOrder(orderParams);
    } catch (error) {
      console.error('İşlem açma hatası:', error);
      throw error;
    }
  }
}

export const orderService = new OrderService();