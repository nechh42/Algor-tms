import { binanceService } from './binance';
import { MLAnalysisService } from './mlAnalysis';
import { SentimentService } from './sentiment';
import { TechnicalAnalysisService } from './analysis/technicalAnalysis';
import { OpportunityScoringService } from './analysis/opportunityScoring';
import { PerformanceTrackingService } from './analysis/performanceTracking';

interface CoinAnalysis {
  symbol: string;
  price: number;
  volume: string;
  priceChange: string;
  signals: {
    rsi: number;
    macd: any;
    bb: any;
    ai: {
      prediction: number;
      confidence: number;
    };
  };
  opportunity: {
    score: number;
    reason: string;
    profitPotential: number;
    risk: number;
  };
  historicalPerformance: {
    successRate: number;
    avgProfit: number;
    avgLoss: number;
  };
}

class MultiCoinAnalysisService {
  private symbols: string[] = [];
  
  constructor() {
    this.initializeSymbols();
    PerformanceTrackingService.loadFromStorage();
  }

  private async initializeSymbols() {
    try {
      const exchangeInfo = await fetch('https://api.binance.com/api/v3/exchangeInfo');
      const data = await exchangeInfo.json();
      this.symbols = data.symbols
        .filter((s: any) => s.quoteAsset === 'USDT' && s.status === 'TRADING')
        .map((s: any) => s.symbol)
        .slice(0, 100);
      
      console.log(`${this.symbols.length} coin analiz için hazırlandı`);
    } catch (error) {
      console.error('Sembol listesi alınamadı:', error);
      this.symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'ADAUSDT', 'DOGEUSDT'];
    }
  }

  async analyzeAllCoins(): Promise<CoinAnalysis[]> {
    const analyses: CoinAnalysis[] = [];
    
    for (const symbol of this.symbols) {
      try {
        console.log(`${symbol} analizi başlıyor...`);
        
        const [priceData, volumeData, sentiment] = await Promise.all([
          binanceService.getPrice(symbol),
          binanceService.get24hrStats(symbol),
          SentimentService.analyzeSocialSentiment(symbol)
        ]);

        const technicalSignals = await TechnicalAnalysisService.analyzeCoin(symbol);
        const mlPrediction = await MLAnalysisService.getPrediction(symbol);
        
        const opportunityScore = OpportunityScoringService.calculateScore(
          technicalSignals,
          mlPrediction,
          sentiment,
          volumeData
        );

        const performance = PerformanceTrackingService.getMetrics(symbol);

        analyses.push({
          symbol,
          price: parseFloat(priceData.price),
          volume: volumeData.volume,
          priceChange: volumeData.priceChange,
          signals: {
            ...technicalSignals,
            ai: {
              prediction: mlPrediction.price,
              confidence: mlPrediction.confidence
            }
          },
          opportunity: opportunityScore,
          historicalPerformance: {
            successRate: performance.successRate,
            avgProfit: performance.avgProfit,
            avgLoss: -performance.avgProfit * (1 - performance.successRate) / Math.max(performance.successRate, 0.01)
          }
        });

        console.log(`${symbol} analizi tamamlandı`);
      } catch (error) {
        console.error(`${symbol} analiz hatası:`, error);
      }
    }

    return analyses.sort((a, b) => b.opportunity.score - a.opportunity.score);
  }
}

export const multiCoinAnalysisService = new MultiCoinAnalysisService();