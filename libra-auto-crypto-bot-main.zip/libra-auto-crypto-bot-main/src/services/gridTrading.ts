export interface GridLevel {
  price: number;
  type: 'BUY' | 'SELL';
  size: number;
}

export interface GridConfig {
  upperPrice: number;
  lowerPrice: number;
  levels: number;
  totalInvestment: number;
}

export class GridTradingService {
  static calculateGridLevels(config: GridConfig): GridLevel[] {
    const { upperPrice, lowerPrice, levels, totalInvestment } = config;
    const priceStep = (upperPrice - lowerPrice) / (levels - 1);
    const investmentPerLevel = totalInvestment / levels;

    return Array.from({ length: levels }, (_, i) => {
      const price = lowerPrice + (priceStep * i);
      return {
        price,
        type: i < levels / 2 ? 'BUY' : 'SELL',
        size: investmentPerLevel / price
      };
    });
  }

  static calculateProfitPotential(levels: GridLevel[]): number {
    let potentialProfit = 0;
    for (let i = 1; i < levels.length; i++) {
      const priceDiff = levels[i].price - levels[i-1].price;
      potentialProfit += Math.abs(priceDiff * levels[i].size);
    }
    return potentialProfit;
  }
}