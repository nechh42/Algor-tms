export interface Position {
  symbol: string;
  amount: number;
  entryPrice: number;
  currentPrice: number;
  pnl: number;
  risk: number;
}

export interface PortfolioHistory {
  timestamp: string;
  value: number;
  profit: number;
}

export interface Trade {
  symbol: string;
  type: 'BUY' | 'SELL';
  price: number;
  amount: number;
  pnl: number;
  timestamp: number;
}

export class PortfolioService {
  static async getPositions(): Promise<Position[]> {
    // Binance API entegrasyonu için hazır yapı
    return [
      {
        symbol: 'BTCUSDT',
        amount: 0.1,
        entryPrice: 45000,
        currentPrice: 47000,
        pnl: 200,
        risk: 0.3
      }
    ];
  }

  static calculatePortfolioRisk(positions: Position[]): number {
    const totalValue = positions.reduce((sum, pos) => 
      sum + pos.amount * pos.currentPrice, 0);
    
    const riskScore = positions.reduce((score, pos) => 
      score + (pos.risk * pos.amount * pos.currentPrice) / totalValue, 0);
    
    return riskScore;
  }

  static async getPortfolioHistory(): Promise<PortfolioHistory[]> {
    const now = new Date();
    return Array.from({ length: 30 }, (_, i) => ({
      timestamp: new Date(now.getTime() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      value: 50000 + Math.random() * 5000,
      profit: Math.random() * 1000 - 500
    }));
  }

  static async getTradeHistory(): Promise<Trade[]> {
    // Örnek veri - gerçek implementasyonda API'den gelecek
    const now = Date.now();
    return Array.from({ length: 10 }, (_, i) => ({
      symbol: 'BTCUSDT',
      type: Math.random() > 0.5 ? 'BUY' : 'SELL',
      price: 45000 + Math.random() * 2000,
      amount: 0.1,
      pnl: Math.random() * 200 - 100,
      timestamp: now - i * 3600000
    }));
  }
}