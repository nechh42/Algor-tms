import { binanceService } from './binance';
import { StochasticRSI, ADX } from 'technicalindicators';

export interface MomentumAnalysisResult {
  momentum: 'STRONG_UP' | 'UP' | 'NEUTRAL' | 'DOWN' | 'STRONG_DOWN';
  confidence: number;
  signals: {
    stochRsi: {
      k: number;
      d: number;
    };
    adx: number;
  };
}

export class MomentumAnalysisService {
  static async analyze(symbol: string): Promise<MomentumAnalysisResult> {
    const klines = await binanceService.getKlines(symbol, '1h', 100);
    const prices = klines.map(k => k.close);
    const highs = klines.map(k => k.high);
    const lows = klines.map(k => k.low);

    const stochRsi = StochasticRSI.calculate({
      values: prices,
      rsiPeriod: 14,
      stochasticPeriod: 14,
      kPeriod: 3,
      dPeriod: 3
    });

    const adxResult = ADX.calculate({
      high: highs,
      low: lows,
      close: prices,
      period: 14
    });

    const lastStochRsi = stochRsi[stochRsi.length - 1];
    const lastADX = adxResult[adxResult.length - 1];
    const adxValue = typeof lastADX === 'number' ? lastADX : lastADX.adx;

    let momentum: 'STRONG_UP' | 'UP' | 'NEUTRAL' | 'DOWN' | 'STRONG_DOWN' = 'NEUTRAL';
    let confidence = 0.5;

    if (lastStochRsi.k > 80 && adxValue > 25) {
      momentum = lastStochRsi.k > lastStochRsi.d ? 'STRONG_UP' : 'UP';
      confidence = 0.8;
    } else if (lastStochRsi.k < 20 && adxValue > 25) {
      momentum = lastStochRsi.k < lastStochRsi.d ? 'STRONG_DOWN' : 'DOWN';
      confidence = 0.8;
    }

    return {
      momentum,
      confidence,
      signals: {
        stochRsi: lastStochRsi,
        adx: adxValue
      }
    };
  }
}