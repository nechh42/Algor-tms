import React from 'react';
import { Card } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

interface PortfolioDistributionChartProps {
  positions: Array<{
    symbol: string;
    amount: number;
    currentPrice: number;
  }>;
}

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#0088FE'];

const PortfolioDistributionChart = ({ positions }: PortfolioDistributionChartProps) => {
  const data = positions.map((position) => ({
    name: position.symbol,
    value: position.amount * position.currentPrice
  }));

  const totalValue = data.reduce((sum, item) => sum + item.value, 0);

  return (
    <Card className="p-4">
      <h3 className="text-lg font-semibold mb-4">Portföy Dağılımı</h3>
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
              outerRadius={100}
              fill="#8884d8"
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip
              formatter={(value: number) => [`$${value.toFixed(2)}`, 'Değer']}
            />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 text-sm text-gray-600">
        Toplam Portföy Değeri: ${totalValue.toFixed(2)}
      </div>
    </Card>
  );
};

export default PortfolioDistributionChart;