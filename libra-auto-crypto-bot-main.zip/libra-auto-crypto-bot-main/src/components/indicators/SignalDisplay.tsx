import React from 'react';
import { TradeSignal } from '@/services/strategy';

interface SignalDisplayProps {
  signal: TradeSignal | null;
}

const SignalDisplay = ({ signal }: SignalDisplayProps) => {
  if (!signal) return null;

  return (
    <>
      <div className="space-y-2">
        <p className="text-sm text-gray-500">Sinyal</p>
        <p className={`text-xl font-bold ${
          signal.action === 'BUY' ? 'text-green-500' : 
          signal.action === 'SELL' ? 'text-red-500' : 
          'text-yellow-500'
        }`}>
          {signal.action || 'HOLD'}
        </p>
      </div>
      <div className="mt-4 p-2 bg-gray-800 rounded">
        <p className="text-sm text-gray-300">
          {signal.reason} (Güven: {(signal.confidence * 100).toFixed(0)}%)
        </p>
      </div>
    </>
  );
};

export default SignalDisplay;