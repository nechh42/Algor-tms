import React from 'react';

interface PriceDisplayProps {
  price: string;
  volume: string;
}

const PriceDisplay = ({ price, volume }: PriceDisplayProps) => {
  return (
    <>
      <div className="space-y-2">
        <p className="text-sm text-gray-500">BTC/USDT</p>
        <p className="text-xl font-bold">${price}</p>
      </div>
      <div className="space-y-2">
        <p className="text-sm text-gray-500">24s Hacim (BTC)</p>
        <p className="text-xl font-bold">{volume}</p>
      </div>
    </>
  );
};

export default PriceDisplay;