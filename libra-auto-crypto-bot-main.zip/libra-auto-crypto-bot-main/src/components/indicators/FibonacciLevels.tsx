import React from 'react';
import { Badge } from '@/components/ui/badge';

interface FibonacciLevelsProps {
  levels: {
    retracement: number[];
    extension: number[];
    pivot: number;
    support1: number;
    support2: number;
    resistance1: number;
    resistance2: number;
  };
  pivotPoints: {
    pivot: number;
    r1: number;
    r2: number;
    s1: number;
    s2: number;
  };
  currentPrice: number;
}

const FibonacciLevels = ({ levels, pivotPoints, currentPrice }: FibonacciLevelsProps) => {
  const getColorForLevel = (level: number) => {
    const diff = Math.abs(currentPrice - level) / currentPrice;
    if (diff < 0.005) return 'bg-yellow-500';
    return currentPrice > level ? 'bg-green-500' : 'bg-red-500';
  };

  return (
    <div className="space-y-4">
      <div>
        <h4 className="text-sm font-medium mb-2">Fibonacci Seviyeleri</h4>
        <div className="space-y-1">
          {levels.retracement.map((level, index) => (
            <div key={`ret-${index}`} className="flex justify-between items-center">
              <span className="text-sm">%{(23.6 + index * 14.6).toFixed(1)}</span>
              <Badge variant="default" className={getColorForLevel(level)}>
                {level.toFixed(2)}
              </Badge>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h4 className="text-sm font-medium mb-2">Pivot Noktaları</h4>
        <div className="space-y-1">
          <div className="flex justify-between items-center">
            <span className="text-sm">R2</span>
            <Badge variant="default" className={getColorForLevel(pivotPoints.r2)}>
              {pivotPoints.r2.toFixed(2)}
            </Badge>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm">R1</span>
            <Badge variant="default" className={getColorForLevel(pivotPoints.r1)}>
              {pivotPoints.r1.toFixed(2)}
            </Badge>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm">Pivot</span>
            <Badge variant="default" className={getColorForLevel(pivotPoints.pivot)}>
              {pivotPoints.pivot.toFixed(2)}
            </Badge>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm">S1</span>
            <Badge variant="default" className={getColorForLevel(pivotPoints.s1)}>
              {pivotPoints.s1.toFixed(2)}
            </Badge>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm">S2</span>
            <Badge variant="default" className={getColorForLevel(pivotPoints.s2)}>
              {pivotPoints.s2.toFixed(2)}
            </Badge>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FibonacciLevels;