import React from 'react';
import { Progress } from '@/components/ui/progress';

interface TechnicalIndicatorsProps {
  rsi: number | null;
  stochRsi: { k: number; d: number } | null;
  trendStrength: number | null;
  prediction: number | null;
}

const TechnicalIndicators = ({ rsi, stochRsi, trendStrength, prediction }: TechnicalIndicatorsProps) => {
  return (
    <>
      <div className="space-y-2">
        <p className="text-sm text-gray-500">RSI (14)</p>
        <p className="text-xl font-bold">{rsi?.toFixed(2) || 'Hesaplanıyor...'}</p>
      </div>
      <div className="space-y-2">
        <p className="text-sm text-gray-500">Stoch RSI</p>
        <p className="text-xl font-bold">
          K: {stochRsi?.k.toFixed(2) || '...'} / D: {stochRsi?.d.toFixed(2) || '...'}
        </p>
      </div>
      <div className="space-y-2">
        <p className="text-sm text-gray-500">Trend Gücü</p>
        <p className="text-xl font-bold">{trendStrength?.toFixed(2) || 'Hesaplanıyor...'}</p>
      </div>
      <div className="space-y-2">
        <p className="text-sm text-gray-500">Tahmin</p>
        <p className="text-xl font-bold">${prediction?.toFixed(2) || 'Hesaplanıyor...'}</p>
      </div>
    </>
  );
};

export default TechnicalIndicators;