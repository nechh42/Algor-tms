import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { binanceService } from '@/services/binance';
import { useToast } from '@/hooks/use-toast';
import ChartContainer from './trading/ChartContainer';
import ChartControls from './trading/ChartControls';

type TimeFrame = '1m' | '5m' | '15m' | '1h' | '4h' | '1d';
type Indicator = 'MA' | 'EMA' | 'RSI' | 'MACD' | 'BB';

interface KlineData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

const TradingView = () => {
  const [timeframe, setTimeframe] = useState<TimeFrame>('1h');
  const [activeIndicators, setActiveIndicators] = useState<Indicator[]>([]);
  const [isDrawingMode, setIsDrawingMode] = useState(false);
  const [chartData, setChartData] = useState<KlineData[]>([]);
  const { toast } = useToast();

  const fetchData = async () => {
    try {
      const klines = await binanceService.getKlines('BTCUSDT', timeframe, 100);
      const formattedData = klines.map((value: KlineData) => ({
        time: value.time,
        open: value.open,
        high: value.high,
        low: value.low,
        close: value.close,
        volume: value.volume
      }));
      setChartData(formattedData);
    } catch (error) {
      console.error('Veri çekme hatası:', error);
      toast({
        title: "Hata",
        description: "Veriler yüklenirken bir hata oluştu.",
        variant: "destructive",
      });
    }
  };

  React.useEffect(() => {
    fetchData();
    // 1 saniyede bir güncelleme
    const interval = setInterval(fetchData, 1000);
    return () => clearInterval(interval);
  }, [timeframe]);

  const toggleIndicator = (indicator: Indicator) => {
    setActiveIndicators(prev => 
      prev.includes(indicator) 
        ? prev.filter(i => i !== indicator)
        : [...prev, indicator]
    );
  };

  const toggleDrawingMode = () => {
    setIsDrawingMode(!isDrawingMode);
    toast({
      title: isDrawingMode ? "Çizim Modu Kapatıldı" : "Çizim Modu Açıldı",
      description: isDrawingMode ? "Normal mod aktif" : "Trend çizgileri çizebilirsiniz",
    });
  };

  return (
    <Card className="p-4 bg-[#1a1a1a]">
      <ChartControls
        timeframe={timeframe}
        onTimeframeChange={(value: string) => setTimeframe(value as TimeFrame)}
        activeIndicators={activeIndicators}
        onToggleIndicator={toggleIndicator}
        isDrawingMode={isDrawingMode}
        onToggleDrawingMode={toggleDrawingMode}
      />
      <ChartContainer
        data={chartData}
        indicators={activeIndicators}
        isDrawingMode={isDrawingMode}
      />
    </Card>
  );
};

export default TradingView;