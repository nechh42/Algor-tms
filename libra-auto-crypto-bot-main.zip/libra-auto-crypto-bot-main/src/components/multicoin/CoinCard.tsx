import React from 'react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';

interface CoinAnalysis {
  symbol: string;
  price: number;
  volume: string;
  signals: {
    rsi: number;
    macd: any;
    bb: any;
    ai: {
      prediction: number;
      confidence: number;
    };
  };
  opportunity: {
    score: number;
    reason: string;
    profitPotential: number;
    risk: number;
  };
  historicalPerformance: {
    successRate: number;
    avgProfit: number;
    avgLoss: number;
  };
  mlPrediction?: {
    price: number;
    confidence: number;
    features: {
      trend: string;
      momentum: number;
      volatility: number;
      support: number;
      resistance: number;
    };
  };
}

interface CoinCardProps {
  analysis: CoinAnalysis;
}

const CoinCard = ({ analysis }: CoinCardProps) => {
  const formatNumber = (value: number | undefined) => {
    if (value === undefined || value === null || isNaN(value)) {
      return 'N/A';
    }
    return value.toFixed(2);
  };

  const getOpportunityColor = (score: number) => {
    if (score > 80) return 'text-green-500';
    if (score > 60) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getRiskBadge = (risk: number) => {
    if (risk < 0.3) return <Badge variant="default" className="bg-green-500">Düşük Risk</Badge>;
    if (risk < 0.7) return <Badge variant="default" className="bg-yellow-500">Orta Risk</Badge>;
    return <Badge variant="default" className="bg-red-500">Yüksek Risk</Badge>;
  };

  return (
    <Card className="p-4 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all">
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-bold">{analysis.symbol}</h3>
            {getRiskBadge(analysis.opportunity.risk)}
          </div>
          <p className="text-sm text-gray-500">
            Fiyat: ${formatNumber(analysis.price)} | Hacim: {analysis.volume}
          </p>
        </div>
        <div className="text-right">
          <div className={`text-lg font-bold ${getOpportunityColor(analysis.opportunity.score)}`}>
            Fırsat Skoru: {analysis.opportunity.score}
          </div>
          <div className="flex items-center gap-2 justify-end">
            <span className="text-sm">Kar Potansiyeli:</span>
            <Progress value={analysis.opportunity.profitPotential * 100} className="w-32" />
          </div>
        </div>
      </div>
      
      <div className="mt-4 grid grid-cols-2 gap-4">
        <div>
          <h4 className="font-medium mb-2">Teknik Göstergeler</h4>
          <ul className="space-y-1 text-sm">
            <li className="flex items-center justify-between">
              <span>RSI:</span>
              <span className={analysis.signals.rsi > 70 ? 'text-red-500' : analysis.signals.rsi < 30 ? 'text-green-500' : ''}>
                {formatNumber(analysis.signals.rsi)}
              </span>
            </li>
            <li className="flex items-center justify-between">
              <span>MACD Histogram:</span>
              <span className={analysis.signals.macd.histogram > 0 ? 'text-green-500' : 'text-red-500'}>
                {formatNumber(analysis.signals.macd.histogram)}
              </span>
            </li>
            <li>
              <span>Bollinger:</span>
              {analysis.price > analysis.signals.bb.upper ? (
                <Badge variant="destructive" className="ml-2">Üst Band Üstünde</Badge>
              ) : analysis.price < analysis.signals.bb.lower ? (
                <Badge variant="default" className="ml-2 bg-green-500">Alt Band Altında</Badge>
              ) : (
                <Badge variant="secondary" className="ml-2">Bantlar Arasında</Badge>
              )}
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-medium mb-2">Yapay Zeka Tahmini</h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm">Tahmin:</span>
              <span className={`font-medium ${
                analysis.mlPrediction?.price && analysis.mlPrediction.price > analysis.price
                  ? 'text-green-500'
                  : 'text-red-500'
              }`}>
                ${formatNumber(analysis.mlPrediction?.price)}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm">Güven:</span>
              <Progress value={analysis.mlPrediction?.confidence ? analysis.mlPrediction.confidence * 100 : 0} className="w-32" />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 border-t pt-4">
        <div className="flex justify-between items-center">
          <div className="space-y-1">
            <h4 className="font-medium">Performans Geçmişi</h4>
            <div className="text-sm">
              Başarı Oranı: {(analysis.historicalPerformance.successRate * 100).toFixed(1)}%
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-green-500">
              Ort. Kar: {formatNumber(analysis.historicalPerformance.avgProfit)}%
            </div>
            <div className="text-sm text-red-500">
              Ort. Zarar: {formatNumber(analysis.historicalPerformance.avgLoss)}%
            </div>
          </div>
        </div>
      </div>

      {analysis.opportunity.reason && (
        <div className="mt-4 p-3 bg-gray-100 dark:bg-gray-800 rounded-lg">
          <div className="flex items-start gap-2">
            <AlertTriangle className="w-5 h-5 text-yellow-500 mt-0.5" />
            <p className="text-sm">{analysis.opportunity.reason}</p>
          </div>
        </div>
      )}
    </Card>
  );
};

export default CoinCard;
