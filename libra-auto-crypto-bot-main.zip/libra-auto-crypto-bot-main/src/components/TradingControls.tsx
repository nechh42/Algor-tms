import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import TradingHeader from './trading/TradingHeader';
import TradeTypeSelector from './trading/TradeTypeSelector';
import PositionStats from './trading/PositionStats';
import ActionButtons from './trading/ActionButtons';
import StrategySettings from './trading/StrategySettings';
import TradeInputs from './trading/TradeInputs';
import ManualTradeButtons from './trading/ManualTradeButtons';

const TradingControls = () => {
  const [autoTrade, setAutoTrade] = useState(false);
  const [amount, setAmount] = useState('40');
  const [leverage, setLeverage] = useState('10');
  const [stopLoss, setStopLoss] = useState('2');
  const [takeProfit, setTakeProfit] = useState('4');
  const [strategy, setStrategy] = useState('COMBINED');
  const [riskLevel, setRiskLevel] = useState(50);
  const [tradeType, setTradeType] = useState('FUTURES');
  const [isHedgeMode, setIsHedgeMode] = useState(false);
  const [isRealTrading, setIsRealTrading] = useState(true); // Varsayılan olarak gerçek hesap
  const { toast } = useToast();

  const handleTradingModeChange = (checked: boolean) => {
    setIsRealTrading(checked);
    toast({
      title: checked ? "Gerçek Ticaret Modu Aktif" : "Test Modu Aktif",
      description: checked ? 
        "Dikkat: Gerçek para ile işlem yapılacak!" : 
        "Demo hesap üzerinde işlemler gerçekleştirilecek.",
      variant: checked ? "destructive" : "default",
    });
  };

  const handleCloseAllPositions = () => {
    toast({
      title: "Tüm Pozisyonlar Kapatılıyor",
      description: `${isRealTrading ? 'Gerçek' : 'Test'} modunda pozisyonlar kapatılıyor.`,
    });
  };

  const handleExit = () => {
    setAutoTrade(false);
    handleCloseAllPositions();
    toast({
      title: "Çıkış Yapılıyor",
      description: "Tüm işlemler durduruldu ve pozisyonlar kapatılıyor.",
    });
  };

  const validateAmount = (value: string) => {
    const numValue = Number(value);
    if (numValue < 40) {
      toast({
        title: "Uyarı",
        description: "Minimum işlem miktarı 40 USDT olmalıdır.",
        variant: "destructive",
      });
      setAmount('40');
    }
  };

  return (
    <Card className="p-4 space-y-4">
      <TradingHeader 
        isRealTrading={isRealTrading}
        handleTradingModeChange={handleTradingModeChange}
        autoTrade={autoTrade}
        setAutoTrade={setAutoTrade}
        riskLevel={riskLevel}
      />

      <TradeTypeSelector 
        tradeType={tradeType}
        setTradeType={setTradeType}
        isHedgeMode={isHedgeMode}
        setIsHedgeMode={setIsHedgeMode}
        leverage={leverage}
        setLeverage={setLeverage}
        isRealTrading={isRealTrading}
      />

      <PositionStats />

      <ActionButtons 
        handleCloseAllPositions={handleCloseAllPositions}
        handleExit={handleExit}
      />

      <StrategySettings 
        strategy={strategy}
        setStrategy={setStrategy}
        riskLevel={riskLevel}
        setRiskLevel={setRiskLevel}
      />

      <TradeInputs 
        amount={amount}
        setAmount={(value) => {
          setAmount(value);
          validateAmount(value);
        }}
        stopLoss={stopLoss}
        setStopLoss={setStopLoss}
        takeProfit={takeProfit}
        setTakeProfit={setTakeProfit}
        tradeType={tradeType}
        leverage={leverage}
        isRealTrading={isRealTrading}
      />

      <ManualTradeButtons 
        stopLoss={stopLoss}
        takeProfit={takeProfit}
        tradeType={tradeType}
        leverage={leverage}
        isHedgeMode={isHedgeMode}
        isRealTrading={isRealTrading}
      />
    </Card>
  );
};

export default TradingControls;