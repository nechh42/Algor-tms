import React from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/components/ui/use-toast';
import { useQuery } from '@tanstack/react-query';
import { multiCoinAnalysisService } from '@/services/multiCoinAnalysis';
import { MLAnalysisService } from '@/services/mlAnalysis';
import CoinCard from './multicoin/CoinCard';
import LoadingSkeleton from './multicoin/LoadingSkeleton';
import { Badge } from '@/components/ui/badge';

const MultiCoinView = () => {
  const { toast } = useToast();

  const { data: analyses, isLoading, error } = useQuery({
    queryKey: ['coinAnalyses'],
    queryFn: async () => {
      const data = await multiCoinAnalysisService.analyzeAllCoins();
      const analysesWithML = await Promise.all(
        data.map(async (analysis) => {
          const mlPrediction = await MLAnalysisService.getPrediction(analysis.symbol);
          return { ...analysis, mlPrediction };
        })
      );
      return analysesWithML;
    },
    refetchInterval: 30000,
    meta: {
      onError: () => {
        toast({
          title: "Hata",
          description: "Coin verileri alınırken bir hata oluştu.",
          variant: "destructive",
        });
      },
      onSuccess: (data) => {
        const opportunities = data.filter(a => a.opportunity.score > 80);
        if (opportunities.length > 0) {
          opportunities.slice(0, 3).forEach(opp => {
            toast({
              title: `Yüksek Fırsat: ${opp.symbol}`,
              description: `Skor: ${opp.opportunity.score}, Sebep: ${opp.opportunity.reason}`,
            });
          });
        }
      },
    }
  });

  if (error) {
    return (
      <div className="text-center text-red-500">
        Veriler yüklenirken bir hata oluştu. Lütfen tekrar deneyin.
      </div>
    );
  }

  const highOpportunityCount = analyses?.filter(a => a.opportunity.score > 80).length || 0;
  const mediumOpportunityCount = analyses?.filter(a => a.opportunity.score > 60 && a.opportunity.score <= 80).length || 0;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center mb-4">
        <div className="space-y-1">
          <h2 className="text-2xl font-bold">Coin Analizi</h2>
          <p className="text-sm text-gray-500">
            {analyses?.length || 0} coin analiz ediliyor
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="default" className="bg-green-500">
            Yüksek Fırsat: {highOpportunityCount}
          </Badge>
          <Badge variant="default" className="bg-yellow-500">
            Orta Fırsat: {mediumOpportunityCount}
          </Badge>
        </div>
      </div>

      <ScrollArea className="h-[600px] w-full rounded-md border p-4">
        <div className="space-y-4">
          {isLoading ? (
            <LoadingSkeleton />
          ) : (
            analyses?.map((analysis) => (
              <CoinCard key={analysis.symbol} analysis={analysis} />
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

export default MultiCoinView;