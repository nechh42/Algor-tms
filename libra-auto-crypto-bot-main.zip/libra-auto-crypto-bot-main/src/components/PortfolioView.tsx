import React from 'react';
import { Card } from '@/components/ui/card';
import { PortfolioService } from '@/services/portfolio';
import { Progress } from '@/components/ui/progress';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import PortfolioChart from './PortfolioChart';
import PortfolioDistributionChart from './portfolio/PortfolioDistributionChart';

const PortfolioView = () => {
  const { data: positions, isLoading } = useQuery({
    queryKey: ['portfolio'],
    queryFn: PortfolioService.getPositions,
    refetchInterval: 30000,
  });

  const { data: chartData = [] } = useQuery({
    queryKey: ['portfolioHistory'],
    queryFn: PortfolioService.getPortfolioHistory,
    refetchInterval: 60000,
  });

  const { data: tradeHistory = [] } = useQuery({
    queryKey: ['tradeHistory'],
    queryFn: PortfolioService.getTradeHistory,
    refetchInterval: 60000,
  });

  const totalRisk = positions ? PortfolioService.calculatePortfolioRisk(positions) : 0;
  const totalValue = positions?.reduce((sum, pos) => sum + pos.amount * pos.currentPrice, 0) || 0;
  const totalPnL = positions?.reduce((sum, pos) => sum + pos.pnl, 0) || 0;

  if (isLoading) {
    return (
      <Card className="p-4 space-y-4">
        <Skeleton className="h-6 w-[200px]" />
        <Skeleton className="h-4 w-full" />
        <div className="space-y-4">
          {Array(3).fill(0).map((_, i) => (
            <div key={i} className="border p-3 rounded-lg space-y-2">
              <Skeleton className="h-4 w-[150px]" />
              <div className="grid grid-cols-2 gap-2">
                <Skeleton className="h-4 w-[100px]" />
                <Skeleton className="h-4 w-[100px]" />
              </div>
            </div>
          ))}
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {chartData && <PortfolioChart data={chartData} />}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-4">Portföy Durumu</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="p-3 border rounded-lg">
              <div className="text-sm text-gray-600">Toplam Değer</div>
              <div className="text-lg font-semibold">${totalValue.toFixed(2)}</div>
            </div>
            <div className="p-3 border rounded-lg">
              <div className="text-sm text-gray-600">Toplam Kar/Zarar</div>
              <div className={`text-lg font-semibold ${totalPnL >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {totalPnL > 0 ? '+' : ''}{totalPnL.toFixed(2)} USDT
              </div>
            </div>
            <div className="p-3 border rounded-lg">
              <div className="text-sm text-gray-600">Risk Seviyesi</div>
              <Progress value={totalRisk * 100} className="mt-2" />
            </div>
          </div>

          <div className="space-y-4">
            {positions?.map((position) => (
              <div key={position.symbol} className="border p-3 rounded-lg">
                <div className="flex justify-between mb-2">
                  <span className="font-medium">{position.symbol}</span>
                  <span className={position.pnl >= 0 ? 'text-green-500' : 'text-red-500'}>
                    {position.pnl > 0 ? '+' : ''}{position.pnl.toFixed(2)} USDT
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
                  <div>Miktar: {position.amount}</div>
                  <div>Giriş: ${position.entryPrice}</div>
                  <div>Güncel: ${position.currentPrice}</div>
                  <div>Risk: {(position.risk * 100).toFixed(1)}%</div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {positions && <PortfolioDistributionChart positions={positions} />}
      </div>

      <Card className="p-4">
        <h3 className="text-lg font-semibold mb-4">İşlem Geçmişi</h3>
        <ScrollArea className="h-[300px]">
          <div className="space-y-2">
            {tradeHistory.map((trade, index) => (
              <div key={index} className="flex items-center justify-between p-2 border rounded-lg">
                <div className="flex items-center gap-2">
                  <Badge variant={trade.type === 'BUY' ? 'default' : 'destructive'}>
                    {trade.type}
                  </Badge>
                  <span className="font-medium">{trade.symbol}</span>
                </div>
                <div className="text-sm text-gray-600">
                  <div>Fiyat: ${trade.price}</div>
                  <div>Miktar: {trade.amount}</div>
                </div>
                <div className="text-right">
                  <div className={trade.pnl >= 0 ? 'text-green-500' : 'text-red-500'}>
                    {trade.pnl > 0 ? '+' : ''}{trade.pnl} USDT
                  </div>
                  <div className="text-sm text-gray-600">{new Date(trade.timestamp).toLocaleString()}</div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </Card>
    </div>
  );
};

export default PortfolioView;