import React from 'react';
import { Card } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useTheme } from 'next-themes';

interface PortfolioChartProps {
  data: {
    timestamp: string;
    value: number;
    profit: number;
  }[];
}

const PortfolioChart = ({ data }: PortfolioChartProps) => {
  const { theme } = useTheme();
  const textColor = theme === 'dark' ? '#ffffff' : '#000000';

  return (
    <Card className="p-4">
      <h3 className="text-lg font-semibold mb-4">Portföy Performansı</h3>
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="timestamp" 
              stroke={textColor}
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke={textColor}
              style={{ fontSize: '12px' }}
            />
            <Tooltip />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="value" 
              stroke="#8884d8" 
              name="Portföy Değeri"
            />
            <Line 
              type="monotone" 
              dataKey="profit" 
              stroke="#82ca9d" 
              name="Kar/Zarar"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
};

export default PortfolioChart;