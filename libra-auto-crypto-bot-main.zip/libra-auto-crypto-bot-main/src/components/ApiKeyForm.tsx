import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { binanceService } from '@/services/binance';
import { AlertCircle, CheckCircle2, Wallet } from 'lucide-react';

const ApiKeyForm = () => {
  const [apiKey, setApiKey] = useState('');
  const [apiSecret, setApiSecret] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [accountInfo, setAccountInfo] = useState<any>(null);
  const [futuresAccountInfo, setFuturesAccountInfo] = useState<any>(null);
  const { toast } = useToast();

  useEffect(() => {
    const savedApiKey = localStorage.getItem('BINANCE_API_KEY');
    const savedApiSecret = localStorage.getItem('BINANCE_API_SECRET');
    
    if (savedApiKey && savedApiSecret) {
      setApiKey(savedApiKey);
      setApiSecret(savedApiSecret);
      checkConnection();
    }
  }, []);

  const checkConnection = async () => {
    if (binanceService.isInitialized()) {
      try {
        const [spotInfo, futuresInfo] = await Promise.all([
          binanceService.getAccountInfo(),
          binanceService.getFuturesAccountInfo()
        ]);
        
        setAccountInfo(spotInfo);
        setFuturesAccountInfo(futuresInfo);
        setIsConnected(true);
        
        toast({
          title: "Gerçek Hesap Bağlandı",
          description: "Binance API bağlantısı başarıyla kuruldu.",
        });
      } catch (error) {
        setIsConnected(false);
        console.error('Hesap bilgileri alınamadı:', error);
        toast({
          title: "Bağlantı Hatası",
          description: "API anahtarlarınızı kontrol edin.",
          variant: "destructive",
        });
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      binanceService.initialize(apiKey, apiSecret);
      const [spotInfo, futuresInfo] = await Promise.all([
        binanceService.getAccountInfo(),
        binanceService.getFuturesAccountInfo()
      ]);
      
      setAccountInfo(spotInfo);
      setFuturesAccountInfo(futuresInfo);
      setIsConnected(true);
      
      localStorage.setItem('BINANCE_API_KEY', apiKey);
      localStorage.setItem('BINANCE_API_SECRET', apiSecret);
      
      toast({
        title: "Gerçek Hesap Bağlandı",
        description: "API anahtarları doğrulandı ve hesap bağlandı.",
      });
    } catch (error) {
      setIsConnected(false);
      localStorage.removeItem('BINANCE_API_KEY');
      localStorage.removeItem('BINANCE_API_SECRET');
      toast({
        title: "Bağlantı Hatası",
        description: "API anahtarları doğrulanamadı. Lütfen kontrol edin.",
        variant: "destructive",
      });
    }
  };

  if (isConnected && accountInfo) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <CheckCircle2 className="text-green-500 w-6 h-6" />
          <h3 className="text-lg font-semibold">Gerçek Hesap Bağlı</h3>
        </div>
        <div className="space-y-4">
          <div className="p-4 bg-muted rounded-lg">
            <div className="flex items-center gap-2 mb-3">
              <Wallet className="w-5 h-5 text-primary" />
              <span className="font-medium">Hesap Detayları</span>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">API Key:</span>
                <span className="font-medium">{apiKey ? `${apiKey.substring(0, 4)}...${apiKey.substring(apiKey.length - 4)}` : '****'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">Hesap Durumu:</span>
                <span className="font-medium text-green-500">Aktif (Gerçek Hesap)</span>
              </div>

              {/* Spot Bakiyeler */}
              {accountInfo.balances && (
                <div className="space-y-2 mt-3 pt-3 border-t border-border">
                  <div className="text-sm font-medium mb-2">Spot Bakiyeler:</div>
                  {accountInfo.balances
                    .filter((balance: any) => parseFloat(balance.free) > 0)
                    .map((balance: any, index: number) => (
                      <div key={`spot-${index}`} className="flex justify-between items-center">
                        <span className="text-sm text-gray-500">{balance.asset}:</span>
                        <span className="font-medium">{Number(balance.free).toFixed(8)}</span>
                      </div>
                    ))
                  }
                </div>
              )}

              {/* Futures Bakiyeler */}
              {futuresAccountInfo && (
                <div className="space-y-2 mt-3 pt-3 border-t border-border">
                  <div className="text-sm font-medium mb-2">Futures Bakiyeler:</div>
                  {futuresAccountInfo.assets
                    .filter((asset: any) => parseFloat(asset.walletBalance) > 0)
                    .map((asset: any, index: number) => (
                      <div key={`futures-${index}`} className="flex justify-between items-center">
                        <span className="text-sm text-gray-500">{asset.asset}:</span>
                        <div className="text-right">
                          <div className="font-medium">{Number(asset.walletBalance).toFixed(8)}</div>
                          <div className="text-xs text-gray-500">
                            PNL: {Number(asset.unrealizedProfit).toFixed(8)}
                          </div>
                        </div>
                      </div>
                    ))
                  }
                </div>
              )}
            </div>
          </div>
          
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => {
              localStorage.removeItem('BINANCE_API_KEY');
              localStorage.removeItem('BINANCE_API_SECRET');
              setIsConnected(false);
              setAccountInfo(null);
              setFuturesAccountInfo(null);
              setApiKey('');
              setApiSecret('');
              toast({
                title: "Bağlantı Kesildi",
                description: "API anahtarları kaldırıldı.",
              });
            }}
          >
            Hesap Bağlantısını Kes
          </Button>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-4">
        <AlertCircle className="text-yellow-500 w-6 h-6" />
        <h3 className="text-lg font-semibold">Gerçek Hesap Bağlantısı Gerekli</h3>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="apiKey">Binance API Key</Label>
          <Input
            id="apiKey"
            type="text"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="Binance API Key"
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="apiSecret">Binance API Secret</Label>
          <Input
            id="apiSecret"
            type="password"
            value={apiSecret}
            onChange={(e) => setApiSecret(e.target.value)}
            placeholder="Binance API Secret"
            required
          />
        </div>

        <Button type="submit" className="w-full">
          Gerçek Hesap API Anahtarlarını Doğrula
        </Button>
      </form>
    </Card>
  );
};

export default ApiKeyForm;