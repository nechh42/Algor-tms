import React, { useEffect, useRef } from 'react';
import { createChart, CrosshairMode, IChartApi, ISeriesApi, Time } from 'lightweight-charts';
import { useToast } from '@/hooks/use-toast';

interface ChartContainerProps {
  data: any[];
  indicators: string[];
  isDrawingMode: boolean;
}

const ChartContainer = ({ data, indicators, isDrawingMode }: ChartContainerProps) => {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chart = useRef<IChartApi | null>(null);
  const candlestickSeries = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const indicatorSeries = useRef<ISeriesApi<'Line'>[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    if (chartContainerRef.current) {
      chart.current = createChart(chartContainerRef.current, {
        width: chartContainerRef.current.clientWidth,
        height: 500,
        layout: {
          background: { color: '#1a1a1a' },
          textColor: '#DDD',
        },
        grid: {
          vertLines: { color: '#2B2B43' },
          horzLines: { color: '#2B2B43' },
        },
        crosshair: {
          mode: CrosshairMode.Normal,
        },
      });

      candlestickSeries.current = chart.current.addCandlestickSeries({
        upColor: '#26a69a',
        downColor: '#ef5350',
        borderVisible: false,
        wickUpColor: '#26a69a',
        wickDownColor: '#ef5350',
      });

      const handleResize = () => {
        if (chartContainerRef.current && chart.current) {
          chart.current.applyOptions({ 
            width: chartContainerRef.current.clientWidth 
          });
        }
      };

      window.addEventListener('resize', handleResize);
      return () => {
        window.removeEventListener('resize', handleResize);
        if (chart.current) {
          chart.current.remove();
        }
      };
    }
  }, []);

  useEffect(() => {
    if (candlestickSeries.current && data.length > 0) {
      candlestickSeries.current.setData(data);
    }
  }, [data]);

  useEffect(() => {
    if (!chart.current || !data.length) return;

    // Clear existing indicators
    indicatorSeries.current.forEach(series => {
      if (chart.current) {
        chart.current.removeSeries(series);
      }
    });
    indicatorSeries.current = [];

    candlestickSeries.current = chart.current.addCandlestickSeries({
      upColor: '#26a69a',
      downColor: '#ef5350',
      borderVisible: false,
      wickUpColor: '#26a69a',
      wickDownColor: '#ef5350',
    });
    candlestickSeries.current.setData(data);

    // Add indicators
    indicators.forEach(indicator => {
      if (indicator === 'MA') addMovingAverage(data);
      if (indicator === 'EMA') addEMA(data);
    });
  }, [indicators, data]);

  const addMovingAverage = (data: any[]) => {
    if (!chart.current) return;
    
    const maData = data.map((item, idx, arr) => {
      if (idx < 20) return null;
      const sum = arr.slice(idx - 20, idx).reduce((acc, val) => acc + val.close, 0);
      return {
        time: item.time as Time,
        value: sum / 20
      };
    }).filter((item): item is { time: Time; value: number } => item !== null);

    const lineSeries = chart.current.addLineSeries({
      color: '#2962FF',
      lineWidth: 2,
      title: 'MA(20)',
    });
    lineSeries.setData(maData);
    indicatorSeries.current.push(lineSeries);
  };

  const addEMA = (data: any[]) => {
    if (!chart.current) return;
    
    const multiplier = 2 / (20 + 1);
    const emaData = data.map((item, idx, arr) => {
      if (idx === 0) return { time: item.time as Time, value: item.close };
      const prevEMA = idx > 0 ? emaData[idx - 1].value : item.close;
      return {
        time: item.time as Time,
        value: (item.close - prevEMA) * multiplier + prevEMA
      };
    });

    const lineSeries = chart.current.addLineSeries({
      color: '#FF9800',
      lineWidth: 2,
      title: 'EMA(20)',
    });
    lineSeries.setData(emaData);
    indicatorSeries.current.push(lineSeries);
  };

  return <div ref={chartContainerRef} className="w-full h-[500px]" />;
};

export default ChartContainer;