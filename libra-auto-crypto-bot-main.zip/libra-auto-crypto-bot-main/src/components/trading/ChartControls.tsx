import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';

interface ChartControlsProps {
  timeframe: string;
  onTimeframeChange: (value: string) => void;
  activeIndicators: string[];
  onToggleIndicator: (indicator: string) => void;
  isDrawingMode: boolean;
  onToggleDrawingMode: () => void;
}

const ChartControls = ({
  timeframe,
  onTimeframeChange,
  activeIndicators,
  onToggleIndicator,
  isDrawingMode,
  onToggleDrawingMode
}: ChartControlsProps) => {
  return (
    <div className="flex justify-between items-center mb-4">
      <div className="space-x-2">
        <Select value={timeframe} onValueChange={onTimeframeChange}>
          <SelectTrigger className="w-[100px]">
            <SelectValue placeholder="Zaman" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1m">1 dakika</SelectItem>
            <SelectItem value="5m">5 dakika</SelectItem>
            <SelectItem value="15m">15 dakika</SelectItem>
            <SelectItem value="1h">1 saat</SelectItem>
            <SelectItem value="4h">4 saat</SelectItem>
            <SelectItem value="1d">1 gün</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-x-2">
        {(['MA', 'EMA', 'RSI', 'MACD', 'BB'] as const).map((indicator) => (
          <Button
            key={indicator}
            variant={activeIndicators.includes(indicator) ? "default" : "outline"}
            onClick={() => onToggleIndicator(indicator)}
            size="sm"
          >
            {indicator}
          </Button>
        ))}
        <Button
          variant={isDrawingMode ? "default" : "outline"}
          onClick={onToggleDrawingMode}
          size="sm"
        >
          Çizim
        </Button>
      </div>
    </div>
  );
};

export default ChartControls;