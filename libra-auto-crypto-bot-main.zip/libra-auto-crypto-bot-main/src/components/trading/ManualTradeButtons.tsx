import React from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { StrategyService } from '@/services/strategy';

interface ManualTradeButtonsProps {
  stopLoss: string;
  takeProfit: string;
  tradeType: string;
  leverage?: string;
  isHedgeMode?: boolean;
  isRealTrading?: boolean;
}

const ManualTradeButtons = ({ 
  stopLoss, 
  takeProfit, 
  tradeType,
  leverage = '1',
  isHedgeMode = false,
  isRealTrading = false
}: ManualTradeButtonsProps) => {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = React.useState(false);

  const handleManualTrade = async (action: 'BUY' | 'SELL') => {
    if (isProcessing) return;

    if (isRealTrading) {
      toast({
        title: "Dikkat: Gerçek İşlem",
        description: "Gerçek para ile işlem yapılacak. Devam etmek istiyor musunuz?",
        variant: "destructive",
      });
    }

    setIsProcessing(true);

    try {
      const signal = await StrategyService.analyzeMarket();
      const effectiveLeverage = tradeType === 'FUTURES' ? Number(leverage) : 1;
      
      const stopLossPrice = action === 'BUY' ? 
        signal.price * (1 - Number(stopLoss) / (100 * effectiveLeverage)) : 
        signal.price * (1 + Number(stopLoss) / (100 * effectiveLeverage));
      
      const takeProfitPrice = action === 'BUY' ? 
        signal.price * (1 + Number(takeProfit) / (100 * effectiveLeverage)) : 
        signal.price * (1 - Number(takeProfit) / (100 * effectiveLeverage));

      toast({
        title: `${action} İşlemi (${tradeType}) - ${isRealTrading ? 'GERÇEK' : 'TEST'} MOD`,
        description: (
          <div>
            <p>Sinyal: {signal.action} ({signal.reason})</p>
            <p>Stop Loss: ${stopLossPrice.toFixed(2)}</p>
            <p>Take Profit: ${takeProfitPrice.toFixed(2)}</p>
            {tradeType === 'FUTURES' && (
              <p>Kaldıraç: {leverage}x {isHedgeMode ? '(Hedge Mode)' : ''}</p>
            )}
          </div>
        ),
        variant: signal.action === action ? "default" : "destructive",
      });
    } catch (error) {
      toast({
        title: "İşlem Hatası",
        description: "İşlem gerçekleştirilemedi",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-2">
      {isRealTrading && (
        <div className="text-red-500 text-sm font-semibold mb-2 text-center">
          ⚠️ GERÇEK TİCARET MODU AKTİF ⚠️
        </div>
      )}
      <div className="flex space-x-2">
        <Button 
          className={`w-full ${isRealTrading ? 'bg-green-600' : 'bg-green-500'} hover:bg-green-600`}
          onClick={() => handleManualTrade('BUY')}
          disabled={isProcessing}
        >
          {tradeType === 'FUTURES' ? 'Long' : 'Al'}
        </Button>
        <Button 
          className={`w-full ${isRealTrading ? 'bg-red-600' : 'bg-red-500'} hover:bg-red-600`}
          onClick={() => handleManualTrade('SELL')}
          disabled={isProcessing}
        >
          {tradeType === 'FUTURES' ? 'Short' : 'Sat'}
        </Button>
      </div>
    </div>
  );
};

export default ManualTradeButtons;