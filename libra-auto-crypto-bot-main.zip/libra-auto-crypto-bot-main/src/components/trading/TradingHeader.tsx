import React from 'react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import AutoTradeControl from './AutoTradeControl';

interface TradingHeaderProps {
  isRealTrading: boolean;
  handleTradingModeChange: (checked: boolean) => void;
  autoTrade: boolean;
  setAutoTrade: (checked: boolean) => void;
  riskLevel: number;
}

const TradingHeader = ({
  isRealTrading,
  handleTradingModeChange,
  autoTrade,
  setAutoTrade,
  riskLevel
}: TradingHeaderProps) => {
  return (
    <div className="flex items-center justify-between">
      <h3 className="text-lg font-semibold">İşlem Kontrolleri</h3>
      <div className="flex items-center gap-4">
        <div className="flex items-center space-x-2">
          <Switch
            checked={isRealTrading}
            onCheckedChange={handleTradingModeChange}
            className={isRealTrading ? "bg-red-500" : ""}
          />
          <Label>
            {isRealTrading ? 
              <span className="text-red-500 font-semibold">Gerçek Ticaret</span> : 
              <span className="text-green-500">Test Modu</span>
            }
          </Label>
        </div>
        <AutoTradeControl 
          autoTrade={autoTrade}
          setAutoTrade={setAutoTrade}
          riskLevel={riskLevel}
          isRealTrading={isRealTrading}
        />
      </div>
    </div>
  );
};

export default TradingHeader;