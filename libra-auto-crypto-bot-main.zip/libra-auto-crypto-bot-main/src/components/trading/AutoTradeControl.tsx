import React from 'react';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { StrategyService } from '@/services/strategy';
import { autoTrader } from '@/services/trading/autoTrader';
import { TrendingUp } from 'lucide-react';

interface AutoTradeControlProps {
  autoTrade: boolean;
  setAutoTrade: (checked: boolean) => void;
  riskLevel: number;
  isRealTrading: boolean;
}

const AutoTradeControl = ({ 
  autoTrade, 
  setAutoTrade, 
  riskLevel,
  isRealTrading 
}: AutoTradeControlProps) => {
  const { toast } = useToast();

  const handleAutoTradeChange = async (checked: boolean) => {
    if (checked && isRealTrading) {
      toast({
        title: "Dikkat: Gerçek Para ile Otomatik İşlem",
        description: "Gerçek para ile otomatik işlem başlatılıyor. Riski kabul ediyor musunuz?",
        variant: "destructive",
      });
    }
    
    setAutoTrade(checked);
    if (checked) {
      try {
        await StrategyService.startAutoTrading(40, 1);
        toast({
          title: `Otomatik işlem başlatıldı (${isRealTrading ? 'Gerçek' : 'Test'} Mod)`,
          description: "Sistem sinyalleri takip edecek ve uygun fırsatlarda işlem açacak",
        });
      } catch (error) {
        toast({
          title: "Otomatik işlem başlatılamadı",
          description: "Bir hata oluştu, lütfen tekrar deneyin",
          variant: "destructive",
        });
        setAutoTrade(false);
      }
    } else {
      autoTrader.stopTrading();
      toast({
        title: "Otomatik işlem durduruldu",
        description: "Sistem manuel moda geçti",
      });
    }
  };

  return (
    <div className="flex items-center space-x-2">
      <Label htmlFor="auto-trade">Otomatik İşlem</Label>
      <Switch 
        id="auto-trade" 
        checked={autoTrade}
        onCheckedChange={handleAutoTradeChange}
      />
    </div>
  );
};

export default AutoTradeControl;