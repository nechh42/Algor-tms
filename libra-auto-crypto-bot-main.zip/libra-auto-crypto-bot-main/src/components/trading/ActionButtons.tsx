import React from 'react';
import { Button } from '@/components/ui/button';
import { X, LogOut } from 'lucide-react';

interface ActionButtonsProps {
  handleCloseAllPositions: () => void;
  handleExit: () => void;
}

const ActionButtons = ({ handleCloseAllPositions, handleExit }: ActionButtonsProps) => {
  return (
    <div className="flex gap-2">
      <Button 
        variant="destructive" 
        className="w-full"
        onClick={handleCloseAllPositions}
      >
        <X className="w-4 h-4 mr-2" />
        Tüm Pozisyonları Kapat
      </Button>
      <Button 
        variant="secondary" 
        className="w-full"
        onClick={handleExit}
      >
        <LogOut className="w-4 h-4 mr-2" />
        Çıkış
      </Button>
    </div>
  );
};

export default ActionButtons;