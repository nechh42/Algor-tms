import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

const PositionStats = () => {
  return (
    <div className="grid grid-cols-2 gap-2">
      <div className="p-3 border rounded-lg">
        <div className="text-sm text-gray-600">Açık Pozisyonlar</div>
        <div className="flex items-center gap-2">
          <TrendingUp className="text-green-500" />
          <span className="text-lg font-semibold">3</span>
        </div>
      </div>
      <div className="p-3 border rounded-lg">
        <div className="text-sm text-gray-600">Toplam Kar/Zarar</div>
        <div className="flex items-center gap-2">
          <TrendingDown className="text-red-500" />
          <span className="text-lg font-semibold text-red-500">-2.5%</span>
        </div>
      </div>
    </div>
  );
};

export default PositionStats;