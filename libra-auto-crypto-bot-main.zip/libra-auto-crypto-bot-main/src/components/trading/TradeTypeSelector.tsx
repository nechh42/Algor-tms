import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';

interface TradeTypeSelectorProps {
  tradeType: string;
  setTradeType: (value: string) => void;
  isHedgeMode: boolean;
  setIsHedgeMode: (checked: boolean) => void;
  leverage: string;
  setLeverage: (value: string) => void;
  isRealTrading: boolean;
}

const TradeTypeSelector = ({
  tradeType,
  setTradeType,
  isHedgeMode,
  setIsHedgeMode,
  leverage,
  setLeverage,
  isRealTrading
}: TradeTypeSelectorProps) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Select value={tradeType} onValueChange={setTradeType}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="İşlem Tipi" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="FUTURES">Vadeli İşlemler</SelectItem>
            <SelectItem value="SPOT">Spot İşlemler</SelectItem>
            <SelectItem value="BOTH">Her İkisi</SelectItem>
          </SelectContent>
        </Select>
        <Badge variant={tradeType === 'FUTURES' ? 'default' : 'secondary'} className="bg-blue-500">
          {tradeType}
        </Badge>
        {isRealTrading && (
          <Badge variant="destructive">
            Gerçek İşlem
          </Badge>
        )}
      </div>

      {tradeType === 'FUTURES' && (
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <Label htmlFor="hedge-mode">Hedge Mode</Label>
            <Switch
              id="hedge-mode"
              checked={isHedgeMode}
              onCheckedChange={setIsHedgeMode}
            />
          </div>
          <div className="flex items-center space-x-2">
            <Label>Kaldıraç (x)</Label>
            <Select value={leverage} onValueChange={setLeverage}>
              <SelectTrigger className="w-[100px]">
                <SelectValue placeholder="Kaldıraç" />
              </SelectTrigger>
              <SelectContent>
                {[1, 2, 3, 5, 10, 20, 50, 100].map((lev) => (
                  <SelectItem key={lev} value={lev.toString()}>
                    {lev}x
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      )}
    </div>
  );
};

export default TradeTypeSelector;