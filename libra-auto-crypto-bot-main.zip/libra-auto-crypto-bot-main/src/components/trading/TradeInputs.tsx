import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { AlertCircle, TrendingUp, Wallet } from 'lucide-react';

interface TradeInputsProps {
  amount: string;
  setAmount: (value: string) => void;
  stopLoss: string;
  setStopLoss: (value: string) => void;
  takeProfit: string;
  setTakeProfit: (value: string) => void;
  tradeType: string;
  leverage?: string;
  isRealTrading?: boolean;
}

const TradeInputs = ({
  amount,
  setAmount,
  stopLoss,
  setStopLoss,
  takeProfit,
  setTakeProfit,
  tradeType,
  leverage = '1',
  isRealTrading = false
}: TradeInputsProps) => {
  const effectiveAmount = tradeType === 'FUTURES' ? 
    Number(amount) * Number(leverage) : 
    Number(amount);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="amount" className="flex items-center gap-2">
            İşlem Miktarı (USDT)
            {isRealTrading && (
              <span className="text-xs text-red-500 font-semibold">
                (Gerçek Para)
              </span>
            )}
          </Label>
          <div className="relative">
            <Input 
              id="amount" 
              type="number" 
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="40.00"
              min="40"
              className={`pl-8 ${isRealTrading ? 'border-red-500' : ''}`}
            />
            <Wallet className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          </div>
          {tradeType === 'FUTURES' && (
            <div className="text-sm text-gray-500">
              Efektif İşlem: {effectiveAmount.toFixed(2)} USDT ({leverage}x)
            </div>
          )}
        </div>
        <div className="space-y-2">
          <Label htmlFor="stop-loss">Stop Loss (%)</Label>
          <div className="relative">
            <Input 
              id="stop-loss" 
              type="number" 
              value={stopLoss}
              onChange={(e) => setStopLoss(e.target.value)}
              placeholder="2"
              className="pl-8"
            />
            <AlertCircle className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="take-profit">Take Profit (%)</Label>
        <div className="relative">
          <Input 
            id="take-profit" 
            type="number" 
            value={takeProfit}
            onChange={(e) => setTakeProfit(e.target.value)}
            placeholder="4"
            className="pl-8"
          />
          <TrendingUp className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        </div>
      </div>
    </div>
  );
};

export default TradeInputs;