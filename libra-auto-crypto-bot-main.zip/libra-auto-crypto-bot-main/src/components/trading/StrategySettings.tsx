import React from 'react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';

interface StrategySettingsProps {
  strategy: string;
  setStrategy: (value: string) => void;
  riskLevel: number;
  setRiskLevel: (value: number) => void;
}

const StrategySettings = ({ 
  strategy, 
  setStrategy, 
  riskLevel, 
  setRiskLevel 
}: StrategySettingsProps) => {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Strateji</Label>
        <Select value={strategy} onValueChange={setStrategy}>
          <SelectTrigger>
            <SelectValue placeholder="Strateji seçin" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="TECHNICAL">Teknik Analiz</SelectItem>
            <SelectItem value="MOMENTUM">Momentum</SelectItem>
            <SelectItem value="VOLUME">Hacim Analizi</SelectItem>
            <SelectItem value="COMBINED">Kombine Strateji</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Risk Seviyesi</Label>
        <div className="flex items-center space-x-2">
          <Slider
            value={[riskLevel]}
            onValueChange={(value) => setRiskLevel(value[0])}
            max={100}
            step={1}
          />
          <span className="min-w-[3rem] text-right">{riskLevel}%</span>
        </div>
      </div>
    </div>
  );
};

export default StrategySettings;