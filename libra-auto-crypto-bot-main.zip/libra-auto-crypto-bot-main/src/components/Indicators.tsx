import React, { useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { binanceService } from '@/services/binance';
import { StrategyService, TradeSignal } from '@/services/strategy';
import { AnalysisService } from '@/services/analysis';
import PriceDisplay from './indicators/PriceDisplay';
import TechnicalIndicators from './indicators/TechnicalIndicators';
import SignalDisplay from './indicators/SignalDisplay';
import FibonacciLevels from './indicators/FibonacciLevels';

const Indicators = () => {
  const [price, setPrice] = useState<string>('0');
  const [signal, setSignal] = useState<TradeSignal | null>(null);
  const [prediction, setPrediction] = useState<number | null>(null);
  const [rsi, setRsi] = useState<number | null>(null);
  const [stochRsi, setStochRsi] = useState<{ k: number; d: number } | null>(null);
  const [trendStrength, setTrendStrength] = useState<number | null>(null);
  const [volume, setVolume] = useState<string>('0');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const priceData = await binanceService.getPrice('BTCUSDT');
        setPrice(priceData.price);

        const volumeData = await binanceService.get24hrStats('BTCUSDT');
        setVolume(volumeData.volume);

        const marketSignal = await StrategyService.analyzeMarket('BTCUSDT');
        setSignal(marketSignal);

        const klines = await binanceService.getKlines('BTCUSDT', '1h', 100);
        const prices = klines.map(k => k.close);
        
        const rsiValues = AnalysisService.calculateRSI(prices);
        setRsi(rsiValues[rsiValues.length - 1]);

        const stochRsiValues = AnalysisService.calculateStochRSI(prices);
        setStochRsi(stochRsiValues[stochRsiValues.length - 1]);

        const strength = AnalysisService.calculateTrendStrength(prices);
        setTrendStrength(strength);

        const nextPrice = AnalysisService.predictNextPrice(prices);
        setPrediction(nextPrice);
      } catch (error) {
        console.error('Veri çekme hatası:', error);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="p-4">
      <h3 className="text-lg font-semibold mb-4">Teknik Göstergeler</h3>
      <div className="grid grid-cols-2 gap-4">
        <PriceDisplay price={price} volume={volume} />
        <TechnicalIndicators
          rsi={rsi}
          stochRsi={stochRsi}
          trendStrength={trendStrength}
          prediction={prediction}
        />
        <SignalDisplay signal={signal} />
        {signal?.fibLevels && (
          <FibonacciLevels 
            levels={signal.fibLevels}
            pivotPoints={signal.pivotPoints}
            currentPrice={parseFloat(price)}
          />
        )}
      </div>
    </Card>
  );
};

export default Indicators;